using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LowMinionCount : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      bool GlobalTipDialogActive;

      bool LowMinionCount()
      {
      return
            // Sequence name :TipState-LowMinionCount
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarInt(
                              out TipActivationCount, 
                              0) &&
                        SetVarBool(
                              out ResetTip, 
                              False) &&
                        GetUnitAttackRange(
                              out TurretAttackRange, 
                              ChaosTopFrontTurret) &&
                        AddFloat(
                              out TurretExtendedRange, 
                              TurretAttackRange, 
                              200)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              GetUnitsInTargetArea(
                                    out EnemyTurretsNearPlayer, 
                                    TutorialPlayer, 
                                    PlayerPosition, 
                                    TurretAttackRange, 
                                    AffectEnemies,AffectTurrets, 
                                    "") &&
                              GetCollectionCount(
                                    out EnemyTurretCount, 
                                    EnemyTurretsNearPlayer) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestTipReset
                                    (
                                          ResetTip == true &&
                                          EnemyTurretCount == 0 &&
                                          SetVarBool(
                                                out ResetTip, 
                                                False)
                                    )
                              ) &&
                              ResetTip == False &&
                              // Sequence name :TestPlayerNearEnemyTurret
                              (
                                    GreaterInt(
                                          EnemyTurretCount, 
                                          0) &&
                                    EnemyTurretsNearPlayer.ForEach( Unit => (                                          SetVarAttackableUnit(
                                                out Turret, 
                                                Unit)
                                    ) &&
                                    GetUnitPosition(
                                          out TurretPosition, 
                                          Turret)
                              ) &&
                              // Sequence name :TestTurretHealth
                              (
                                    GetUnitCurrentHealth(
                                          out TurretHealth, 
                                          Turret) &&
                                    GreaterFloat(
                                          TurretHealth, 
                                          400)
                              ) &&
                              // Sequence name :TestFriendlyMinionsNearTurret
                              (
                                    GetUnitsInTargetArea(
                                          out FriendlyMinionsNearTurret, 
                                          TutorialPlayer, 
                                          TurretPosition, 
                                          TurretExtendedRange, 
                                          AffectFriends,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyMinionCount, 
                                          FriendlyMinionsNearTurret) &&
                                    GreaterInt(
                                          FriendlyMinionCount, 
                                          0) &&
                                    LessEqualInt(
                                          FriendlyMinionCount, 
                                          2)
                              ) &&
                              // Sequence name :TestFriendlyMinionsNearPlayer
                              (
                                    GetUnitsInTargetArea(
                                          out FriendlyMinionsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          500, 
                                          AffectFriends,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyMinionCount, 
                                          FriendlyMinionsNearPlayer) &&
                                    LessInt(
                                          FriendlyMinionCount, 
                                          3)
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ToggleUnitHighlight(
                                    true, 
                                    Turret) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_low_minion_count, 
                                    game_advanced_tutorial_tip_dialog_low_minion_count, 
                                    DATA/Images/Tips/tipDialogImage_lowMinionCount.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Watch_Out, 
                                    Tutorial2, 
                                    true) &&
                              AddInt(
                                    out TipActivationCount, 
                                    TipActivationCount, 
                                    1) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUnitHighlight(
                              False, 
                              Turret) &&
                        // Sequence name :CappedRepeat
                        (
                              // Sequence name :TestTipActivationCount
                              (
                                    GreaterEqualInt(
                                          TipActivationCount, 
                                          3) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          LowMinionCount)
                              ) ||
                              // Sequence name :ResetTip
                              (
                                    SetVarBool(
                                          out TipDialogActive, 
                                          False) &&
                                    SetVarBool(
                                          out ResetTip, 
                                          true) &&
                                    DelayNSecondsBlocking(
                                          10)

                              )
                        )
                  )
            );
      }
}

