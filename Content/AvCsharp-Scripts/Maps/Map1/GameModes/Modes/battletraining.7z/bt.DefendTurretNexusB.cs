using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendTurretNexusB : BehaviourTree 
{
      float BuildingDefensePlayerCheckRange;
      int BuildingSecureTime;
      AttackableUnit OrderNexusTurretB;
      AttackableUnit TutorialPlayer;

      bool DefendTurretNexusB()
      {
      return
            // Sequence name :QuestState-DefendTurretNexusB
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out TurretPosition, 
                                    OrderNexusTurretB) &&
                              GetUnitCurrentHealth(
                                    out CurrentTurretHealth, 
                                    OrderNexusTurretB) &&
                              SetVarFloat(
                                    out PreviousTurretHealth, 
                                    CurrentTurretHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderNexusTurretB, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendNexus) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendTurretNexusB)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderNexusTurretB, 
                                    true) &&
                              // Sequence name :TestTurretDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentTurretHealth, 
                                          OrderNexusTurretB) &&
                                    LessFloat(
                                          CurrentTurretHealth, 
                                          PreviousTurretHealth)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderNexusTurretB, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Base_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :UpdateReferences
                                    (
                                          TestUnitCondition(
                                                OrderNexusTurretB, 
                                                true) &&
                                          DelayNSecondsBlocking(
                                                1) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestTurretHealthOverTime
                                                (
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            False) &&
                                                      GetUnitCurrentHealth(
                                                            out CurrentTurretHealth, 
                                                            OrderNexusTurretB) &&
                                                      // Sequence name :UpdateSteadyHealthCount
                                                      (
                                                            // Sequence name :TestTurretNotDamaged
                                                            (
                                                                  GreaterEqualFloat(
                                                                        CurrentTurretHealth, 
                                                                        PreviousTurretHealth) &&
                                                                  AddInt(
                                                                        out SteadyHealthCount, 
                                                                        SteadyHealthCount, 
                                                                        1)
                                                            ) ||
                                                            SetVarInt(
                                                                  out SteadyHealthCount, 
                                                                  0)
                                                      ) &&
                                                      SteadyHealthCount == BuildingSecureTime &&
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            true)
                                                )
                                          ) &&
                                          DistanceBetweenObjectAndPoint(
                                                out PlayerDistance, 
                                                TutorialPlayer, 
                                                TurretPosition) &&
                                          // Sequence name :CountNumberOfEnemiesNearTurret
                                          (
                                                GetUnitsInTargetArea(
                                                      out EnemiesInTurretArea, 
                                                      TutorialPlayer, 
                                                      TurretPosition, 
                                                      750, 
                                                      AffectEnemies,AffectHeroes,AffectMinions, 
                                                      "") &&
                                                GetCollectionCount(
                                                      out NumberOfEnemiesNearTurret, 
                                                      EnemiesInTurretArea)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestFailure
                              (
                                    QuestActive == true &&
                                    // Sequence name :FailConditions
                                    (
                                          TestUnitCondition(
                                                OrderNexusTurretB, 
                                                False)                                          // Sequence name :TestTurretDefense
                                          (
                                                TurretSecure == true &&
                                                GreaterEqualFloat(
                                                      PlayerDistance, 
                                                      BuildingDefensePlayerCheckRange) &&
                                                NumberOfEnemiesNearTurret == 0
                                          )
                                    ) &&
                                    // Sequence name :FailQuest
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendNexus) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretNexusB)
                                    )
                              ) ||
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          TurretSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearTurret == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Turret_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendNexus) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretNexusB)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousTurretHealth, 
                              CurrentTurretHealth)

                  )
            );
      }
}

