using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DestroyInhibitor : BehaviourTree 
{
      AttackableUnit ChaosTopInhibitor;
      AttackableUnit ChaosMidInhibitor;
      AttackableUnit ChaosBotInhibitor;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosTopRearTurret;
      AttackableUnit ChaosMidRearTurret;
      AttackableUnit ChaosBotRearTurret;
      float QuestDelayTime;

      bool DestroyInhibitor()
      {
      return
            // Sequence name :QuestState-DestroyInhibitor
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        // Sequence name :ValidateQuest
                        (
                              // Sequence name :TestInhibitors
                              (
                                    TestUnitCondition(
                                          ChaosTopInhibitor, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidInhibitor, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotInhibitor, 
                                          False)
                              ) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyNexusTurrets) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyInhibitor)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_inhibitor, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_inhibitor, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Destroy_Inhibitor, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          QuestID, 
                                          true) &&
                                    // Sequence name :PingActiveInhibitors
                                    (
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :Top
                                                (
                                                      TestUnitCondition(
                                                            ChaosTopRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosTopInhibitor, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosTopInhibitor, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :Mid
                                                (
                                                      TestUnitCondition(
                                                            ChaosMidRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosMidInhibitor, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosMidInhibitor, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :Bot
                                                (
                                                      TestUnitCondition(
                                                            ChaosBotRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosBotInhibitor, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosBotInhibitor, 
                                                            False)
                                                )
                                          )
                                    ) &&
                                    DelayNSecondsBlocking(
                                          3)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              // Sequence name :TestInhibitors
                              (
                                    TestUnitCondition(
                                          ChaosTopInhibitor, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidInhibitor, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotInhibitor, 
                                          False)
                              )
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    QuestID, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    QuestDelayTime) &&
                              SetBTInstanceStatus(
                                    true, 
                                    InhibitorReward) &&
                              SetBTInstanceStatus(
                                    true, 
                                    InhibitorRespawn) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyNexusTurrets) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyInhibitor)

                        )
                  )
            );
      }
}

