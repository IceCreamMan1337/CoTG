using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendNexus : BehaviourTree 
{
      AttackableUnit OrderNexus;
      AttackableUnit TutorialPlayer;
      int BuildingSecureTime;
      float BuildingDefensePlayerCheckRange;

      bool DefendNexus()
      {
      return
            // Sequence name :QuestState-DefendNexus
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out NexusPosition, 
                                    OrderNexus) &&
                              GetUnitCurrentHealth(
                                    out CurrentNexusHealth, 
                                    OrderNexus) &&
                              SetVarFloat(
                                    out PreviousNexusHealth, 
                                    CurrentNexusHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderNexus, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendNexus)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderNexus, 
                                    true) &&
                              // Sequence name :TestNexusDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentNexusHealth, 
                                          OrderNexus) &&
                                    LessFloat(
                                          CurrentNexusHealth, 
                                          PreviousNexusHealth)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderNexus, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Nexus_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              TestUnitCondition(
                                    OrderNexus, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestInhibitorHealthOverTime
                                    (
                                          SetVarBool(
                                                out NexusSecure, 
                                                False) &&
                                          GetUnitCurrentHealth(
                                                out CurrentNexusHealth, 
                                                OrderNexus) &&
                                          // Sequence name :UpdateSteadyHealthCount
                                          (
                                                // Sequence name :TestNexusNotDamaged
                                                (
                                                      GreaterEqualFloat(
                                                            CurrentNexusHealth, 
                                                            PreviousNexusHealth) &&
                                                      AddInt(
                                                            out SteadyHealthCount, 
                                                            SteadyHealthCount, 
                                                            1)
                                                ) ||
                                                SetVarInt(
                                                      out SteadyHealthCount, 
                                                      0)
                                          ) &&
                                          SteadyHealthCount == BuildingSecureTime &&
                                          SetVarBool(
                                                out NexusSecure, 
                                                true)
                                    )
                              ) &&
                              DistanceBetweenObjectAndPoint(
                                    out PlayerDistance, 
                                    TutorialPlayer, 
                                    NexusPosition) &&
                              // Sequence name :CountNumberOfEnemiesNearNexus
                              (
                                    GetUnitsInTargetArea(
                                          out EnemiesInNexusArea, 
                                          TutorialPlayer, 
                                          NexusPosition, 
                                          750, 
                                          AffectEnemies,AffectHeroes,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out NumberOfEnemiesNearNexus, 
                                          EnemiesInNexusArea)
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          NexusSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearNexus == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Nexus_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendNexus)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousNexusHealth, 
                              CurrentNexusHealth)

                  )
            );
      }
}

