using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DestroyNexusTurrets : BehaviourTree 
{
      AttackableUnit ChaosNexusTurretA;
      AttackableUnit ChaosNexusTurretB;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      float QuestDelayTime;

      bool DestroyNexusTurrets()
      {
      return
            // Sequence name :QuestState-DestroyNexusTurrets
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        // Sequence name :ValidateQuest
                        (
                              TestUnitCondition(
                                    ChaosNexusTurretA, 
                                    False) &&
                              TestUnitCondition(
                                    ChaosNexusTurretB, 
                                    False) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyNexus) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyNexusTurrets)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_nexus_turrets, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_nexus_turrets, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Nexus_Turrets, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          QuestID, 
                                          true) &&
                                    // Sequence name :PingActiveNexusTurrets
                                    (
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :NexusTurretA
                                                (
                                                      TestUnitCondition(
                                                            ChaosNexusTurretA, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosNexusTurretA, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :NexusTurretB
                                                (
                                                      TestUnitCondition(
                                                            ChaosNexusTurretB, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosNexusTurretB, 
                                                            False)
                                                )
                                          )
                                    ) &&
                                    DelayNSecondsBlocking(
                                          3)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              TestUnitCondition(
                                    ChaosNexusTurretA, 
                                    False) &&
                              TestUnitCondition(
                                    ChaosNexusTurretB, 
                                    False)
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    QuestID, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    QuestDelayTime) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyNexus) &&
                              SetBTInstanceStatus(
                                    False, 
                                    SpendGold) &&
                              SetBTInstanceStatus(
                                    False, 
                                    LowHealthWarning) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyNexusTurrets)

                        )
                  )
            );
      }
}

