using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LowHealthWarning : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      float SafeAreaRange;

      bool LowHealthWarning()
      {
      return
            // Sequence name :TipState-LowHealthWarning
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out ResetTip, 
                              False) &&
                        DelayNSecondsBlocking(
                              2)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitCurrentHealth(
                                    out PlayerHealth, 
                                    TutorialPlayer) &&
                              GetUnitMaxHealth(
                                    out PlayerMaxHealth, 
                                    TutorialPlayer) &&
                              DivideFloat(
                                    out PlayerHealthPercentage, 
                                    PlayerHealth, 
                                    PlayerMaxHealth) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestTipReset
                                    (
                                          ResetTip == true &&
                                          GreaterFloat(
                                                PlayerHealthPercentage, 
                                                0.8) &&
                                          SetVarBool(
                                                out ResetTip, 
                                                False)
                                    )
                              ) &&
                              ResetTip == False &&
                              // Sequence name :TestPlayerHealth
                              (
                                    LessFloat(
                                          PlayerHealthPercentage, 
                                          0.25)
                              ) &&
                              // Sequence name :TestEnemiesNearPlayer
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              ) &&
                              // Sequence name :TestAggroNeutralsNear
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    GetCollectionCount(
                                          out NeutralCount, 
                                          NeutralsNearPlayer) &&
                                    // Sequence name :ConditionOption
                                    (
                                          NeutralCount == 0                                          NeutralsNearPlayer.ForEach( Unit => (
                                                // Sequence name :TestHealth
                                                (
                                                      GetUnitMaxHealth(
                                                            out UnitMaxHealth, 
                                                            Unit) &&
                                                      GetUnitCurrentHealth(
                                                            out UnitHealth, 
                                                            Unit) &&
                                                      UnitHealth == UnitMaxHealth
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_low_health_warning, 
                                    game_advanced_tutorial_tip_dialog_low_health_warning, 
                                    ) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleUIHighlight(
                                    UI_RECALL, 
                                    true) &&
                              PlayVOAudioEvent(
                                    Tip_Low_Health, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_RECALL, 
                              False) &&
                        SetVarBool(
                              out TipActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out ResetTip, 
                              true)

                  )
            );
      }
}

