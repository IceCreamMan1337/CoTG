using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LizardTactics : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;
      bool GlobalTipDialogActive;

      bool LizardTactics()
      {
      return
            // Sequence name :TipState-LizardTactics
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerNearLizardElder
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out PlayerAreaCollection, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          1000, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    PlayerAreaCollection.ForEach( Unit => (
                                          // Sequence name :TestForLizardElder
                                          (
                                                GetUnitSkinName(
                                                      out "SkinName", 
                                                      Unit) &&
                                                "SkinName" == LizardElder &&
                                                // Sequence name :TestLizardElderHealth
                                                (
                                                      GetUnitCurrentHealth(
                                                            out LizardElderHealth, 
                                                            Unit) &&
                                                      GetUnitMaxHealth(
                                                            out LizardElderMaxHealth, 
                                                            Unit) &&
                                                      LessFloat(
                                                            LizardElderHealth, 
                                                            LizardElderMaxHealth)
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_lizard_tactics, 
                                    game_advanced_tutorial_tip_dialog_lizard_tactics, 
                                    DATA/Images/Tips/tipDialogImage_lizardTactics.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Lizard_Tactics, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              LizardTactics)

                  )
            );
      }
}

