using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class FirstSkillPoint : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      Vector3OrderSpawnPlatformPosition;
      AttackableUnit TutorialPlayer;
      bool GlobalTipDialogActive;

      bool FirstSkillPoint()
      {
      return
            // Sequence name :TipState-FirstSkillPoint
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipValid, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerLocation
                              (
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          OrderSpawnPlatformPosition) &&
                                    GreaterFloat(
                                          Distance, 
                                          4000)
                              ) &&
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    // Sequence name :TestValidity
                                    (
                                          PlayerLevel == 1                                          // Sequence name :TipNotValid
                                          (
                                                SetVarBool(
                                                      out TipValid, 
                                                      False) &&
                                                SetBTInstanceStatus(
                                                      False, 
                                                      FirstSkillPoint)
                                          )
                                    )
                              ) &&
                              // Sequence name :TestPlayerSkillPoints
                              (
                                    GetUnitSkillPoints(
                                          out SkillPoints, 
                                          TutorialPlayer) &&
                                    // Sequence name :TestValidity
                                    (
                                          GreaterInt(
                                                SkillPoints, 
                                                0)                                          // Sequence name :TipNotValid
                                          (
                                                SetVarBool(
                                                      out TipValid, 
                                                      False) &&
                                                SetBTInstanceStatus(
                                                      False, 
                                                      FirstSkillPoint)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              TipValid == true &&
                              GlobalTipDialogActive == False &&
                              StopUnitMovement(
                                    TutorialPlayer) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_first_skill_point, 
                                    game_advanced_tutorial_tip_dialog_first_skill_point, 
                                    ) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT1, 
                                    true) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT2, 
                                    true) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT3, 
                                    true) &&
                              PlayVOAudioEvent(
                                    Tip_First_Skill_Point, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT1, 
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT2, 
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT3, 
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              FirstSkillPoint)

                  )
            );
      }
}

