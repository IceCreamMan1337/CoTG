using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class KillFiveMinions : BehaviourTree 
{
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool KillFiveMinions()
      {
      return
            // Sequence name :QuestState-KillFiveMinions
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              // Sequence name :TestPlayerNearEnemyMinion
                              (
                                    GetUnitsInTargetArea(
                                          out EnemyMinionsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          1000, 
                                          AffectEnemies,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyMinionCount, 
                                          EnemyMinionsNearPlayer) &&
                                    GreaterInt(
                                          EnemyMinionCount, 
                                          0)
                              ) &&
                              // Sequence name :TestPlayerNearFriendlyMinion
                              (
                                    GetUnitsInTargetArea(
                                          out FriendlyMinionsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          1000, 
                                          AffectFriends,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyMinionCount, 
                                          FriendlyMinionsNearPlayer) &&
                                    GreaterInt(
                                          FriendlyMinionCount, 
                                          0)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_kill_minions, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_kill_minions, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Slay_Minions, 
                                    Tutorial2, 
                                    true) &&
                              RegisterMinionKillCounter(
                                    out KillCount, 
                                    TutorialPlayer) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :SuccessConditions
                              (
                                    GreaterEqualInt(
                                          KillCount, 
                                          5)
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          100) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          ProximityXP) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          KillFiveMinions)

                              )
                        )
                  )
            );
      }
}

