using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class TurretApproachWarning : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosMidFrontTurret;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      bool GlobalTipDialogActive;

      bool TurretApproachWarning()
      {
      return
            // Sequence name :TipState-TurretApproachWarning
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarInt(
                              out TipActivationCount, 
                              0) &&
                        GetUnitAttackRange(
                              out TurretAttackRange, 
                              ChaosMidFrontTurret) &&
                        AddFloat(
                              out NearTurretDistance, 
                              TurretAttackRange, 
                              250) &&
                        SetVarBool(
                              out PlayerNearTurret, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              GetUnitsInTargetArea(
                                    out EnemyTurretsNearPlayer, 
                                    TutorialPlayer, 
                                    PlayerPosition, 
                                    NearTurretDistance, 
                                    AffectEnemies,AffectTurrets, 
                                    "") &&
                              GetCollectionCount(
                                    out EnemyTurretCount, 
                                    EnemyTurretsNearPlayer) &&
                              // Sequence name :TestPlayerApproachingTurret
                              (
                                    // Sequence name :TestPlayerLocation
                                    (
                                          PlayerNearTurret == False                                          // Sequence name :TestPlayerNotNearTurret
                                          (
                                                EnemyTurretCount == 0 &&
                                                SetVarBool(
                                                      out PlayerNearTurret, 
                                                      False)
                                          )
                                    ) &&
                                    GreaterInt(
                                          EnemyTurretCount, 
                                          0) &&
                                    EnemyTurretsNearPlayer.ForEach( Unit => (                                          SetVarAttackableUnit(
                                                out Turret, 
                                                Unit)
                                    ) &&
                                    GetUnitPosition(
                                          out TurretPosition, 
                                          Turret) &&
                                    SetVarBool(
                                          out PlayerNearTurret, 
                                          true)
                              ) &&
                              // Sequence name :TestTurretHealth
                              (
                                    GetUnitCurrentHealth(
                                          out TurretHealth, 
                                          Turret) &&
                                    GreaterFloat(
                                          TurretHealth, 
                                          200)
                              ) &&
                              // Sequence name :TestFriendlyMinionsAheadOfPlayer
                              (
                                    GetUnitsInTargetArea(
                                          out FriendlyMinionsNearTurret, 
                                          TutorialPlayer, 
                                          TurretPosition, 
                                          NearTurretDistance, 
                                          AffectFriends,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyMinionCount, 
                                          FriendlyMinionsNearTurret) &&
                                    FriendlyMinionCount == 0
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ToggleUnitHighlight(
                                    true, 
                                    Turret) &&
                              StopUnitMovement(
                                    TutorialPlayer) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_turret_approach_warning, 
                                    game_advanced_tutorial_tip_dialog_turret_approach_warning, 
                                    DATA/Images/Tips/tipDialogImage_turretApproachWarning.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Stay_Behind_Minions, 
                                    Tutorial2, 
                                    true) &&
                              AddInt(
                                    out TipActivationCount, 
                                    TipActivationCount, 
                                    1) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUnitHighlight(
                              False, 
                              Turret) &&
                        // Sequence name :CappedRepeat
                        (
                              // Sequence name :TestTipActivationCount
                              (
                                    GreaterEqualInt(
                                          TipActivationCount, 
                                          3) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          TurretApproachWarning)
                              ) ||
                              // Sequence name :ResetTip
                              (
                                    SetVarBool(
                                          out TipDialogActive, 
                                          False) &&
                                    DelayNSecondsBlocking(
                                          10)

                              )
                        )
                  )
            );
      }
}

