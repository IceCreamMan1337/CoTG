using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class ClearingFrontTurrets : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosTopCenterTurret;
      AttackableUnit ChaosTopRearTurret;
      AttackableUnit ChaosMidCenterTurret;
      AttackableUnit ChaosMidRearTurret;
      AttackableUnit ChaosBotCenterTurret;
      AttackableUnit ChaosBotRearTurret;
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit ChaosMidFrontTurret;
      AttackableUnit ChaosBotFrontTurret;
      AttackableUnit TutorialPlayer;
      bool GlobalTipDialogActive;

      bool ClearingFrontTurrets()
      {
      return
            // Sequence name :TipState-ClearingFrontTurrets
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        GetUnitPosition(
                              out ChaosTopCenterTurretPosition, 
                              ChaosTopCenterTurret) &&
                        GetUnitPosition(
                              out ChaosTopRearTurretPosition, 
                              ChaosTopRearTurret) &&
                        GetUnitPosition(
                              out ChaosMidCenterTurretPosition, 
                              ChaosMidCenterTurret) &&
                        GetUnitPosition(
                              out ChaosMidRearTurretPosition, 
                              ChaosMidRearTurret) &&
                        GetUnitPosition(
                              out ChaosBotCenterTurretPosition, 
                              ChaosBotCenterTurret) &&
                        GetUnitPosition(
                              out ChaosBotRearTurretPosition, 
                              ChaosBotRearTurret)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              // Sequence name :TestFrontTurretDestoyed
                              (
                                    TestUnitCondition(
                                          ChaosTopFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotFrontTurret, 
                                          False)
                              ) &&
                              // Sequence name :TestFrontTurretAlive
                              (
                                    TestUnitCondition(
                                          ChaosTopFrontTurret, 
                                          true)                                    TestUnitCondition(
                                          ChaosMidFrontTurret, 
                                          true)                                    TestUnitCondition(
                                          ChaosBotFrontTurret, 
                                          true)
                              ) &&
                              // Sequence name :TestPlayerNearDeepEnemyTurret
                              (
                                    // Sequence name :TopCenter
                                    (
                                          TestUnitCondition(
                                                ChaosTopCenterTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosTopCenterTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    ) ||
                                    // Sequence name :MidCenter
                                    (
                                          TestUnitCondition(
                                                ChaosMidCenterTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosMidCenterTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    ) ||
                                    // Sequence name :BotCenter
                                    (
                                          TestUnitCondition(
                                                ChaosBotCenterTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosBotCenterTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    ) ||
                                    // Sequence name :TopRear
                                    (
                                          TestUnitCondition(
                                                ChaosTopCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosTopRearTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosTopRearTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    ) ||
                                    // Sequence name :MidRear
                                    (
                                          TestUnitCondition(
                                                ChaosMidCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosMidRearTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosMidRearTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    ) ||
                                    // Sequence name :BotRear
                                    (
                                          TestUnitCondition(
                                                ChaosBotCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosBotRearTurret, 
                                                true) &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                ChaosBotRearTurretPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                750)
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_front_turrets, 
                                    game_advanced_tutorial_tip_category_pushing) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_front_turrets, 
                              game_advanced_tutorial_tip_dialog_front_turrets, 
                              DATA/Images/Tips/tipDialogImage_clearingFrontTurrets.dds) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        PlayVOAudioEvent(
                              Tip_Clear_Front_Turrets, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              ClearingFrontTurrets)

                  )
            );
      }
}

