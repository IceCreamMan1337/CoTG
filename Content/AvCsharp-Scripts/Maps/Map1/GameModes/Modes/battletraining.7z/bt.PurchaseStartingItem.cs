using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class PurchaseStartingItem : BehaviourTree 
{
      AttackableUnit TutorialPlayer;
      Vector3OrderShopPosition;

      bool PurchaseStartingItem()
      {
      return
            // Sequence name :QuestState-PurchaseStartingItem
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_starting_item, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_starting_item, 
                                    "") &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestQuestClicked
                                    (
                                          TestQuestClicked(
                                                QuestID, 
                                                true) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                OrderShopPosition, 
                                                False) &&
                                          DelayNSecondsBlocking(
                                                3)
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    GetNumberOfInventorySlotsFilled(
                                          out NumPlayerItems, 
                                          TutorialPlayer) &&
                                    GreaterInt(
                                          NumPlayerItems, 
                                          0)
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          50) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          PurchaseStartingItem)

                              )
                        )
                  )
            );
      }
}

