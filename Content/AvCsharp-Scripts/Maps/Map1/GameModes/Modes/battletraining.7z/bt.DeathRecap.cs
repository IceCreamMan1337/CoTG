using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DeathRecap : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool DeathRecap()
      {
      return
            // Sequence name :TipState-DeathRecap
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    False) &&
                              GetChampionDeaths(
                                    out PlayerDeaths, 
                                    TutorialPlayer) &&
                              GreaterInt(
                                    PlayerDeaths, 
                                    1)
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_death_recap, 
                                    game_advanced_tutorial_tip_category_user_interface) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_death_recap, 
                              game_advanced_tutorial_tip_dialog_death_recap, 
                              ) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        PlayVOAudioEvent(
                              Tip_Death_Recap, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              true, 
                              ShopWhileDead) &&
                        SetBTInstanceStatus(
                              False, 
                              DeathRecap)

                  )
            );
      }
}

