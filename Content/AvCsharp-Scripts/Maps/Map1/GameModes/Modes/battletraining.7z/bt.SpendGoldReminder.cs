using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class SpendGoldReminder : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      Vector3OrderSpawnPlatformPosition;
      float SafeAreaRange;
      bool GlobalTipDialogActive;

      bool SpendGoldReminder()
      {
      return
            // Sequence name :TipState-SpendGoldReminder
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out ResetTip, 
                              False) &&
                        SetVarBool(
                              out VisitedSpawnPlatform, 
                              False) &&
                        SetVarFloat(
                              out LowLevelGoldThreshold, 
                              800) &&
                        SetVarFloat(
                              out MidLevelGoldThreshold, 
                              1400) &&
                        SetVarFloat(
                              out HighLevelGoldThreshold, 
                              2000)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              GetUnitLevel(
                                    out PlayerLevel, 
                                    TutorialPlayer) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitGold(
                                    out PlayerGold, 
                                    TutorialPlayer) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestTipReset
                                    (
                                          ResetTip == true &&
                                          // Sequence name :TierCheck
                                          (
                                                // Sequence name :LowLevel
                                                (
                                                      LessEqualInt(
                                                            PlayerLevel, 
                                                            5) &&
                                                      LessFloat(
                                                            PlayerGold, 
                                                            LowLevelGoldThreshold)
                                                ) ||
                                                // Sequence name :MidLevel
                                                (
                                                      GreaterInt(
                                                            PlayerLevel, 
                                                            5) &&
                                                      LessInt(
                                                            PlayerLevel, 
                                                            11) &&
                                                      LessFloat(
                                                            PlayerGold, 
                                                            MidLevelGoldThreshold)
                                                ) ||
                                                // Sequence name :MidLevel
                                                (
                                                      GreaterEqualInt(
                                                            PlayerLevel, 
                                                            11) &&
                                                      LessFloat(
                                                            PlayerGold, 
                                                            HighLevelGoldThreshold)
                                                )
                                          ) &&
                                          SetVarBool(
                                                out ResetTip, 
                                                False) &&
                                          SetVarBool(
                                                out VisitedSpawnPlatform, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :TestPlayerVisitBase
                              (
                                    ResetTip == False &&
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          OrderSpawnPlatformPosition) &&
                                    // Sequence name :TestPlayerVisitSummonerPlatform
                                    (
                                          VisitedSpawnPlatform == true                                          // Sequence name :TestPlayerNearSummonerPlatform
                                          (
                                                LessFloat(
                                                      Distance, 
                                                      600) &&
                                                SetVarBool(
                                                      out VisitedSpawnPlatform, 
                                                      true)
                                          )
                                    ) &&
                                    GreaterFloat(
                                          Distance, 
                                          1200) &&
                                    SetVarBool(
                                          out VisitedSpawnPlatform, 
                                          False)
                              ) &&
                              // Sequence name :TestPlayerGold
                              (
                                    // Sequence name :TierCheck
                                    (
                                          // Sequence name :LowLevel
                                          (
                                                LessEqualInt(
                                                      PlayerLevel, 
                                                      5) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      LowLevelGoldThreshold)
                                          ) ||
                                          // Sequence name :MidLevel
                                          (
                                                GreaterInt(
                                                      PlayerLevel, 
                                                      5) &&
                                                LessInt(
                                                      PlayerLevel, 
                                                      11) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      MidLevelGoldThreshold)
                                          ) ||
                                          // Sequence name :MidLevel
                                          (
                                                GreaterEqualInt(
                                                      PlayerLevel, 
                                                      11) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      HighLevelGoldThreshold)
                                          )
                                    )
                              ) &&
                              // Sequence name :TestEnemiesNearPlayer
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              StopUnitMovement(
                                    TutorialPlayer) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_spend_gold_reminder, 
                                    game_advanced_tutorial_tip_dialog_spend_gold_reminder, 
                                    ) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleUIHighlight(
                                    UI_GOLD, 
                                    true) &&
                              PlayVOAudioEvent(
                                    Tip_Spend_Gold, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetVarBool(
                              out TipActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out VisitedSpawnPlatform, 
                              False) &&
                        ToggleUIHighlight(
                              UI_GOLD, 
                              False) &&
                        SetVarBool(
                              out ResetTip, 
                              true)

                  )
            );
      }
}

