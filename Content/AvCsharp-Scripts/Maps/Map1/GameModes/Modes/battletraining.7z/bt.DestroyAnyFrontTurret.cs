using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DestroyAnyFrontTurret : BehaviourTree 
{
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit ChaosMidFrontTurret;
      AttackableUnit ChaosBotFrontTurret;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      float QuestDelayTime;

      bool DestroyAnyFrontTurret()
      {
      return
            // Sequence name :QuestState-DestroyAnyFrontTurret
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        // Sequence name :ValidateQuest
                        (
                              // Sequence name :TestChaosFrontTurrets
                              (
                                    TestUnitCondition(
                                          ChaosTopFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotFrontTurret, 
                                          False)
                              ) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyAllTurretsInLane) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DangerousPush) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyAnyFrontTurret)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_front_turret, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_front_turret, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Destroy_Turret, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          QuestID, 
                                          true) &&
                                    // Sequence name :PingActiveChaosFrontTurrets
                                    (
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TopFrontTurret
                                                (
                                                      TestUnitCondition(
                                                            ChaosTopFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosTopFrontTurret, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :MidFrontTurret
                                                (
                                                      TestUnitCondition(
                                                            ChaosMidFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosMidFrontTurret, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :BotFrontTurret
                                                (
                                                      TestUnitCondition(
                                                            ChaosBotFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosBotFrontTurret, 
                                                            False)
                                                )
                                          )
                                    ) &&
                                    DelayNSecondsBlocking(
                                          3)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              // Sequence name :TestTurrets
                              (
                                    TestUnitCondition(
                                          ChaosTopFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotFrontTurret, 
                                          False)
                              )
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    QuestID, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    QuestDelayTime) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyAllTurretsInLane) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DangerousPush) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyAnyFrontTurret)

                        )
                  )
            );
      }
}

