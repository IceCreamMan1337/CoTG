using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class SpendGold : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;
      Vector3OrderSpawnPlatformPosition;
      float SafeAreaRange;
      bool GlobalTipDialogActive;

      bool SpendGold()
      {
      return
            // Sequence name :TipState-SpendGold
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out QuestCanFire, 
                              true) &&
                        SetVarBool(
                              out Poor, 
                              true)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerGold
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    GetUnitGold(
                                          out PlayerGold, 
                                          TutorialPlayer) &&
                                    // Sequence name :TierCheck
                                    (
                                          // Sequence name :LowLevel
                                          (
                                                LessEqualInt(
                                                      PlayerLevel, 
                                                      5) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      1500) &&
                                                SetVarBool(
                                                      out Poor, 
                                                      False)
                                          ) ||
                                          // Sequence name :MidLevel
                                          (
                                                GreaterInt(
                                                      PlayerLevel, 
                                                      5) &&
                                                LessInt(
                                                      PlayerLevel, 
                                                      11) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      2000) &&
                                                SetVarBool(
                                                      out Poor, 
                                                      False)
                                          ) ||
                                          // Sequence name :HighLevel
                                          (
                                                GreaterEqualInt(
                                                      PlayerLevel, 
                                                      11) &&
                                                GreaterEqualFloat(
                                                      PlayerGold, 
                                                      2500) &&
                                                SetVarBool(
                                                      out Poor, 
                                                      False)
                                          ) ||
                                          // Sequence name :Sequence
                                          (
                                                SetVarBool(
                                                      out Poor, 
                                                      true) &&
                                                SetVarBool(
                                                      out QuestCanFire, 
                                                      true)
                                          )
                                    )
                              ) &&
                              Poor == False &&
                              QuestCanFire == true &&
                              // Sequence name :TestPlayerLocation
                              (
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          OrderSpawnPlatformPosition) &&
                                    GreaterFloat(
                                          Distance, 
                                          6000)
                              ) &&
                              // Sequence name :TestEnemiesNear
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              ) &&
                              // Sequence name :TestAggroNeutralsNear
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    GetCollectionCount(
                                          out NeutralCount, 
                                          NeutralsNearPlayer) &&
                                    // Sequence name :ConditionOption
                                    (
                                          NeutralCount == 0                                          NeutralsNearPlayer.ForEach( Unit => (
                                                // Sequence name :TestHealth
                                                (
                                                      GetUnitMaxHealth(
                                                            out UnitMaxHealth, 
                                                            Unit) &&
                                                      GetUnitCurrentHealth(
                                                            out UnitHealth, 
                                                            Unit) &&
                                                      UnitHealth == UnitMaxHealth
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_spend_gold, 
                                    game_advanced_tutorial_tip_dialog_spend_gold, 
                                    DATA/Images/Tips/tipDialogImage_spendGold.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleUIHighlight(
                                    UI_GOLD, 
                                    true) &&
                              ToggleUIHighlight(
                                    UI_RECALL, 
                                    true) &&
                              PlayVOAudioEvent(
                                    Tip_High_Gold, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out QuestCanFire, 
                              False) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_GOLD, 
                              False) &&
                        ToggleUIHighlight(
                              UI_RECALL, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)

                  )
            );
      }
}

