using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class ShopWhileDead : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool ShopWhileDead()
      {
      return
            // Sequence name :TipState-ShopWhileDead
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    False) &&
                              GetChampionDeaths(
                                    out PlayerDeaths, 
                                    TutorialPlayer) &&
                              GreaterInt(
                                    PlayerDeaths, 
                                    2)
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_shop_while_dead, 
                                    game_advanced_tutorial_tip_category_items) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_shop_while_dead, 
                              game_advanced_tutorial_tip_dialog_shop_while_dead, 
                              ) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        ToggleUIHighlight(
                              UI_SHOP, 
                              true) &&
                        PlayVOAudioEvent(
                              Tip_Shop_While_Dead, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_SHOP, 
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              ShopWhileDead)

                  )
            );
      }
}

