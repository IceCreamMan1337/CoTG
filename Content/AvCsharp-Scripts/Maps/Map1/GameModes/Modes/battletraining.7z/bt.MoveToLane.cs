using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class MoveToLane : BehaviourTree 
{
      out int MoveToLaneQuestID;
      out float MinionSpawnStartTime;
      AttackableUnit TutorialPlayer;
      int MoveToLaneQuestID;
      Vector3OrderSpawnPlatformPosition;
      float QuestDelayTime;

      bool MoveToLane()
      {
      return
            // Sequence name :QuestState-MoveToLane
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        MakeVector(
                              out TopRunwayStartPosition, 
                              452, 
                              100, 
                              1300) &&
                        MakeVector(
                              out MidRunwayStartPosition, 
                              746, 
                              107, 
                              1045) &&
                        MakeVector(
                              out BotRunwayStartPosition, 
                              1041, 
                              101, 
                              691) &&
                        MakeVector(
                              out TopLanePosition, 
                              815, 
                              48, 
                              5364) &&
                        MakeVector(
                              out MidLanePosition, 
                              4070, 
                              44, 
                              4470) &&
                        MakeVector(
                              out BotLanePosition, 
                              5200, 
                              44, 
                              990) &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out MoveToLaneQuestID, 
                                    game_advanced_tutorial_quest_name_move_to_lane, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_move_to_lane, 
                                    "") &&
                              SetVarBool(
                                    out QuestActive, 
                                    true) &&
                              SetVarBool(
                                    out RunwayActivated, 
                                    False)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :Sequence
                              (
                                    RunwayActivated == False &&
                                    GetNumberOfInventorySlotsFilled(
                                          out PlayerItems, 
                                          TutorialPlayer) &&
                                    GreaterInt(
                                          PlayerItems, 
                                          0) &&
                                    CreatePositionParticle(
                                          out TopLaneRunwayID, 
                                          out , 
                                          TopRunwayStartPosition, 
                                          tutorial_runway_arrows.troy, 
                                          "", 
                                          , 
                                          "", 
                                          TopLanePosition, 
                                          TopLanePosition, 
                                          , 
                                          , 
                                          0, 
                                          , 
                                          False, 
                                          False) &&
                                    CreatePositionParticle(
                                          out MidLaneRunwayID, 
                                          out , 
                                          MidRunwayStartPosition, 
                                          tutorial_runway_arrows.troy, 
                                          "", 
                                          , 
                                          "", 
                                          MidLanePosition, 
                                          MidLanePosition, 
                                          , 
                                          , 
                                          0, 
                                          , 
                                          False, 
                                          False) &&
                                    CreatePositionParticle(
                                          out BotLaneRunwayID, 
                                          out , 
                                          BotRunwayStartPosition, 
                                          tutorial_runway_arrows.troy, 
                                          "", 
                                          , 
                                          "", 
                                          BotLanePosition, 
                                          BotLanePosition, 
                                          , 
                                          , 
                                          0, 
                                          , 
                                          False, 
                                          False) &&
                                    SetVarBool(
                                          out RunwayActivated, 
                                          true)
                              )
                        ) &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          MoveToLaneQuestID, 
                                          true) &&
                                    // Sequence name :PingActiveChaosFrontTurrets
                                    (
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                TopLanePosition, 
                                                False) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                MidLanePosition, 
                                                False) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                BotLanePosition, 
                                                False)
                                    ) &&
                                    DelayNSecondsBlocking(
                                          3)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              DistanceBetweenObjectAndPoint(
                                    out Distance, 
                                    TutorialPlayer, 
                                    OrderSpawnPlatformPosition) &&
                              GreaterFloat(
                                    Distance, 
                                    5000)
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    MoveToLaneQuestID, 
                                    true) &&
                              SetBarrackStatus(
                                    true) &&
                              SetNeutralSpawnEnabled(
                                    true) &&
                              GetChampionCollection(
                                    out ChampionCollection, 
                                    out ChampionCollection) &&
                              ChampionCollection.ForEach( Unit => (                                    SetStateDisableAmbientGold(
                                          Unit, 
                                          False)
                              ) &&
                              GetGameTime(
                                    out MinionSpawnStartTime, 
                                    out MinionSpawnStartTime) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :RemoveRunways
                                    (
                                          RunwayActivated == true &&
                                          RemoveParticle(
                                                TopLaneRunwayID) &&
                                          RemoveParticle(
                                                MidLaneRunwayID) &&
                                          RemoveParticle(
                                                BotLaneRunwayID) &&
                                          SetVarBool(
                                                out RunwayActivated, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :EnableQuests
                              (
                                    SetBTInstanceStatus(
                                          true, 
                                          KillFiveMinions) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          BuyBoots) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefeatWolves) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefeatWraiths) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefeatAncientGolem) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefeatLizardElder) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefeatDragon)
                              ) &&
                              // Sequence name :EnableTips
                              (
                                    SetBTInstanceStatus(
                                          true, 
                                          LaneNames) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          Brush) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          TurretApproachWarning) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          LowMinionCount) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          TurretTargeting) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          BaronNashor) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          ClearingFrontTurrets) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          Scoreboard) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          PassiveAbility) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          Buffs) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          Chat)
                              ) &&
                              DelayNSecondsBlocking(
                                    QuestDelayTime) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyAnyFrontTurret) &&
                              SetBTInstanceStatus(
                                    False, 
                                    MoveToLane)

                        )
                  )
            );
      }
}

