using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class BotLevelManager : BehaviourTree 
{
      AttackableUnit TutorialPlayer;

      bool BotLevelManager()
      {
      return
            // Sequence name :State-BotLevelManager
            (
                  // Sequence name :InitializeManager
                  (
                        __IsFirstRun == true &&
                        SetVarInt(
                              out PreviousPlayerLevel, 
                              0)
                  ) ||
                  // Sequence name :TestPlayerLevel
                  (
                        TestUnitCondition(
                              TutorialPlayer, 
                              true) &&
                        GetUnitLevel(
                              out PlayerLevel, 
                              TutorialPlayer) &&
                        GreaterInt(
                              PlayerLevel, 
                              PreviousPlayerLevel) &&
                        GetChampionCollection(
                              out ChampionCollection, 
                              out ChampionCollection) &&
                        ChampionCollection.ForEach( Unit => (                              // Sequence name :TestForBot
                              (
                                    NotEqualUnit(
                                          Unit, 
                                          TutorialPlayer) &&
                                    SetUnitLevelCap(
                                          Unit, 
                                          PlayerLevel)
                              )
                        ) &&
                        SetVarInt(
                              out PreviousPlayerLevel, 
                              PlayerLevel)

                  )
            );
      }
}

