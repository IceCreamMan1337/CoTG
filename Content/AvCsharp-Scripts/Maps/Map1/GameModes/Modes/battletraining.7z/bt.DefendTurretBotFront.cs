using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendTurretBotFront : BehaviourTree 
{
      AttackableUnit OrderBotFrontTurret;
      AttackableUnit TutorialPlayer;
      float BuildingDefenseAllyCheckRange;
      float BuildingDefensePlayerCheckRange;
      int BuildingSecureTime;

      bool DefendTurretBotFront()
      {
      return
            // Sequence name :QuestState-DefendTurretBotFront
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out TurretPosition, 
                                    OrderBotFrontTurret) &&
                              GetUnitCurrentHealth(
                                    out CurrentTurretHealth, 
                                    OrderBotFrontTurret) &&
                              SetVarFloat(
                                    out PreviousTurretHealth, 
                                    CurrentTurretHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderBotFrontTurret, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendTurretBotCenter) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendTurretBotFront)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderBotFrontTurret, 
                                    true) &&
                              // Sequence name :TestTurretDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentTurretHealth, 
                                          OrderBotFrontTurret) &&
                                    LessFloat(
                                          CurrentTurretHealth, 
                                          PreviousTurretHealth)
                              ) &&
                              // Sequence name :TestFriendlyUnitsNear
                              (
                                    GetUnitsInTargetArea(
                                          out TurretArea, 
                                          TutorialPlayer, 
                                          TurretPosition, 
                                          BuildingDefenseAllyCheckRange, 
                                          AffectFriends,AffectHeroes,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyUnitsNearTurret, 
                                          TurretArea) &&
                                    LessInt(
                                          FriendlyUnitsNearTurret, 
                                          1)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderBotFrontTurret, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Turret_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :UpdateReferences
                                    (
                                          TestUnitCondition(
                                                OrderBotFrontTurret, 
                                                true) &&
                                          DelayNSecondsBlocking(
                                                1) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestTurretHealthOverTime
                                                (
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            False) &&
                                                      GetUnitCurrentHealth(
                                                            out CurrentTurretHealth, 
                                                            OrderBotFrontTurret) &&
                                                      // Sequence name :UpdateSteadyHealthCount
                                                      (
                                                            // Sequence name :TestTurretNotDamaged
                                                            (
                                                                  GreaterEqualFloat(
                                                                        CurrentTurretHealth, 
                                                                        PreviousTurretHealth) &&
                                                                  AddInt(
                                                                        out SteadyHealthCount, 
                                                                        SteadyHealthCount, 
                                                                        1)
                                                            ) ||
                                                            SetVarInt(
                                                                  out SteadyHealthCount, 
                                                                  0)
                                                      ) &&
                                                      SteadyHealthCount == BuildingSecureTime &&
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            true)
                                                )
                                          ) &&
                                          DistanceBetweenObjectAndPoint(
                                                out PlayerDistance, 
                                                TutorialPlayer, 
                                                TurretPosition) &&
                                          // Sequence name :CountNumberOfEnemiesNearTurret
                                          (
                                                GetUnitsInTargetArea(
                                                      out EnemiesInTurretArea, 
                                                      TutorialPlayer, 
                                                      TurretPosition, 
                                                      750, 
                                                      AffectEnemies,AffectHeroes,AffectMinions, 
                                                      "") &&
                                                GetCollectionCount(
                                                      out NumberOfEnemiesNearTurret, 
                                                      EnemiesInTurretArea)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestFailure
                              (
                                    QuestActive == true &&
                                    // Sequence name :FailConditions
                                    (
                                          TestUnitCondition(
                                                OrderBotFrontTurret, 
                                                False)                                          // Sequence name :TestTurretDefense
                                          (
                                                TurretSecure == true &&
                                                GreaterEqualFloat(
                                                      PlayerDistance, 
                                                      BuildingDefensePlayerCheckRange) &&
                                                NumberOfEnemiesNearTurret == 0
                                          )
                                    ) &&
                                    // Sequence name :FailQuest
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretBotCenter) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretBotFront)
                                    )
                              ) ||
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          TurretSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearTurret == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Turret_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretBotCenter) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretBotFront)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousTurretHealth, 
                              CurrentTurretHealth)

                  )
            );
      }
}

