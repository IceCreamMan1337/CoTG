using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendInhibitorTop : BehaviourTree 
{
      AttackableUnit OrderTopInhibitor;
      AttackableUnit TutorialPlayer;
      int BuildingSecureTime;
      float BuildingDefensePlayerCheckRange;

      bool DefendInhibitorTop()
      {
      return
            // Sequence name :QuestState-DefendInhibitorTop
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out InhibitorPosition, 
                                    OrderTopInhibitor) &&
                              GetUnitCurrentHealth(
                                    out CurrentInhibitorHealth, 
                                    OrderTopInhibitor) &&
                              SetVarFloat(
                                    out PreviousInhibitorHealth, 
                                    CurrentInhibitorHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderTopInhibitor, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendTurretNexusA) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendTurretNexusB) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendInhibitorTop)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderTopInhibitor, 
                                    true) &&
                              // Sequence name :TestInhibitorDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentInhibitorHealth, 
                                          OrderTopInhibitor) &&
                                    LessFloat(
                                          CurrentInhibitorHealth, 
                                          PreviousInhibitorHealth)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderTopInhibitor, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Inhibitor_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :UpdateReferences
                                    (
                                          TestUnitCondition(
                                                OrderTopInhibitor, 
                                                true) &&
                                          DelayNSecondsBlocking(
                                                1) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestInhibitorHealthOverTime
                                                (
                                                      SetVarBool(
                                                            out InhibitorSecure, 
                                                            False) &&
                                                      GetUnitCurrentHealth(
                                                            out CurrentInhibitorHealth, 
                                                            OrderTopInhibitor) &&
                                                      // Sequence name :UpdateSteadyHealthCount
                                                      (
                                                            // Sequence name :TestInhibitorNotDamaged
                                                            (
                                                                  GreaterEqualFloat(
                                                                        CurrentInhibitorHealth, 
                                                                        PreviousInhibitorHealth) &&
                                                                  AddInt(
                                                                        out SteadyHealthCount, 
                                                                        SteadyHealthCount, 
                                                                        1)
                                                            ) ||
                                                            SetVarInt(
                                                                  out SteadyHealthCount, 
                                                                  0)
                                                      ) &&
                                                      SteadyHealthCount == BuildingSecureTime &&
                                                      SetVarBool(
                                                            out InhibitorSecure, 
                                                            true)
                                                )
                                          ) &&
                                          DistanceBetweenObjectAndPoint(
                                                out PlayerDistance, 
                                                TutorialPlayer, 
                                                InhibitorPosition) &&
                                          // Sequence name :CountNumberOfEnemiesNearInhibitor
                                          (
                                                GetUnitsInTargetArea(
                                                      out EnemiesInInhibitorArea, 
                                                      TutorialPlayer, 
                                                      InhibitorPosition, 
                                                      750, 
                                                      AffectEnemies,AffectHeroes,AffectMinions, 
                                                      "") &&
                                                GetCollectionCount(
                                                      out NumberOfEnemiesNearInhibitor, 
                                                      EnemiesInInhibitorArea)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestFailure
                              (
                                    QuestActive == true &&
                                    // Sequence name :FailConditions
                                    (
                                          TestUnitCondition(
                                                OrderTopInhibitor, 
                                                False)                                          // Sequence name :TestInhibitorDefense
                                          (
                                                InhibitorSecure == true &&
                                                GreaterEqualFloat(
                                                      PlayerDistance, 
                                                      BuildingDefensePlayerCheckRange) &&
                                                NumberOfEnemiesNearInhibitor == 0
                                          )
                                    ) &&
                                    // Sequence name :FailQuest
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretNexusA) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretNexusB) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendInhibitorTop)
                                    )
                              ) ||
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          InhibitorSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearInhibitor == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Inhibitor_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretNexusA) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretNexusB) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendInhibitorTop)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousInhibitorHealth, 
                              CurrentInhibitorHealth)

                  )
            );
      }
}

