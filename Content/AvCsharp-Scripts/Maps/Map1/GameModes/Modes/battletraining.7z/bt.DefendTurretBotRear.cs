using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendTurretBotRear : BehaviourTree 
{
      float BuildingDefensePlayerCheckRange;
      int BuildingSecureTime;
      AttackableUnit TutorialPlayer;
      AttackableUnit OrderBotRearTurret;

      bool DefendTurretBotRear()
      {
      return
            // Sequence name :QuestState-DefendTurretBotRear
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out TurretPosition, 
                                    OrderBotRearTurret) &&
                              GetUnitCurrentHealth(
                                    out CurrentTurretHealth, 
                                    OrderBotRearTurret) &&
                              SetVarFloat(
                                    out PreviousTurretHealth, 
                                    CurrentTurretHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderBotRearTurret, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendInhibitorBot) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendTurretBotRear)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderBotRearTurret, 
                                    true) &&
                              // Sequence name :TestTurretDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentTurretHealth, 
                                          OrderBotRearTurret) &&
                                    LessFloat(
                                          CurrentTurretHealth, 
                                          PreviousTurretHealth)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderBotRearTurret, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Base_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :UpdateReferences
                                    (
                                          TestUnitCondition(
                                                OrderBotRearTurret, 
                                                true) &&
                                          DelayNSecondsBlocking(
                                                1) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestTurretHealthOverTime
                                                (
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            False) &&
                                                      GetUnitCurrentHealth(
                                                            out CurrentTurretHealth, 
                                                            OrderBotRearTurret) &&
                                                      // Sequence name :UpdateSteadyHealthCount
                                                      (
                                                            // Sequence name :TestTurretNotDamaged
                                                            (
                                                                  GreaterEqualFloat(
                                                                        CurrentTurretHealth, 
                                                                        PreviousTurretHealth) &&
                                                                  AddInt(
                                                                        out SteadyHealthCount, 
                                                                        SteadyHealthCount, 
                                                                        1)
                                                            ) ||
                                                            SetVarInt(
                                                                  out SteadyHealthCount, 
                                                                  0)
                                                      ) &&
                                                      SteadyHealthCount == BuildingSecureTime &&
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            true)
                                                )
                                          ) &&
                                          DistanceBetweenObjectAndPoint(
                                                out PlayerDistance, 
                                                TutorialPlayer, 
                                                TurretPosition) &&
                                          // Sequence name :CountNumberOfEnemiesNearTurret
                                          (
                                                GetUnitsInTargetArea(
                                                      out EnemiesInTurretArea, 
                                                      TutorialPlayer, 
                                                      TurretPosition, 
                                                      750, 
                                                      AffectEnemies,AffectHeroes,AffectMinions, 
                                                      "") &&
                                                GetCollectionCount(
                                                      out NumberOfEnemiesNearTurret, 
                                                      EnemiesInTurretArea)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestFailure
                              (
                                    QuestActive == true &&
                                    // Sequence name :FailConditions
                                    (
                                          TestUnitCondition(
                                                OrderBotRearTurret, 
                                                False)                                          // Sequence name :TestTurretDefense
                                          (
                                                TurretSecure == true &&
                                                GreaterEqualFloat(
                                                      PlayerDistance, 
                                                      BuildingDefensePlayerCheckRange) &&
                                                NumberOfEnemiesNearTurret == 0
                                          )
                                    ) &&
                                    // Sequence name :FailQuest
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendInhibitorBot) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretBotRear)
                                    )
                              ) ||
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          TurretSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearTurret == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Turret_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendInhibitorBot) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretBotRear)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousTurretHealth, 
                              CurrentTurretHealth)

                  )
            );
      }
}

