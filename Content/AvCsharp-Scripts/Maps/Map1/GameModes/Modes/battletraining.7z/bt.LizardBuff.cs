using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LizardBuff : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool LizardBuff()
      {
      return
            // Sequence name :TipState-LizardBuff
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitHasBuff(
                                    TutorialPlayer, 
                                    , 
                                    BlessingoftheLizardElder, 
                                    true)
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              DelayNSecondsBlocking(
                                    1) &&
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_lizard_buff, 
                                    game_advanced_tutorial_tip_category_jungling) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_lizard_buff, 
                              game_advanced_tutorial_tip_dialog_lizard_buff, 
                              DATA/Images/Tips/tipDialogImage_lizardBuff.dds) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        PlayVOAudioEvent(
                              General_Excellent, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              LizardBuff)

                  )
            );
      }
}

