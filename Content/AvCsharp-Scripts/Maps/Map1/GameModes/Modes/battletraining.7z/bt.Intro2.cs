using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class Intro2 : BehaviourTree 
{
      int FirstPrimaryQuestID;
      int FirstSecondaryQuestID;
      int ViewQuestTooltipQuestID;
      AttackableUnit TutorialPlayer;

      bool Intro2()
      {
      return
            // Sequence name :TipState-Intro2
            (
                  // Sequence name :Initialize
                  (
                        __IsFirstRun == true &&
                        GetGameTime(
                              out TimeMark, 
                              out TimeMark) &&
                        SetVarFloat(
                              out IdleTimeThreshold, 
                              15)
                  ) ||
                  // Sequence name :TestQuestRollover
                  (
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestIdleTime
                              (
                                    GetGameTime(
                                          out GameTime, 
                                          out GameTime) &&
                                    SubtractFloat(
                                          out IdleTime, 
                                          GameTime, 
                                          TimeMark) &&
                                    GreaterFloat(
                                          IdleTime, 
                                          IdleTimeThreshold) &&
                                    ToggleUIHighlight(
                                          UI_QUESTS, 
                                          true) &&
                                    PlayVOAudioEvent(
                                          Intro_Quest_Tracker, 
                                          Tutorial2, 
                                          true) &&
                                    AddFloat(
                                          out TimeMark, 
                                          TimeMark, 
                                          IdleTimeThreshold)
                              )
                        ) &&
                        // Sequence name :HasEitherQuestBeenRolledOver
                        (
                              TestQuestRolledOver(
                                    FirstPrimaryQuestID, 
                                    true)                              TestQuestRolledOver(
                                    FirstSecondaryQuestID, 
                                    true)                              TestQuestRolledOver(
                                    ViewQuestTooltipQuestID, 
                                    true)
                        ) &&
                        ToggleUIHighlight(
                              UI_QUESTS, 
                              False) &&
                        PlayVOAudioEvent(
                              General_Well_Done, 
                              Tutorial2, 
                              False) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        // Sequence name :TipsMessage
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    Intro3) &&
                              EnableTipEvents(
                                    TutorialPlayer) &&
                              PlayVOAudioEvent(
                                    Intro_Tips, 
                                    Tutorial2, 
                                    true)
                        ) &&
                        SetBTInstanceStatus(
                              False, 
                              Intro2)

                  )
            );
      }
}

