using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class UseRecallSpell : BehaviourTree 
{
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      Vector3OrderSpawnPlatformPosition;

      bool UseRecallSpell()
      {
      return
            // Sequence name :QuestState-UseRecallSpell
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              // Sequence name :TestPlayerHealth
                              (
                                    GetUnitCurrentHealth(
                                          out PlayerHealth, 
                                          TutorialPlayer) &&
                                    GetUnitMaxHealth(
                                          out PlayerMaxHealth, 
                                          TutorialPlayer) &&
                                    DivideFloat(
                                          out PlayerHealthPercent, 
                                          PlayerHealth, 
                                          PlayerMaxHealth) &&
                                    LessEqualFloat(
                                          PlayerHealthPercent, 
                                          0.5)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_recall, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_recall, 
                                    "") &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Quest_Recall, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true) &&
                              SetVarBool(
                                    out QuestRolledOver, 
                                    False) &&
                              SetBTInstanceStatus(
                                    true, 
                                    LowHealthWarning)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestFailure
                        (
                              QuestActive == true &&
                              // Sequence name :FailureConditions
                              (
                                    TestUnitCondition(
                                          TutorialPlayer, 
                                          False)
                              ) &&
                              // Sequence name :FailQuest
                              (
                                    RemoveQuest(
                                          QuestID) &&
                                    ToggleUIHighlight(
                                          UI_RECALL, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          UseRecallSpell)
                              )
                        ) ||
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :HandleQuestRollOver
                                    (
                                          // Sequence name :TestQuestRollOver
                                          (
                                                QuestRolledOver == False &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      true) &&
                                                ToggleUIHighlight(
                                                      UI_RECALL, 
                                                      true) &&
                                                DelayNSecondsBlocking(
                                                      2) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      true)
                                          ) ||
                                          // Sequence name :QuestNotRolledOver
                                          (
                                                QuestRolledOver == true &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      False) &&
                                                ToggleUIHighlight(
                                                      UI_RECALL, 
                                                      False) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      False)
                                          )
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    // Sequence name :TestPlayerOnSpawnPlatform
                                    (
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderSpawnPlatformPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                500)
                                    )
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    ToggleUIHighlight(
                                          UI_RECALL, 
                                          False) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          100) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          UseRecallSpell)

                              )
                        )
                  )
            );
      }
}

