using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class UltimateAbilities : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;
      bool GlobalTipDialogActive;
      String PlayerSkin;

      bool UltimateAbilities()
      {
      return
            // Sequence name :TipState-UltimateAbilities
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    GreaterEqualInt(
                                          PlayerLevel, 
                                          6)
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              // Sequence name :ChampionOption
                              (
                                    // Sequence name :TestForAshe
                                    (
                                          "PlayerSkin" == Bowmaster &&
                                          ActivateTipDialogue(
                                                out TipDialogID, 
                                                TutorialPlayer, 
                                                game_advanced_tutorial_tip_name_ultimate_ability, 
                                                game_advanced_tutorial_tip_dialog_ultimate_ability_ashe, 
                                                DATA/Images/Tips/tipDialogImage_ultimateAbilityAshe.dds)
                                    ) ||
                                    // Sequence name :TestForGaren
                                    (
                                          "PlayerSkin" == Garen &&
                                          ActivateTipDialogue(
                                                out TipDialogID, 
                                                TutorialPlayer, 
                                                game_advanced_tutorial_tip_name_ultimate_ability, 
                                                game_advanced_tutorial_tip_dialog_ultimate_ability_garen, 
                                                DATA/Images/Tips/tipDialogImage_ultimateAbilityGaren.dds)
                                    ) ||
                                    // Sequence name :TestForRyze
                                    (
                                          "PlayerSkin" == Ryze &&
                                          ActivateTipDialogue(
                                                out TipDialogID, 
                                                TutorialPlayer, 
                                                game_advanced_tutorial_tip_name_ultimate_ability, 
                                                game_advanced_tutorial_tip_dialog_ultimate_ability_ryze, 
                                                DATA/Images/Tips/tipDialogImage_ultimateAbilityRyze.dds)
                                    )
                              ) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleUIHighlight(
                                    UI_ABILITY_4, 
                                    true) &&
                              PlayVOAudioEvent(
                                    Tip_Ultimate_Ability, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_ABILITY_4, 
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              UltimateAbilities)

                  )
            );
      }
}

