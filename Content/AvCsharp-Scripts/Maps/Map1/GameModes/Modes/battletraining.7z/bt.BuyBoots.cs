using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class BuyBoots : BehaviourTree 
{
      bool GlobalTipDialogActive;
      float MinionSpawnStartTime;
      Vector3OrderSpawnPlatformPosition;

      bool BuyBoots()
      {
      return
            // Sequence name :QuestState-BuyBoots
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              false) &&
                        SetVarBool(
                              out QuestValid, 
                              true)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == false &&
                        GlobalTipDialogActive == false &&
                        // Sequence name :ActivationConditions
                        (
                              // Sequence name :TestGameTime
                              (
                                    GetGameTime(
                                          out GameTime, 
                                          out GameTime) &&
                                    SubtractFloat(
                                          out GameTime, 
                                          GameTime, 
                                          MinionSpawnStartTime) &&
                                    GreaterFloat(
                                          GameTime, 
                                          480)
                              ) &&
                              // Sequence name :TestPlayerNearSummonerPlatform
                              (
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          OrderSpawnPlatformPosition) &&
                                    LessFloat(
                                          Distance, 
                                          1000)
                              ) &&
                              // Sequence name :TestPlayerGold
                              (
                                    GetUnitGold(
                                          out PlayerGold, 
                                          TutorialPlayer) &&
                                    GreaterEqualFloat(
                                          PlayerGold, 
                                          350)
                              ) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestPlayerInventory
                                    (
                                          // Sequence name :CheckForBoots
                                          (
                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      1001, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3006, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3117, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3047, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3111, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3009, 
                                                      true)                                                TestChampionHasItem(
                                                      TutorialPlayer, 
                                                      3020, 
                                                      true)
                                          ) &&
                                          // Sequence name :QuestInvalid
                                          (
                                                SetVarBool(
                                                      out QuestValid, 
                                                      false) &&
                                                SetBTInstanceStatus(
                                                      false, 
                                                      BuyBoots)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              QuestValid == true &&
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_buy_boots, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_buy_boots, 
                                    "") &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Quest_Boots, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :SuccessConditions
                              (
                                    // Sequence name :TestForInventoryBoots
                                    (
                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                1001, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3006, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3117, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3047, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3111, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3009, 
                                                true)                                          TestChampionHasItem(
                                                TutorialPlayer, 
                                                3020, 
                                                true)
                                    )
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          100) &&
                                    SetBTInstanceStatus(
                                          false, 
                                          BuyBoots)

                              )
                        )
                  )
            );
      }
}

