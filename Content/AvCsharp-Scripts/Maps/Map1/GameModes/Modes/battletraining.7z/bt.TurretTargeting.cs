using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class TurretTargeting : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      bool GlobalTipDialogActive;

      bool TurretTargeting()
      {
      return
            // Sequence name :TipState-TurretTargeting
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarFloat(
                              out NearTurretDistance, 
                              850) &&
                        GetUnitAttackRange(
                              out TurretAttackRange, 
                              ChaosTopFrontTurret)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              // Sequence name :TestEnemyChampionNearPlayer
                              (
                                    GetUnitsInTargetArea(
                                          out EnemyChampionsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          1200, 
                                          AffectEnemies,AffectHeroes, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyChampionCount, 
                                          EnemyChampionsNearPlayer) &&
                                    GreaterInt(
                                          EnemyChampionCount, 
                                          0)
                              ) &&
                              // Sequence name :TestPlayerNearEnemyTurret
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemyTurretsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          TurretAttackRange, 
                                          AffectEnemies,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyTurretCount, 
                                          EnemyTurretsNearPlayer) &&
                                    GreaterInt(
                                          EnemyTurretCount, 
                                          0) &&
                                    EnemyTurretsNearPlayer.ForEach( Unit => (                                          SetVarAttackableUnit(
                                                out Turret, 
                                                Unit)
                                    ) &&
                                    GetUnitPosition(
                                          out TurretPosition, 
                                          Turret)
                              ) &&
                              // Sequence name :TestTurretHealth
                              (
                                    GetUnitCurrentHealth(
                                          out TurretHealth, 
                                          Turret) &&
                                    GreaterFloat(
                                          TurretHealth, 
                                          400)
                              ) &&
                              // Sequence name :TestFriendlyMinionsNearTurret
                              (
                                    GetUnitsInTargetArea(
                                          out FriendlyMinionsNearTurret, 
                                          TutorialPlayer, 
                                          TurretPosition, 
                                          TurretAttackRange, 
                                          AffectFriends,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out FriendlyMinionCount, 
                                          FriendlyMinionsNearTurret) &&
                                    GreaterInt(
                                          FriendlyMinionCount, 
                                          0)
                              ) &&
                              // Sequence name :TestEnemyChampionNearTurret
                              (
                                    GetUnitsInTargetArea(
                                          out EnemyChampionsNearTurret, 
                                          TutorialPlayer, 
                                          TurretPosition, 
                                          TurretAttackRange, 
                                          AffectEnemies,AffectHeroes, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyChampionCount, 
                                          EnemyChampionsNearTurret) &&
                                    GreaterInt(
                                          EnemyChampionCount, 
                                          0)
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ToggleUnitHighlight(
                                    true, 
                                    Turret) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_turret_targeting, 
                                    game_advanced_tutorial_tip_dialog_turret_targeting, 
                                    DATA/Images/Tips/tipDialogImage_turretTargeting.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Be_Wary_Near_Turrets, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUnitHighlight(
                              False, 
                              Turret) &&
                        SetBTInstanceStatus(
                              False, 
                              TurretTargeting)

                  )
            );
      }
}

