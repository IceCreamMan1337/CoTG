using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class BaronNashor : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool BaronNashor()
      {
      return
            // Sequence name :TipState-BaronNashor
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        MakeVector(
                              out BaronNashorPosition, 
                              5319, 
                              -14, 
                              9992)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              // Sequence name :TestPlayerNearBaron
                              (
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          BaronNashorPosition) &&
                                    LessFloat(
                                          Distance, 
                                          1500)
                              ) &&
                              // Sequence name :TestBaronAlive
                              (
                                    GetUnitsInTargetArea(
                                          out BaronAreaUnitCollection, 
                                          TutorialPlayer, 
                                          BaronNashorPosition, 
                                          2000, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    BaronAreaUnitCollection.ForEach( Unit => (
                                          // Sequence name :TestForBaron
                                          (
                                                GetUnitSkinName(
                                                      out "UnitSkinName", 
                                                      Unit) &&
                                                "UnitSkinName" == Worm
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_baron, 
                                    game_advanced_tutorial_tip_category_jungling) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true) &&
                              SetBTInstanceStatus(
                                    true, 
                                    BaronWarning)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_baron, 
                              game_advanced_tutorial_tip_dialog_baron, 
                              DATA/Images/Tips/tipDialogImage_baronNashor.dds) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        PlayVOAudioEvent(
                              Tip_Baron_Nashor, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              BaronNashor)

                  )
            );
      }
}

