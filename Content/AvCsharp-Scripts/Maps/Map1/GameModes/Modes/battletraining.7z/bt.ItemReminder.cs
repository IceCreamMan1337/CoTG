using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class ItemReminder : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      Vector3OrderSpawnPlatformPosition;
      bool GlobalTipDialogActive;

      bool ItemReminder()
      {
      return
            // Sequence name :TipState-ItemReminder
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipValid, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerLocation
                              (
                                    DistanceBetweenObjectAndPoint(
                                          out Distance, 
                                          TutorialPlayer, 
                                          OrderSpawnPlatformPosition) &&
                                    GreaterFloat(
                                          Distance, 
                                          1500)
                              ) &&
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    // Sequence name :TestValidity
                                    (
                                          PlayerLevel == 1                                          // Sequence name :TipNotValid
                                          (
                                                SetVarBool(
                                                      out TipValid, 
                                                      False) &&
                                                SetBTInstanceStatus(
                                                      False, 
                                                      ItemReminder)
                                          )
                                    )
                              ) &&
                              // Sequence name :TestPlayerInventory
                              (
                                    GetNumberOfInventorySlotsFilled(
                                          out Items, 
                                          TutorialPlayer) &&
                                    // Sequence name :TestValidity
                                    (
                                          Items == 0                                          // Sequence name :TipNotValid
                                          (
                                                SetVarBool(
                                                      out TipValid, 
                                                      False) &&
                                                SetBTInstanceStatus(
                                                      False, 
                                                      ItemReminder)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              TipValid == true &&
                              GlobalTipDialogActive == False &&
                              StopUnitMovement(
                                    TutorialPlayer) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_item_reminder, 
                                    game_advanced_tutorial_tip_dialog_item_reminder, 
                                    DATA/Images/Tips/tipDialogImage_itemReminder.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              DebugAction(
                                    0, 
                                    SUCCESS, 
                                    wooo1) &&
                              SetGamePauseState(
                                    true) &&
                              DebugAction(
                                    0, 
                                    SUCCESS, 
                                    woo2) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Starting_item, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true) &&
                              DebugAction(
                                    0, 
                                    SUCCESS, 
                                    woo3)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        DebugAction(
                              0, 
                              SUCCESS, 
                              removed dialog) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        DebugAction(
                              0, 
                              SUCCESS, 
                              Resume HITTTT) &&
                        SetBTInstanceStatus(
                              False, 
                              ItemReminder)

                  )
            );
      }
}

