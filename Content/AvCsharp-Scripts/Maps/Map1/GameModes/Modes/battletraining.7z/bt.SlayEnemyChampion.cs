using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class SlayEnemyChampion : BehaviourTree 
{
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      String PlayerSkin;

      bool SlayEnemyChampion()
      {
      return
            // Sequence name :QuestState-SlayEnemyChampion
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        SetVarBool(
                              out QuestValid, 
                              true)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    GreaterEqualInt(
                                          PlayerLevel, 
                                          8)
                              ) &&
                              // Sequence name :ValidateQuest
                              (
                                    // Sequence name :TestPlayerKillCount
                                    (
                                          GetChampionKills(
                                                out ChampionKills, 
                                                TutorialPlayer) &&
                                          ChampionKills == 0
                                    ) ||
                                    // Sequence name :InvalidQuest
                                    (
                                          SetVarBool(
                                                out QuestValid, 
                                                False) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                SlayEnemyChampion)
                                    )
                              ) &&
                              // Sequence name :TestPlayerHealth
                              (
                                    GetUnitCurrentHealth(
                                          out PlayerHealth, 
                                          TutorialPlayer) &&
                                    GetUnitMaxHealth(
                                          out PlayerMaxHealth, 
                                          TutorialPlayer) &&
                                    DivideFloat(
                                          out PlayerHealthPercentage, 
                                          PlayerHealth, 
                                          PlayerMaxHealth) &&
                                    GreaterFloat(
                                          PlayerHealthPercentage, 
                                          0.75)
                              ) &&
                              // Sequence name :TestEnemyChampionNear
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out PlayerArea, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          1000, 
                                          AffectEnemies,AffectHeroes, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyChampionsNearPlayer, 
                                          PlayerArea) &&
                                    GreaterInt(
                                          EnemyChampionsNearPlayer, 
                                          0)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              QuestValid == true &&
                              // Sequence name :VO Option
                              (
                                    // Sequence name :TestPlayerSkin
                                    (
                                          "PlayerSkin" == Garen &&
                                          PlayVOAudioEvent(
                                                Gag_Spin_To_Win, 
                                                Tutorial2, 
                                                true)
                                    ) ||
                                    PlayVOAudioEvent(
                                          Quest_Slay_Champion, 
                                          Tutorial2, 
                                          true)
                              ) &&
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_slay_champion, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_slay_champion, 
                                    "") &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :SuccessConditions
                              (
                                    GetChampionKills(
                                          out ChampionKills, 
                                          TutorialPlayer) &&
                                    GreaterInt(
                                          ChampionKills, 
                                          0)
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          200) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          SlayEnemyChampion)

                              )
                        )
                  )
            );
      }
}

