using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class Intro3 : BehaviourTree 
{
      AttackableUnit TutorialPlayer;
      int FirstPrimaryQuestID;
      int FirstSecondaryQuestID;
      int ViewQuestTooltipQuestID;
      String PlayerSkin;

      bool Intro3()
      {
      return
            // Sequence name :TipState-Intro3
            (
                  // Sequence name :Initialize
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        GetGameTime(
                              out TimeMark, 
                              out TimeMark) &&
                        SetVarFloat(
                              out IdleTimeThreshold, 
                              15)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipActive == False &&
                        // Sequence name :ActivateTip
                        (
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_first_tip, 
                                    game_advanced_tutorial_tip_category_user_interface) &&
                              SetVarBool(
                                    out TipActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipActive == true &&
                        TipDialogActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestIdleTime
                              (
                                    GetGameTime(
                                          out GameTime, 
                                          out GameTime) &&
                                    SubtractFloat(
                                          out IdleTime, 
                                          GameTime, 
                                          TimeMark) &&
                                    GreaterFloat(
                                          IdleTime, 
                                          IdleTimeThreshold) &&
                                    ToggleUIHighlight(
                                          UI_TIPS, 
                                          true) &&
                                    PlayVOAudioEvent(
                                          Intro_Tips, 
                                          Tutorial2, 
                                          true) &&
                                    AddFloat(
                                          out TimeMark, 
                                          TimeMark, 
                                          IdleTimeThreshold)
                              )
                        ) &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        RemoveQuest(
                              FirstPrimaryQuestID) &&
                        RemoveQuest(
                              FirstSecondaryQuestID) &&
                        RemoveQuest(
                              ViewQuestTooltipQuestID) &&
                        ToggleUIHighlight(
                              UI_TIPS, 
                              False) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_first_tip, 
                              game_advanced_tutorial_tip_dialog_first_tip, 
                              DATA/Images/Tips/tipDialogImage_tips.dds) &&
                        PlayVOAudioEvent(
                              Intro_Good_Job, 
                              Tutorial2, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        // Sequence name :MinionsMessage
                        (
                              PlayVOAudioEvent(
                                    Intro_Minions, 
                                    Tutorial2, 
                                    False)
                        ) &&
                        // Sequence name :BeginMessage
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    MoveToLane) &&
                              SetBTInstanceStatus(
                                    true, 
                                    PurchaseStartingItem) &&
                              ToggleUserInput(
                                    true) &&
                              PlayVOAudioEvent(
                                    Intro_Ready, 
                                    Tutorial2, 
                                    False) &&
                              PlayVOAudioEvent(
                                    Intro_Begin, 
                                    Tutorial2, 
                                    False) &&
                              DelayNSecondsBlocking(
                                    2) &&
                              SetGamePauseState(
                                    False) &&
                              ToggleUserInput(
                                    true)
                        ) &&
                        // Sequence name :EnableSecondaryQuests
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    DefeatWolves) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SlayEnemyChampion) &&
                              SetBTInstanceStatus(
                                    true, 
                                    UseRecallSpell) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretTopFront) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretMidFront) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretBotFront)
                        ) &&
                        // Sequence name :EnableTips
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    FirstSkillPoint) &&
                              SetBTInstanceStatus(
                                    true, 
                                    ItemReminder) &&
                              SetBTInstanceStatus(
                                    true, 
                                    LastHitting) &&
                              SetBTInstanceStatus(
                                    true, 
                                    UltimateAbilities) &&
                              SetBTInstanceStatus(
                                    true, 
                                    RespawnTimer) &&
                              SetBTInstanceStatus(
                                    true, 
                                    Assists) &&
                              SetBTInstanceStatus(
                                    true, 
                                    TurretReward) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendGold) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendGoldReminder) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendSkillPoints) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestPlayerChampion
                                    (
                                          "PlayerSkin" == Garen &&
                                          SetBTInstanceStatus(
                                                true, 
                                                ManalessChampions)
                                    )
                              )
                        ) &&
                        SetBTInstanceStatus(
                              False, 
                              Intro3)

                  )
            );
      }
}

