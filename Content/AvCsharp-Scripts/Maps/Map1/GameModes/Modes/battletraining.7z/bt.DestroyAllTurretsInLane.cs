using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DestroyAllTurretsInLane : BehaviourTree 
{
      AttackableUnit ChaosTopCenterTurret;
      AttackableUnit ChaosTopRearTurret;
      AttackableUnit ChaosMidCenterTurret;
      AttackableUnit ChaosMidRearTurret;
      AttackableUnit ChaosBotCenterTurret;
      AttackableUnit ChaosBotRearTurret;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosMidFrontTurret;
      TeamEnum PlayerTeam;
      AttackableUnit ChaosNexusTurretA;
      AttackableUnit ChaosNexusTurretB;
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit ChaosBotFrontTurret;
      float QuestDelayTime;

      bool DestroyAllTurretsInLane()
      {
      return
            // Sequence name :QuestState-DestroyAllTurretsInLane
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        // Sequence name :ValidateQuest
                        (
                              // Sequence name :TestTurrets
                              (
                                    // Sequence name :TopLane
                                    (
                                          TestUnitCondition(
                                                ChaosTopCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosTopRearTurret, 
                                                False)
                                    ) ||
                                    // Sequence name :MidLane
                                    (
                                          TestUnitCondition(
                                                ChaosMidCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosMidRearTurret, 
                                                False)
                                    ) ||
                                    // Sequence name :BotLane
                                    (
                                          TestUnitCondition(
                                                ChaosBotCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosBotRearTurret, 
                                                False)
                                    )
                              ) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyInhibitor) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyAllTurretsInLane)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_lane_turrets, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_lane_turrets, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Clear_Lane, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          QuestID, 
                                          true) &&
                                    // Sequence name :FindClosestTurret
                                    (
                                          GetTurretCollection(
                                                out AllTurrets, 
                                                out AllTurrets) &&
                                          SetVarFloat(
                                                out ShortestDistance, 
                                                25000) &&
                                          SetVarAttackableUnit(
                                                out ClosestTurret, 
                                                ChaosMidFrontTurret) &&
                                          AllTurrets.ForEach( Turret => (
                                                // Sequence name :Sequence
                                                (
                                                      TestUnitCondition(
                                                            Turret, 
                                                            true) &&
                                                      // Sequence name :TestTurretTeam
                                                      (
                                                            GetUnitTeam(
                                                                  out TurretTeam, 
                                                                  Turret) &&
                                                            NotEqualUnitTeam(
                                                                  TurretTeam, 
                                                                  PlayerTeam)
                                                      ) &&
                                                      // Sequence name :IgnoreNexusTurrets
                                                      (
                                                            NotEqualUnit(
                                                                  Turret, 
                                                                  ChaosNexusTurretA) &&
                                                            NotEqualUnit(
                                                                  Turret, 
                                                                  ChaosNexusTurretB)
                                                      ) &&
                                                      // Sequence name :TestDistanceToPlayer
                                                      (
                                                            GetUnitPosition(
                                                                  out TurretPosition, 
                                                                  Turret) &&
                                                            DistanceBetweenObjectAndPoint(
                                                                  out TurretDistance, 
                                                                  TutorialPlayer, 
                                                                  TurretPosition) &&
                                                            LessFloat(
                                                                  TurretDistance, 
                                                                  ShortestDistance)
                                                      ) &&
                                                      // Sequence name :SetClosestTurret
                                                      (
                                                            SetVarFloat(
                                                                  out ShortestDistance, 
                                                                  TurretDistance) &&
                                                            SetVarAttackableUnit(
                                                                  out ClosestTurret, 
                                                                  Turret)
                                                      )
                                                )
                                          )
                                    ) &&
                                    // Sequence name :PingTurrets
                                    (
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TopLane
                                                (
                                                      // Sequence name :CheckForClosestTurret
                                                      (
                                                            ClosestTurret == ChaosTopFrontTurret                                                            ClosestTurret == ChaosTopCenterTurret                                                            ClosestTurret == ChaosTopRearTurret
                                                      ) &&
                                                      TestUnitCondition(
                                                            ChaosTopRearTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosTopRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosTopCenterTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosTopCenterTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosTopFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosTopFrontTurret, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :MidLane
                                                (
                                                      // Sequence name :CheckForClosestTurret
                                                      (
                                                            ClosestTurret == ChaosMidFrontTurret                                                            ClosestTurret == ChaosMidCenterTurret                                                            ClosestTurret == ChaosMidRearTurret
                                                      ) &&
                                                      TestUnitCondition(
                                                            ChaosMidRearTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosMidRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosMidCenterTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosMidCenterTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosMidFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosMidFrontTurret, 
                                                            False)
                                                )
                                          ) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :BotLane
                                                (
                                                      // Sequence name :CheckForClosestTurret
                                                      (
                                                            ClosestTurret == ChaosBotFrontTurret                                                            ClosestTurret == ChaosBotCenterTurret                                                            ClosestTurret == ChaosBotRearTurret
                                                      ) &&
                                                      TestUnitCondition(
                                                            ChaosBotRearTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosBotRearTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosBotCenterTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosBotCenterTurret, 
                                                            False) &&
                                                      TestUnitCondition(
                                                            ChaosBotFrontTurret, 
                                                            true) &&
                                                      PingMinimapUnit(
                                                            TutorialPlayer, 
                                                            ChaosBotFrontTurret, 
                                                            False)
                                                )
                                          )
                                    ) &&
                                    DelayNSecondsBlocking(
                                          5)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              // Sequence name :TestTurrets
                              (
                                    // Sequence name :TopLane
                                    (
                                          TestUnitCondition(
                                                ChaosTopCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosTopRearTurret, 
                                                False)
                                    ) ||
                                    // Sequence name :MidLane
                                    (
                                          TestUnitCondition(
                                                ChaosMidCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosMidRearTurret, 
                                                False)
                                    ) ||
                                    // Sequence name :BotLane
                                    (
                                          TestUnitCondition(
                                                ChaosBotCenterTurret, 
                                                False) &&
                                          TestUnitCondition(
                                                ChaosBotRearTurret, 
                                                False)
                                    )
                              )
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    QuestID, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    QuestDelayTime) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DestroyInhibitor) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyAllTurretsInLane)

                        )
                  )
            );
      }
}

