using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DragonTactics : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;
      bool GlobalTipDialogActive;

      bool DragonTactics()
      {
      return
            // Sequence name :TipState-DragonTactics
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestPlayerNearDragon
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out NeutralMinionsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          500, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    NeutralMinionsNearPlayer.ForEach( Unit => (
                                          // Sequence name :TestForDragon
                                          (
                                                GetUnitSkinName(
                                                      out "SkinName", 
                                                      Unit) &&
                                                "SkinName" == Dragon &&
                                                // Sequence name :TestDragonHealth
                                                (
                                                      GetUnitCurrentHealth(
                                                            out DragonHealth, 
                                                            Unit) &&
                                                      GetUnitMaxHealth(
                                                            out DragonMaxHealth, 
                                                            Unit) &&
                                                      LessFloat(
                                                            DragonHealth, 
                                                            DragonMaxHealth)
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_dragon_tactics, 
                                    game_advanced_tutorial_tip_dialog_dragon_tactics, 
                                    DATA/Images/Tips/tipDialogImage_dragonTactics.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Dragon_Tactics, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              DragonTactics)

                  )
            );
      }
}

