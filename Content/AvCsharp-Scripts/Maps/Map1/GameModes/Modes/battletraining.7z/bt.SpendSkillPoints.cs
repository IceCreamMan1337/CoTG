using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class SpendSkillPoints : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;
      float SafeAreaRange;
      bool GlobalTipDialogActive;

      bool SpendSkillPoints()
      {
      return
            // Sequence name :TipState-SpendSkillPoints
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarBool(
                              out ResetTip, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitSkillPoints(
                                    out SkillPoints, 
                                    TutorialPlayer) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestTipReset
                                    (
                                          ResetTip == true &&
                                          SkillPoints == 0 &&
                                          SetVarBool(
                                                out ResetTip, 
                                                False)
                                    )
                              ) &&
                              ResetTip == False &&
                              GreaterEqualInt(
                                    SkillPoints, 
                                    2) &&
                              // Sequence name :TestEnemiesNearPlayer
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              ) &&
                              // Sequence name :TestAggroNeutralsNear
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    GetCollectionCount(
                                          out NeutralCount, 
                                          NeutralsNearPlayer) &&
                                    // Sequence name :ConditionOption
                                    (
                                          NeutralCount == 0                                          NeutralsNearPlayer.ForEach( Unit => (
                                                // Sequence name :TestHealth
                                                (
                                                      GetUnitMaxHealth(
                                                            out UnitMaxHealth, 
                                                            Unit) &&
                                                      GetUnitCurrentHealth(
                                                            out UnitHealth, 
                                                            Unit) &&
                                                      UnitHealth == UnitMaxHealth
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_skill_points, 
                                    game_advanced_tutorial_tip_dialog_skill_points, 
                                    ) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT1, 
                                    true) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT2, 
                                    true) &&
                              ToggleUIHighlight(
                                    UI_SKILLPOINT3, 
                                    true) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestPlayerLevel
                                    (
                                          GetUnitLevel(
                                                out PlayerLevel, 
                                                TutorialPlayer) &&
                                          GreaterEqualInt(
                                                PlayerLevel, 
                                                6) &&
                                          ToggleUIHighlight(
                                                UI_SKILLPOINT4, 
                                                true)
                                    )
                              ) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Skill_Points, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT1, 
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT2, 
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT3, 
                              False) &&
                        ToggleUIHighlight(
                              UI_SKILLPOINT4, 
                              False) &&
                        // Sequence name :ResetOption
                        (
                              // Sequence name :TestPlayerLevel
                              (
                                    PlayerLevel == 17 &&
                                    SetBTInstanceStatus(
                                          False, 
                                          SpendSkillPoints)
                              ) ||
                              // Sequence name :ResetTip
                              (
                                    SetVarBool(
                                          out TipDialogActive, 
                                          False) &&
                                    SetVarBool(
                                          out ResetTip, 
                                          true)

                              )
                        )
                  )
            );
      }
}

