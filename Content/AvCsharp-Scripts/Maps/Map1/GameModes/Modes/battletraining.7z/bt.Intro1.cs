using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class Intro1 : BehaviourTree 
{
      out int FirstPrimaryQuestID;
      out int FirstSecondaryQuestID;
      out int ViewQuestTooltipQuestID;
      AttackableUnit ChaosNexus;
      AttackableUnit TutorialPlayer;

      bool Intro1()
      {
      return
            // Sequence name :TipState-Intro1
            (
                  // Sequence name :Initialize
                  (
                        __IsFirstRun == true &&
                        ToggleUserInput(
                              False) &&
                        ToggleFogOfWarTexture(
                              False) &&
                        MakeVector(
                              out CameraStartPosition, 
                              10943, 
                              46, 
                              6680) &&
                        GetUnitPosition(
                              out ChaosNexusPosition, 
                              ChaosNexus) &&
                        PanCameraFromCurrentPositionToPoint(
                              TutorialPlayer, 
                              CameraStartPosition, 
                              0.1) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :ActivateTipDialog
                  (
                        TipDialogActive == False &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        DelayNSecondsBlocking(
                              1) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_welcome, 
                              game_advanced_tutorial_tip_dialog_welcome, 
                              ) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        ToggleUserInput(
                              False) &&
                        // Sequence name :WelcomeMessage
                        (
                              PlayVOAudioEvent(
                                    Intro_Welcome, 
                                    Tutorial2, 
                                    true) &&
                              PanCameraFromCurrentPositionToPoint(
                                    TutorialPlayer, 
                                    ChaosNexusPosition, 
                                    5)
                        ) &&
                        // Sequence name :GoalMessage
                        (
                              ToggleUnitHighlight(
                                    true, 
                                    ChaosNexus) &&
                              PlayVOAudioEvent(
                                    Intro_Goal, 
                                    Tutorial2, 
                                    False) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              ToggleUnitHighlight(
                                    False, 
                                    ChaosNexus)
                        ) &&
                        // Sequence name :LanesMessage
                        (
                              PlayVOAudioEvent(
                                    Intro_Lanes, 
                                    Tutorial2, 
                                    true) &&
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              PanCameraFromCurrentPositionToPoint(
                                    TutorialPlayer, 
                                    PlayerPosition, 
                                    8) &&
                              LockAllPlayerCameras(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              ToggleFogOfWarTexture(
                                    true)
                        ) &&
                        // Sequence name :GuideMessage
                        (
                              PlayVOAudioEvent(
                                    Intro_Guide, 
                                    Tutorial2, 
                                    False)
                        ) &&
                        // Sequence name :PrimaryQuestsMessage
                        (
                              ActivateQuest(
                                    out FirstPrimaryQuestID, 
                                    game_advanced_tutorial_quest_name_primary_quests, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_primary_quests, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Intro_Primary_Quests, 
                                    Tutorial2, 
                                    False)
                        ) &&
                        // Sequence name :SecondaryQuestsMessage
                        (
                              ActivateQuest(
                                    out FirstSecondaryQuestID, 
                                    game_advanced_tutorial_quest_name_secondary_quests, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_secondary_quests, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Intro_Secondary_Quests, 
                                    Tutorial2, 
                                    False)
                        ) &&
                        // Sequence name :QuestDetailsMessage
                        (
                              ActivateQuest(
                                    out ViewQuestTooltipQuestID, 
                                    game_advanced_tutorial_quest_name_view_quest_tooltip, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_view_quest_tooltip, 
                                    "") &&
                              SetBTInstanceStatus(
                                    true, 
                                    Intro2) &&
                              PlayVOAudioEvent(
                                    Intro_Quest_Tracker, 
                                    Tutorial2, 
                                    true)
                        ) &&
                        SetBTInstanceStatus(
                              False, 
                              Intro1)

                  )
            );
      }
}

