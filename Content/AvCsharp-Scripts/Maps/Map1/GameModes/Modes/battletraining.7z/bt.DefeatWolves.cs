using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefeatWolves : BehaviourTree 
{
      out bool QuestTrackerSequenceActive;
      out bool WolvesQuestComplete;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      Vector3OrderSpawnPlatformPosition;
      TeamEnum PlayerTeam;
      bool QuestTrackerSequenceActive;
      float QuestDelayTime;

      bool DefeatWolves()
      {
      return
            // Sequence name :QuestState-DefeatWolves
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        MakeVector(
                              out OrderWolvesPosition, 
                              3371, 
                              46, 
                              6230) &&
                        SetVarBool(
                              out VisitedSpawnPlatform, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    GreaterEqualInt(
                                          PlayerLevel, 
                                          2)
                              ) &&
                              // Sequence name :TestGiantWolfAlive
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralUnitsNearOrderWolves, 
                                          TutorialPlayer, 
                                          OrderWolvesPosition, 
                                          500, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    NeutralUnitsNearOrderWolves.ForEach( Unit => (
                                          // Sequence name :TestForGiantWolf
                                          (
                                                GetUnitSkinName(
                                                      out "UnitSkinName", 
                                                      Unit) &&
                                                "UnitSkinName" == GiantWolf
                                          )
                                    )
                              ) &&
                              // Sequence name :ConditionOption
                              (
                                    // Sequence name :TestPlayerNearWolves
                                    (
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderWolvesPosition) &&
                                          LessFloat(
                                                Distance, 
                                                800)
                                    ) ||
                                    // Sequence name :TestPlayerVisitBase
                                    (
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderSpawnPlatformPosition) &&
                                          // Sequence name :TestPlayerVisitSummonerPlatform
                                          (
                                                VisitedSpawnPlatform == true                                                // Sequence name :TestPlayerNearSummonerPlatform
                                                (
                                                      LessFloat(
                                                            Distance, 
                                                            1000) &&
                                                      SetVarBool(
                                                            out VisitedSpawnPlatform, 
                                                            true)
                                                )
                                          ) &&
                                          GreaterFloat(
                                                Distance, 
                                                2000)
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_wolves, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_wolves, 
                                    "") &&
                              PingMinimapLocation(
                                    TutorialPlayer, 
                                    OrderWolvesPosition, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Quest_Wolves, 
                                    Tutorial2, 
                                    true) &&
                              SetVarDWORD(
                                    out BubbleID, 
                                    0) &&
                              SetVarBool(
                                    out QuestRolledOver, 
                                    False) &&
                              SetBTInstanceStatus(
                                    true, 
                                    MoveWithMinimap) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :HandleQuestRollOver
                                    (
                                          // Sequence name :TestQuestRollOver
                                          (
                                                QuestRolledOver == False &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      true) &&
                                                AddPositionPerceptionBubble(
                                                      out BubbleID, 
                                                      OrderWolvesPosition, 
                                                      1000, 
                                                      1000, 
                                                      PlayerTeam, 
                                                      False, 
                                                      , 
                                                      ) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      true)
                                          ) ||
                                          // Sequence name :QuestNotRolledOver
                                          (
                                                QuestRolledOver == true &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      False) &&
                                                RemovePerceptionBubble(
                                                      BubbleID) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      False)
                                          )
                                    )
                              ) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestQuestClicked
                                    (
                                          QuestTrackerSequenceActive == False &&
                                          TestQuestClicked(
                                                QuestID, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                true) &&
                                          // Sequence name :RecordCameraState
                                          (
                                                // Sequence name :TestCameraState
                                                (
                                                      TestPlayerCameraLocked(
                                                            TutorialPlayer, 
                                                            true) &&
                                                      SetVarBool(
                                                            out CameraLocked, 
                                                            true)
                                                ) ||
                                                SetVarBool(
                                                      out CameraLocked, 
                                                      False)
                                          ) &&
                                          SetGamePauseState(
                                                true) &&
                                          ToggleUserInput(
                                                False) &&
                                          DisableTipEvents(
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                OrderWolvesPosition, 
                                                2.5) &&
                                          DelayNSecondsBlocking(
                                                2) &&
                                          GetUnitPosition(
                                                out PlayerPosition, 
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                PlayerPosition, 
                                                1.5) &&
                                          // Sequence name :ReturnToCameraState
                                          (
                                                // Sequence name :ReturnToCameraState
                                                (
                                                      CameraLocked == true &&
                                                      LockAllPlayerCameras(
                                                            true)
                                                ) ||
                                                LockAllPlayerCameras(
                                                      False)
                                          ) &&
                                          EnableTipEvents(
                                                TutorialPlayer) &&
                                          ToggleUserInput(
                                                true) &&
                                          SetGamePauseState(
                                                False) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                OrderWolvesPosition, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    // Sequence name :TestWolves
                                    (
                                          GetUnitsInTargetArea(
                                                out NeutralUnitsNearOrderWolves, 
                                                TutorialPlayer, 
                                                OrderWolvesPosition, 
                                                1200, 
                                                AffectMinions,AffectNeutral, 
                                                "") &&
                                          NeutralUnitsNearOrderWolves.ForEach( Unit => (
                                                // Sequence name :TestUnitSkinName
                                                (
                                                      GetUnitSkinName(
                                                            out "UnitSkinName", 
                                                            Unit) &&
                                                      NotEqualString(
                                                            "UnitSkinName", 
                                                            GiantWolf) &&
                                                      NotEqualString(
                                                            "UnitSkinName", 
                                                            wolf)
                                                )
                                          )
                                    )
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          100) &&
                                    DelayNSecondsBlocking(
                                          QuestDelayTime) &&
                                    SetVarBool(
                                          out WolvesQuestComplete, 
                                          true) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          MirroredJungle) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefeatWolves)

                              )
                        )
                  )
            );
      }
}

