using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class Brush : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      float SafeAreaRange;
      bool GlobalTipDialogActive;

      bool Brush()
      {
      return
            // Sequence name :TipState-Brush
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitInBrush(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              // Sequence name :TestEnemiesNear
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              ) &&
                              // Sequence name :TestAggroNeutralsNear
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    GetCollectionCount(
                                          out NeutralCount, 
                                          NeutralsNearPlayer) &&
                                    // Sequence name :ConditionOption
                                    (
                                          NeutralCount == 0                                          NeutralsNearPlayer.ForEach( Unit => (
                                                // Sequence name :TestHealth
                                                (
                                                      GetUnitMaxHealth(
                                                            out UnitMaxHealth, 
                                                            Unit) &&
                                                      GetUnitCurrentHealth(
                                                            out UnitHealth, 
                                                            Unit) &&
                                                      UnitHealth == UnitMaxHealth
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_brush, 
                                    game_advanced_tutorial_tip_dialog_brush, 
                                    DATA/Images/Tips/tipDialogImage_brush.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Brush, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              Brush)

                  )
            );
      }
}

