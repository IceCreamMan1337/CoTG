using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class InitializationScript : BehaviourTree 
{
      out AttackableUnit TutorialPlayer;
      out TeamEnum PlayerTeam;
      out String PlayerSkin;
      out AttackableUnit ChaosTopFrontTurret;
      out AttackableUnit ChaosTopCenterTurret;
      out AttackableUnit ChaosTopRearTurret;
      out AttackableUnit ChaosMidFrontTurret;
      out AttackableUnit ChaosMidCenterTurret;
      out AttackableUnit ChaosMidRearTurret;
      out AttackableUnit ChaosBotFrontTurret;
      out AttackableUnit ChaosBotCenterTurret;
      out AttackableUnit ChaosBotRearTurret;
      out AttackableUnit ChaosNexusTurretA;
      out AttackableUnit ChaosNexusTurretB;
      out AttackableUnit ChaosNexus;
      out AttackableUnit OrderBotCenterTurret;
      out AttackableUnit OrderBotFrontTurret;
      out AttackableUnit OrderBotRearTurret;
      out AttackableUnit OrderMidCenterTurret;
      out AttackableUnit OrderMidFrontTurret;
      out AttackableUnit OrderMidRearTurret;
      out AttackableUnit OrderNexus;
      out AttackableUnit OrderNexusTurretA;
      out AttackableUnit OrderNexusTurretB;
      out AttackableUnit OrderTopCenterTurret;
      out AttackableUnit OrderTopFrontTurret;
      out AttackableUnit OrderTopRearTurret;
      out AttackableUnit ChaosTopInhibitor;
      out AttackableUnit ChaosMidInhibitor;
      out AttackableUnit ChaosBotInhibitor;
      out AttackableUnit OrderTopInhibitor;
      out AttackableUnit OrderMidInhibitor;
      out AttackableUnit OrderBotInhibitor;
      out Vector3OrderSpawnPlatformPosition;
      out Vector3OrderShopPosition;
      out bool DisableIntro;
      out bool QuestTrackerSequenceActive;
      out bool GlobalTipDialogActive;
      out float MinionSpawnStartTime;
      out float QuestDelayTime;
      out int BuildingSecureTime;
      out float BuildingDefenseAllyCheckRange;
      out float BuildingDefensePlayerCheckRange;
      out bool WolvesQuestComplete;
      out bool WraithsQuestComplete;
      out bool AncientGolemQuestComplete;
      out bool LizardElderQuestComplete;
      out int MoveToLaneQuestID;
      out float SafeAreaRange;

      bool InitializationScript()
      {
      return
            // Sequence name :Initialization
            (
                  __IsFirstRun == true &&
                  // Sequence name :Initialize global references
                  (
                        // Sequence name :Get units
                        (
                              GetTutorialPlayer(
                                    out TutorialPlayer, 
                                    out TutorialPlayer) &&
                              GetUnitTeam(
                                    out PlayerTeam, 
                                    TutorialPlayer) &&
                              GetUnitSkinName(
                                    out "PlayerSkin", 
                                    TutorialPlayer) &&
                              GetTurret(
                                    out ChaosTopFrontTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    2, 
                                    3) &&
                              GetTurret(
                                    out ChaosTopCenterTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    2, 
                                    2) &&
                              GetTurret(
                                    out ChaosTopRearTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    2, 
                                    1) &&
                              GetTurret(
                                    out ChaosMidFrontTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    1, 
                                    3) &&
                              GetTurret(
                                    out ChaosMidCenterTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    1, 
                                    2) &&
                              GetTurret(
                                    out ChaosMidRearTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    1, 
                                    1) &&
                              GetTurret(
                                    out ChaosBotFrontTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    0, 
                                    3) &&
                              GetTurret(
                                    out ChaosBotCenterTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    0, 
                                    2) &&
                              GetTurret(
                                    out ChaosBotRearTurret, 
                                    TeamId.TEAM_PURPLE, 
                                    0, 
                                    1) &&
                              GetTurret(
                                    out ChaosNexusTurretA, 
                                    TeamId.TEAM_PURPLE, 
                                    1, 
                                    4) &&
                              GetTurret(
                                    out ChaosNexusTurretB, 
                                    TeamId.TEAM_PURPLE, 
                                    1, 
                                    5) &&
                              GetInhibitor(
                                    out ChaosTopInhibitor, 
                                    TeamId.TEAM_PURPLE, 
                                    2) &&
                              GetInhibitor(
                                    out ChaosMidInhibitor, 
                                    TeamId.TEAM_PURPLE, 
                                    1) &&
                              GetInhibitor(
                                    out ChaosBotInhibitor, 
                                    TeamId.TEAM_PURPLE, 
                                    0) &&
                              GetNexus(
                                    out ChaosNexus, 
                                    TeamId.TEAM_PURPLE) &&
                              GetTurret(
                                    out OrderTopFrontTurret, 
                                    TeamId.TEAM_BLUE, 
                                    2, 
                                    3) &&
                              GetTurret(
                                    out OrderTopCenterTurret, 
                                    TeamId.TEAM_BLUE, 
                                    2, 
                                    2) &&
                              GetTurret(
                                    out OrderTopRearTurret, 
                                    TeamId.TEAM_BLUE, 
                                    2, 
                                    1) &&
                              GetTurret(
                                    out OrderMidFrontTurret, 
                                    TeamId.TEAM_BLUE, 
                                    1, 
                                    3) &&
                              GetTurret(
                                    out OrderMidCenterTurret, 
                                    TeamId.TEAM_BLUE, 
                                    1, 
                                    2) &&
                              GetTurret(
                                    out OrderMidRearTurret, 
                                    TeamId.TEAM_BLUE, 
                                    1, 
                                    1) &&
                              GetTurret(
                                    out OrderBotFrontTurret, 
                                    TeamId.TEAM_BLUE, 
                                    0, 
                                    3) &&
                              GetTurret(
                                    out OrderBotCenterTurret, 
                                    TeamId.TEAM_BLUE, 
                                    0, 
                                    2) &&
                              GetTurret(
                                    out OrderBotRearTurret, 
                                    TeamId.TEAM_BLUE, 
                                    0, 
                                    1) &&
                              GetTurret(
                                    out OrderNexusTurretA, 
                                    TeamId.TEAM_BLUE, 
                                    1, 
                                    4) &&
                              GetTurret(
                                    out OrderNexusTurretB, 
                                    TeamId.TEAM_BLUE, 
                                    1, 
                                    5) &&
                              GetInhibitor(
                                    out OrderTopInhibitor, 
                                    TeamId.TEAM_BLUE, 
                                    2) &&
                              GetInhibitor(
                                    out OrderMidInhibitor, 
                                    TeamId.TEAM_BLUE, 
                                    1) &&
                              GetInhibitor(
                                    out OrderBotInhibitor, 
                                    TeamId.TEAM_BLUE, 
                                    0) &&
                              GetNexus(
                                    out OrderNexus, 
                                    TeamId.TEAM_BLUE)
                        ) &&
                        // Sequence name :Positions
                        (
                              MakeVector(
                                    out OrderSpawnPlatformPosition, 
                                    42, 
                                    175, 
                                    320) &&
                              MakeVector(
                                    out OrderShopPosition, 
                                    -70, 
                                    175, 
                                    884)
                        ) &&
                        // Sequence name :MiscellaneousRefs
                        (
                              SetVarBool(
                                    out DisableIntro, 
                                    False) &&
                              SetVarBool(
                                    out QuestTrackerSequenceActive, 
                                    False) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    False) &&
                              SetVarFloat(
                                    out MinionSpawnStartTime, 
                                    90) &&
                              SetVarFloat(
                                    out QuestDelayTime, 
                                    4) &&
                              SetVarInt(
                                    out BuildingSecureTime, 
                                    5) &&
                              SetVarFloat(
                                    out BuildingDefenseAllyCheckRange, 
                                    2000) &&
                              SetVarFloat(
                                    out BuildingDefensePlayerCheckRange, 
                                    1200) &&
                              SetVarBool(
                                    out WolvesQuestComplete, 
                                    False) &&
                              SetVarBool(
                                    out WraithsQuestComplete, 
                                    False) &&
                              SetVarBool(
                                    out AncientGolemQuestComplete, 
                                    False) &&
                              SetVarBool(
                                    out LizardElderQuestComplete, 
                                    False) &&
                              SetVarInt(
                                    out MoveToLaneQuestID, 
                                    100) &&
                              SetVarFloat(
                                    out SafeAreaRange, 
                                    600)
                        )
                  ) &&
                  // Sequence name :GamePacing
                  (
                        SetBTInstanceStatus(
                              true, 
                              BotLevelManager) &&
                        GetTurretCollection(
                              out TurretCollection, 
                              out TurretCollection) &&
                        TurretCollection.ForEach( LocalTurret => (                              // Sequence name :NerfTurret
                              (
                                    GetUnitTeam(
                                          out LocalTurretTeam, 
                                          LocalTurret) &&
                                    LocalTurretTeam == TeamId.TEAM_PURPLE &&
                                    // Sequence name :NerfTurretBasedOnDepth
                                    (
                                          // Sequence name :FrontTurret
                                          (
                                                // Sequence name :TestForFrontTurret
                                                (
                                                      LocalTurret == ChaosTopFrontTurret                                                      LocalTurret == ChaosMidFrontTurret                                                      LocalTurret == ChaosBotFrontTurret
                                                ) &&
                                                IncPermanentFlatMaxHealthMod(
                                                      LocalTurret, 
                                                      -800) &&
                                                IncPermanentFlatArmorMod(
                                                      LocalTurret, 
                                                      -35) &&
                                                IncPermanentFlatAttackDamageMod(
                                                      LocalTurret, 
                                                      -20)
                                          ) ||
                                          // Sequence name :CenterTurret
                                          (
                                                // Sequence name :TestForCenterTurret
                                                (
                                                      LocalTurret == ChaosTopCenterTurret                                                      LocalTurret == ChaosMidCenterTurret                                                      LocalTurret == ChaosBotCenterTurret
                                                ) &&
                                                IncPermanentFlatMaxHealthMod(
                                                      LocalTurret, 
                                                      -1000) &&
                                                IncPermanentFlatArmorMod(
                                                      LocalTurret, 
                                                      -42) &&
                                                IncPermanentFlatAttackDamageMod(
                                                      LocalTurret, 
                                                      -24)
                                          ) ||
                                          // Sequence name :RearTurret
                                          (
                                                // Sequence name :TestForRearTurret
                                                (
                                                      LocalTurret == ChaosTopRearTurret                                                      LocalTurret == ChaosMidRearTurret                                                      LocalTurret == ChaosBotRearTurret
                                                ) &&
                                                IncPermanentFlatMaxHealthMod(
                                                      LocalTurret, 
                                                      -1200) &&
                                                IncPermanentFlatArmorMod(
                                                      LocalTurret, 
                                                      -49) &&
                                                IncPermanentFlatAttackDamageMod(
                                                      LocalTurret, 
                                                      -28)
                                          ) ||
                                          // Sequence name :NexusTurret
                                          (
                                                // Sequence name :TestForNexusTurret
                                                (
                                                      LocalTurret == ChaosNexusTurretA                                                      LocalTurret == ChaosNexusTurretB
                                                ) &&
                                                IncPermanentFlatMaxHealthMod(
                                                      LocalTurret, 
                                                      -1400) &&
                                                IncPermanentFlatArmorMod(
                                                      LocalTurret, 
                                                      -56) &&
                                                IncPermanentFlatAttackDamageMod(
                                                      LocalTurret, 
                                                      -32)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :BuffPlayer
                        (
                              IncPermanentFlatArmorMod(
                                    TutorialPlayer, 
                                    25) &&
                              IncPermanentFlatMaxHealthMod(
                                    TutorialPlayer, 
                                    190) &&
                              IncPermanentFlatMagicResistanceMod(
                                    TutorialPlayer, 
                                    15) &&
                              IncPermanentFlatAttackDamageMod(
                                    TutorialPlayer, 
                                    15) &&
                              IncPermanentFlatMagicDamageMod(
                                    TutorialPlayer, 
                                    30) &&
                              IncPermanentPercentRespawnTimeMod(
                                    TutorialPlayer, 
                                    0.2)
                        )
                  ) &&
                  // Sequence name :LevelSetup
                  (
                        SetBarrackStatus(
                              False) &&
                        SetNeutralSpawnEnabled(
                              False) &&
                        GetChampionCollection(
                              out ChampionCollection, 
                              out ChampionCollection) &&
                        ChampionCollection.ForEach( Unit => (
                              SetStateDisableAmbientGold(
                                    Unit, 
                                    true)
                        )
                  ) &&
                  // Sequence name :EnableScripts
                  (
                        // Sequence name :TestForIntro
                        (
                              // Sequence name :TestForIntro
                              (
                                    DisableIntro == False &&
                                    SetBTInstanceStatus(
                                          true, 
                                          Intro1)
                              ) ||
                              // Sequence name :NoIntro
                              (
                                    // Sequence name :EnableQuests
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                MoveToLane) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                PurchaseStartingItem) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                SlayEnemyChampion) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                UseRecallSpell) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretTopFront) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretMidFront) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendTurretBotFront)
                                    ) &&
                                    // Sequence name :EnableTips
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                FirstSkillPoint) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                ItemReminder) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                LastHitting) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                UltimateAbilities) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                RespawnTimer) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                Assists) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                TurretReward) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                SpendGold) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                SpendGoldReminder) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                SpendSkillPoints) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestPlayerChampion
                                                (
                                                      "PlayerSkin" == Garen &&
                                                      SetBTInstanceStatus(
                                                            true, 
                                                            ManalessChampions)
                                                )
                                          )
                                    )
                              )
                        )
                  ) &&
                  SetBTInstanceStatus(
                        False, 
                        InitializationScript)

            );
      }
}

