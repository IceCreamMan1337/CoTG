using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class UseRecallSpell : BehaviourTree 
{
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      Vector3OrderSpawnPlatformPosition;

      bool UseRecallSpell()
      {
      return
            // Sequence name :QuestState-UseRecallSpell
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivationConditions
                        (
                              // Sequence name :TestPlayerHealth
                              (
                                    GetUnitCurrentHealth(
                                          out PlayerHealth, 
                                          TutorialPlayer) &&
                                    GetUnitMaxHealth(
                                          out PlayerMaxHealth, 
                                          TutorialPlayer) &&
                                    DivideFloat(
                                          out PlayerHealthPercent, 
                                          PlayerHealth, 
                                          PlayerMaxHealth) &&
                                    LessEqualFloat(
                                          PlayerHealthPercent, 
                                          0.5)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_recall, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_recall, 
                                    "") &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Quest_Recall, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true) &&
                              SetVarBool(
                                    out QuestRolledOver, 
                                    False) &&
                              SetBTInstanceStatus(
                                    true, 
                                    LowHealthWarning)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestFailure
                        (
                              QuestActive == true &&
                              // Sequence name :FailureConditions
                              (
                                    TestUnitCondition(
                                          TutorialPlayer, 
                                          False)
                              ) &&
                              // Sequence name :FailQuest
                              (
                                    RemoveQuest(
                                          QuestID) &&
                                    ToggleUIHighlight(
                                          UI_RECALL, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          UseRecallSpell)
                              )
                        ) ||
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :HandleQuestRollOver
                                    (
                                          // Sequence name :TestQuestRollOver
                                          (
                                                QuestRolledOver == False &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      true) &&
                                                ToggleUIHighlight(
                                                      UI_RECALL, 
                                                      true) &&
                                                DelayNSecondsBlocking(
                                                      2) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      true)
                                          ) ||
                                          // Sequence name :QuestNotRolledOver
                                          (
                                                QuestRolledOver == true &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      False) &&
                                                ToggleUIHighlight(
                                                      UI_RECALL, 
                                                      False) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      False)
                                          )
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    // Sequence name :TestPlayerOnSpawnPlatform
                                    (
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderSpawnPlatformPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                500)
                                    )
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    ToggleUIHighlight(
                                          UI_RECALL, 
                                          False) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          100) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          UseRecallSpell)
                              )
                        )
                  )
            )
      )      SetGamePauseState(
            False)      ToggleUnitHighlight(
            False, 
            Turret)      SetBTInstanceStatus(
            False, 
            TurretTargeting)      // Sequence name :CappedRepeat
      (
            // Sequence name :TestTipActivationCount
            (
                  GreaterEqualInt(
                        TipActivationCount, 
                        3) &&
                  SetBTInstanceStatus(
                        False, 
                        TurretApproachWarning)
            ) ||
            // Sequence name :ResetTip
            (
                  SetVarBool(
                        out TipDialogActive, 
                        False) &&
                  DelayNSecondsBlocking(
                        10)
            )
      )      // Sequence name :TestPlayerLevel
      (
            PlayerLevel == 17 &&
            SetBTInstanceStatus(
                  False, 
                  SpendSkillPoints)
      )      // Sequence name :ResetTip
      (
            SetVarBool(
                  out TipDialogActive, 
                  False) &&
            SetVarBool(
                  out ResetTip, 
                  true)
      )      SetVarBool(
            out TipDialogActive, 
            true)      // Sequence name :TestTipDialog
      (
            TipDialogActive == true &&
            TestTipClicked(
                  TipDialogID, 
                  true) &&
            RemoveTip(
                  TipDialogID) &&
            SetVarBool(
                  out GlobalTipDialogActive, 
                  False) &&
            EnableTipEvents(
                  TutorialPlayer) &&
            ToggleUserInput(
                  true) &&
            SetGamePauseState(
                  False) &&
            SetVarBool(
                  out TipActive, 
                  False) &&
            SetVarBool(
                  out TipDialogActive, 
                  False) &&
            SetVarBool(
                  out VisitedSpawnPlatform, 
                  False) &&
            ToggleUIHighlight(
                  UI_GOLD, 
                  False) &&
            SetVarBool(
                  out ResetTip, 
                  true)
      ) ||
      LocalTurret == ChaosBotRearTurret      IncPermanentFlatMaxHealthMod(
            LocalTurret, 
            -1200)      IncPermanentFlatArmorMod(
            LocalTurret, 
            -49)      IncPermanentFlatAttackDamageMod(
            LocalTurret, 
            -28)      // Sequence name :NexusTurret
      (
            // Sequence name :TestForNexusTurret
            (
                  LocalTurret == ChaosNexusTurretA                  LocalTurret == ChaosNexusTurretB
            ) &&
            IncPermanentFlatMaxHealthMod(
                  LocalTurret, 
                  -1400) &&
            IncPermanentFlatArmorMod(
                  LocalTurret, 
                  -56) &&
            IncPermanentFlatAttackDamageMod(
                  LocalTurret, 
                  -32)
      )      // Sequence name :BuffPlayer
      (
            IncPermanentFlatArmorMod(
                  TutorialPlayer, 
                  25) &&
            IncPermanentFlatMaxHealthMod(
                  TutorialPlayer, 
                  190) &&
            IncPermanentFlatMagicResistanceMod(
                  TutorialPlayer, 
                  15) &&
            IncPermanentFlatAttackDamageMod(
                  TutorialPlayer, 
                  15) &&
            IncPermanentFlatMagicDamageMod(
                  TutorialPlayer, 
                  30) &&
            IncPermanentPercentRespawnTimeMod(
                  TutorialPlayer, 
                  0.2)
      )      // Sequence name :LevelSetup
      (
            SetBarrackStatus(
                  False) &&
            SetNeutralSpawnEnabled(
                  False) &&
            GetChampionCollection(
                  out ChampionCollection, 
                  out ChampionCollection) &&
            ChampionCollection.ForEach( Unit => (
                  SetStateDisableAmbientGold(
                        Unit, 
                        true)
            )
      ) ||
      // Sequence name :EnableScripts
      (
            // Sequence name :TestForIntro
            (
                  // Sequence name :TestForIntro
                  (
                        DisableIntro == False &&
                        SetBTInstanceStatus(
                              true, 
                              Intro1)
                  ) ||
                  // Sequence name :NoIntro
                  (
                        // Sequence name :EnableQuests
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    MoveToLane) &&
                              SetBTInstanceStatus(
                                    true, 
                                    PurchaseStartingItem) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SlayEnemyChampion) &&
                              SetBTInstanceStatus(
                                    true, 
                                    UseRecallSpell) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretTopFront) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretMidFront) &&
                              SetBTInstanceStatus(
                                    true, 
                                    DefendTurretBotFront)
                        ) &&
                        // Sequence name :EnableTips
                        (
                              SetBTInstanceStatus(
                                    true, 
                                    FirstSkillPoint) &&
                              SetBTInstanceStatus(
                                    true, 
                                    ItemReminder) &&
                              SetBTInstanceStatus(
                                    true, 
                                    LastHitting) &&
                              SetBTInstanceStatus(
                                    true, 
                                    UltimateAbilities) &&
                              SetBTInstanceStatus(
                                    true, 
                                    RespawnTimer) &&
                              SetBTInstanceStatus(
                                    true, 
                                    Assists) &&
                              SetBTInstanceStatus(
                                    true, 
                                    TurretReward) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendGold) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendGoldReminder) &&
                              SetBTInstanceStatus(
                                    true, 
                                    SpendSkillPoints) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestPlayerChampion
                                    (
                                          "PlayerSkin" == Garen &&
                                          SetBTInstanceStatus(
                                                true, 
                                                ManalessChampions)
                                    )
                              )
                        )
                  )
            )
      ) ||
      SetBTInstanceStatus(
            False, 
            InitializationScript);
      }
}

