using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefeatWraiths : BehaviourTree 
{
      out bool QuestTrackerSequenceActive;
      out bool WraithsQuestComplete;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      bool WolvesQuestComplete;
      TeamEnum PlayerTeam;
      bool QuestTrackerSequenceActive;
      float QuestDelayTime;

      bool DefeatWraiths()
      {
      return
            // Sequence name :QuestState-DefeatWraiths
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        MakeVector(
                              out OrderWraithsPosition, 
                              6500, 
                              48, 
                              5290) &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              // Sequence name :TestWraithAlive
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralUnitsNearOrderWraiths, 
                                          TutorialPlayer, 
                                          OrderWraithsPosition, 
                                          800, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    NeutralUnitsNearOrderWraiths.ForEach( Unit => (
                                          // Sequence name :TestForWraith
                                          (
                                                GetUnitSkinName(
                                                      out "UnitSkinName", 
                                                      Unit) &&
                                                "UnitSkinName" == Wraith
                                          )
                                    )
                              ) &&
                              // Sequence name :ConditionOption
                              (
                                    WolvesQuestComplete == true                                    // Sequence name :TestPlayerNearWraiths
                                    (
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderWraithsPosition) &&
                                          LessEqualFloat(
                                                Distance, 
                                                400)
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_wraiths, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_wraiths, 
                                    "") &&
                              PingMinimapLocation(
                                    TutorialPlayer, 
                                    OrderWraithsPosition, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Quest_Wraiths, 
                                    Tutorial2, 
                                    true) &&
                              SetVarDWORD(
                                    out BubbleID, 
                                    0) &&
                              SetVarBool(
                                    out QuestRolledOver, 
                                    False) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :HandleQuestRollOver
                                    (
                                          // Sequence name :TestQuestRollOver
                                          (
                                                QuestRolledOver == False &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      true) &&
                                                AddPositionPerceptionBubble(
                                                      out BubbleID, 
                                                      OrderWraithsPosition, 
                                                      1000, 
                                                      1000, 
                                                      PlayerTeam, 
                                                      False, 
                                                      , 
                                                      ) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      true)
                                          ) ||
                                          // Sequence name :QuestNotRolledOver
                                          (
                                                QuestRolledOver == true &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      False) &&
                                                RemovePerceptionBubble(
                                                      BubbleID) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      False)
                                          )
                                    )
                              ) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestQuestClicked
                                    (
                                          QuestTrackerSequenceActive == False &&
                                          TestQuestClicked(
                                                QuestID, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                true) &&
                                          // Sequence name :RecordCameraState
                                          (
                                                // Sequence name :TestCameraState
                                                (
                                                      TestPlayerCameraLocked(
                                                            TutorialPlayer, 
                                                            true) &&
                                                      SetVarBool(
                                                            out CameraLocked, 
                                                            true)
                                                ) ||
                                                SetVarBool(
                                                      out CameraLocked, 
                                                      False)
                                          ) &&
                                          SetGamePauseState(
                                                true) &&
                                          ToggleUserInput(
                                                False) &&
                                          DisableTipEvents(
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                OrderWraithsPosition, 
                                                2.5) &&
                                          DelayNSecondsBlocking(
                                                2) &&
                                          GetUnitPosition(
                                                out PlayerPosition, 
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                PlayerPosition, 
                                                1.5) &&
                                          // Sequence name :ReturnToCameraState
                                          (
                                                // Sequence name :ReturnToCameraState
                                                (
                                                      CameraLocked == true &&
                                                      LockAllPlayerCameras(
                                                            true)
                                                ) ||
                                                LockAllPlayerCameras(
                                                      False)
                                          ) &&
                                          EnableTipEvents(
                                                TutorialPlayer) &&
                                          ToggleUserInput(
                                                true) &&
                                          SetGamePauseState(
                                                False) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                OrderWraithsPosition, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    // Sequence name :TestWraiths
                                    (
                                          GetUnitsInTargetArea(
                                                out NeutralUnitsNearOrderWraiths, 
                                                TutorialPlayer, 
                                                OrderWraithsPosition, 
                                                1200, 
                                                AffectMinions,AffectNeutral, 
                                                "") &&
                                          NeutralUnitsNearOrderWraiths.ForEach( Unit => (
                                                // Sequence name :TestUnitSkinName
                                                (
                                                      GetUnitSkinName(
                                                            out "UnitSkinName", 
                                                            Unit) &&
                                                      NotEqualString(
                                                            "UnitSkinName", 
                                                            Wraith) &&
                                                      NotEqualString(
                                                            "UnitSkinName", 
                                                            LesserWraith)
                                                )
                                          )
                                    )
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          125) &&
                                    DelayNSecondsBlocking(
                                          QuestDelayTime) &&
                                    SetVarBool(
                                          out WraithsQuestComplete, 
                                          true) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefeatWraiths)

                              )
                        )
                  )
            );
      }
}

