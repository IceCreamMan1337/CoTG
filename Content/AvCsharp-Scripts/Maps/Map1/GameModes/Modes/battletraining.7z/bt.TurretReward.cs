using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class TurretReward : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosTopFrontTurret;
      AttackableUnit ChaosMidFrontTurret;
      AttackableUnit ChaosBotFrontTurret;
      AttackableUnit TutorialPlayer;

      bool TurretReward()
      {
      return
            // Sequence name :TipState-TurretReward
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipTrackerActive, 
                              False) &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipTrackerActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              // Sequence name :TestChaosFrontTurrets
                              (
                                    TestUnitCondition(
                                          ChaosTopFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosMidFrontTurret, 
                                          False)                                    TestUnitCondition(
                                          ChaosBotFrontTurret, 
                                          False)
                              )
                        ) &&
                        // Sequence name :ActivateTipTracker
                        (
                              DelayNSecondsBlocking(
                                    1) &&
                              ActivateTip(
                                    out TipTrackerID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_turret_reward, 
                                    game_advanced_tutorial_tip_category_pushing) &&
                              SetVarBool(
                                    out TipTrackerActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipTracker
                  (
                        TipTrackerActive == true &&
                        TipDialogActive == False &&
                        TestTipClicked(
                              TipTrackerID, 
                              true) &&
                        RemoveTip(
                              TipTrackerID) &&
                        ActivateTipDialogue(
                              out TipDialogID, 
                              TutorialPlayer, 
                              game_advanced_tutorial_tip_name_turret_reward, 
                              game_advanced_tutorial_tip_dialog_turret_reward, 
                              DATA/Images/Tips/tipDialogImage_turretReward.dds) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              true) &&
                        DisableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              False) &&
                        SetGamePauseState(
                              true) &&
                        DelayNSecondsBlocking(
                              0.5) &&
                        PlayVOAudioEvent(
                              General_Success, 
                              Tutorial2, 
                              true) &&
                        SetVarBool(
                              out TipDialogActive, 
                              true)
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              TurretReward)

                  )
            );
      }
}

