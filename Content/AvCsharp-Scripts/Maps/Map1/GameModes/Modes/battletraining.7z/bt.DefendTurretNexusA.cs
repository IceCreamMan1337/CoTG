using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefendTurretNexusA : BehaviourTree 
{
      AttackableUnit OrderNexusTurretA;
      AttackableUnit TutorialPlayer;
      int BuildingSecureTime;
      float BuildingDefensePlayerCheckRange;

      bool DefendTurretNexusA()
      {
      return
            // Sequence name :QuestState-DefendTurretNexusA
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        // Sequence name :InitializeReferences
                        (
                              SetVarBool(
                                    out QuestActive, 
                                    False) &&
                              GetUnitPosition(
                                    out TurretPosition, 
                                    OrderNexusTurretA) &&
                              GetUnitCurrentHealth(
                                    out CurrentTurretHealth, 
                                    OrderNexusTurretA) &&
                              SetVarFloat(
                                    out PreviousTurretHealth, 
                                    CurrentTurretHealth) &&
                              SetVarInt(
                                    out SteadyHealthCount, 
                                    0)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :ValidateQuest
                              (
                                    TestUnitCondition(
                                          OrderNexusTurretA, 
                                          False) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          DefendNexus) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefendTurretNexusA)
                              )
                        ) &&
                        // Sequence name :ActivationConditions
                        (
                              TestUnitCondition(
                                    OrderNexusTurretA, 
                                    true) &&
                              // Sequence name :TestTurretDamaged
                              (
                                    GetUnitCurrentHealth(
                                          out CurrentTurretHealth, 
                                          OrderNexusTurretA) &&
                                    LessFloat(
                                          CurrentTurretHealth, 
                                          PreviousTurretHealth)
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              PingMinimapUnit(
                                    TutorialPlayer, 
                                    OrderNexusTurretA, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Announcer_Base_Under_Attack, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :UpdateReferences
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :UpdateReferences
                                    (
                                          TestUnitCondition(
                                                OrderNexusTurretA, 
                                                true) &&
                                          DelayNSecondsBlocking(
                                                1) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :TestTurretHealthOverTime
                                                (
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            False) &&
                                                      GetUnitCurrentHealth(
                                                            out CurrentTurretHealth, 
                                                            OrderNexusTurretA) &&
                                                      // Sequence name :UpdateSteadyHealthCount
                                                      (
                                                            // Sequence name :TestTurretNotDamaged
                                                            (
                                                                  GreaterEqualFloat(
                                                                        CurrentTurretHealth, 
                                                                        PreviousTurretHealth) &&
                                                                  AddInt(
                                                                        out SteadyHealthCount, 
                                                                        SteadyHealthCount, 
                                                                        1)
                                                            ) ||
                                                            SetVarInt(
                                                                  out SteadyHealthCount, 
                                                                  0)
                                                      ) &&
                                                      SteadyHealthCount == BuildingSecureTime &&
                                                      SetVarBool(
                                                            out TurretSecure, 
                                                            true)
                                                )
                                          ) &&
                                          DistanceBetweenObjectAndPoint(
                                                out PlayerDistance, 
                                                TutorialPlayer, 
                                                TurretPosition) &&
                                          // Sequence name :CountNumberOfEnemiesNearTurret
                                          (
                                                GetUnitsInTargetArea(
                                                      out EnemiesInTurretArea, 
                                                      TutorialPlayer, 
                                                      TurretPosition, 
                                                      750, 
                                                      AffectEnemies,AffectHeroes,AffectMinions, 
                                                      "") &&
                                                GetCollectionCount(
                                                      out NumberOfEnemiesNearTurret, 
                                                      EnemiesInTurretArea)
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :TestQuestCompletion
                        (
                              // Sequence name :TestQuestFailure
                              (
                                    QuestActive == true &&
                                    // Sequence name :FailConditions
                                    (
                                          TestUnitCondition(
                                                OrderNexusTurretA, 
                                                False)                                          // Sequence name :TestTurretDefense
                                          (
                                                TurretSecure == true &&
                                                GreaterEqualFloat(
                                                      PlayerDistance, 
                                                      BuildingDefensePlayerCheckRange) &&
                                                NumberOfEnemiesNearTurret == 0
                                          )
                                    ) &&
                                    // Sequence name :FailQuest
                                    (
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendNexus) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretNexusA)
                                    )
                              ) ||
                              // Sequence name :TestQuestSuccess
                              (
                                    QuestActive == true &&
                                    // Sequence name :SuccessConditions
                                    (
                                          TurretSecure == true &&
                                          LessFloat(
                                                PlayerDistance, 
                                                BuildingDefensePlayerCheckRange) &&
                                          NumberOfEnemiesNearTurret == 0
                                    ) &&
                                    // Sequence name :CompleteQuest
                                    (
                                          PlayVOAudioEvent(
                                                Quest_Turret_Secure, 
                                                Tutorial2, 
                                                true) &&
                                          SetBTInstanceStatus(
                                                true, 
                                                DefendNexus) &&
                                          SetBTInstanceStatus(
                                                False, 
                                                DefendTurretNexusA)
                                    )
                              )
                        )
                  ) ||
                  // Sequence name :UpdateReferences
                  (
                        SetVarFloat(
                              out PreviousTurretHealth, 
                              CurrentTurretHealth)

                  )
            );
      }
}

