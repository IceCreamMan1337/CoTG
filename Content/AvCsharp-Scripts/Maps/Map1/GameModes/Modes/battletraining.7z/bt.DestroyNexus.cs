using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DestroyNexus : BehaviourTree 
{
      AttackableUnit ChaosNexus;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;

      bool DestroyNexus()
      {
      return
            // Sequence name :QuestState-DestroyNexus
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out QuestActive, 
                              False) &&
                        // Sequence name :ValidateQuest
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    False) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyNexus)
                        )
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_nexus, 
                                    TutorialPlayer, 
                                    PRIMARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_nexus, 
                                    "") &&
                              PlayVOAudioEvent(
                                    Quest_Destroy_Nexus, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        QuestActive == true &&
                        // Sequence name :MaskFailure
                        (
                              // Sequence name :TestQuestClicked
                              (
                                    TestQuestClicked(
                                          QuestID, 
                                          true) &&
                                    PingMinimapUnit(
                                          TutorialPlayer, 
                                          ChaosNexus, 
                                          False) &&
                                    DelayNSecondsBlocking(
                                          3)
                              )
                        ) &&
                        // Sequence name :SuccessConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    False)
                        ) &&
                        // Sequence name :CompleteQuest
                        (
                              CompleteQuest(
                                    QuestID, 
                                    true) &&
                              SetBTInstanceStatus(
                                    False, 
                                    DestroyNexus)

                        )
                  )
            );
      }
}

