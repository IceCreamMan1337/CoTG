using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DefeatLizardElder : BehaviourTree 
{
      out bool QuestTrackerSequenceActive;
      out bool LizardElderQuestComplete;
      bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      bool WraithsQuestComplete;
      String PlayerSkin;
      bool AncientGolemQuestComplete;
      Vector3OrderSpawnPlatformPosition;
      TeamEnum PlayerTeam;
      bool QuestTrackerSequenceActive;
      float QuestDelayTime;

      bool DefeatLizardElder()
      {
      return
            // Sequence name :QuestState-DefeatLizardElder
            (
                  // Sequence name :InitializeQuest
                  (
                        __IsFirstRun == true &&
                        MakeVector(
                              out OrderLizardElderPosition, 
                              7100, 
                              48, 
                              3900) &&
                        SetVarBool(
                              out FirstPass, 
                              true) &&
                        SetVarBool(
                              out VisitedSpawnPlatform, 
                              False) &&
                        SetVarBool(
                              out QuestActive, 
                              False)
                  ) ||
                  // Sequence name :TestQuestActivation
                  (
                        QuestActive == False &&
                        GlobalTipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitHasBuff(
                                    TutorialPlayer, 
                                    , 
                                    BlessingoftheLizardElder, 
                                    False) &&
                              // Sequence name :TestPlayerLevel
                              (
                                    GetUnitLevel(
                                          out PlayerLevel, 
                                          TutorialPlayer) &&
                                    GreaterEqualInt(
                                          PlayerLevel, 
                                          6)
                              ) &&
                              // Sequence name :TestLizardElderAlive
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralUnitsNearOrderLizardElder, 
                                          TutorialPlayer, 
                                          OrderLizardElderPosition, 
                                          500, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    NeutralUnitsNearOrderLizardElder.ForEach( Unit => (
                                          // Sequence name :TestForLizardElder
                                          (
                                                GetUnitSkinName(
                                                      out "UnitSkinName", 
                                                      Unit) &&
                                                "UnitSkinName" == LizardElder
                                          )
                                    )
                              ) &&
                              // Sequence name :TestPlayerEffectiveHealth
                              (
                                    GetUnitCurrentHealth(
                                          out PlayerHealth, 
                                          TutorialPlayer) &&
                                    GetUnitArmor(
                                          out PlayerArmor, 
                                          TutorialPlayer) &&
                                    AddFloat(
                                          out TempResult, 
                                          PlayerArmor, 
                                          100) &&
                                    DivideFloat(
                                          out TempResult, 
                                          PlayerArmor, 
                                          TempResult) &&
                                    SubtractFloat(
                                          out TempResult, 
                                          1, 
                                          TempResult) &&
                                    DivideFloat(
                                          out ArmorHealth, 
                                          PlayerHealth, 
                                          TempResult) &&
                                    AddFloat(
                                          out PlayerEffectiveHealth, 
                                          PlayerHealth, 
                                          ArmorHealth) &&
                                    // Sequence name :SetHealthRequirementFlag
                                    (
                                          // Sequence name :TestEffectiveHealthRequirement
                                          (
                                                GreaterEqualFloat(
                                                      PlayerEffectiveHealth, 
                                                      3500) &&
                                                SetVarBool(
                                                      out HealthRequirementMet, 
                                                      true)
                                          ) ||
                                          SetVarBool(
                                                out HealthRequirementMet, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :ConditionOption
                              (
                                    // Sequence name :TestPlayerNearLizardElder
                                    (
                                          HealthRequirementMet == true &&
                                          DistanceBetweenObjectAndPoint(
                                                out Distance, 
                                                TutorialPlayer, 
                                                OrderLizardElderPosition) &&
                                          LessFloat(
                                                Distance, 
                                                600)
                                    ) ||
                                    // Sequence name :TestWraithsQuestComplete
                                    (
                                          WraithsQuestComplete == true &&
                                          // Sequence name :ConditionOption
                                          (
                                                // Sequence name :TestPlayerSkin
                                                (
                                                      // Sequence name :ConditionOption
                                                      (
                                                            "PlayerSkin" == Bowmaster                                                            "PlayerSkin" == Ryze
                                                      ) &&
                                                      AncientGolemQuestComplete == true
                                                ) ||
                                                "PlayerSkin" == Garen
                                          ) &&
                                          // Sequence name :ConditionOption
                                          (
                                                // Sequence name :TestFirstPass
                                                (
                                                      FirstPass == true &&
                                                      SetVarBool(
                                                            out FirstPass, 
                                                            False) &&
                                                      HealthRequirementMet == true
                                                ) ||
                                                // Sequence name :WaitForReturnToBase
                                                (
                                                      DistanceBetweenObjectAndPoint(
                                                            out Distance, 
                                                            TutorialPlayer, 
                                                            OrderSpawnPlatformPosition) &&
                                                      // Sequence name :TestPlayerVisitSummonerPlatform
                                                      (
                                                            VisitedSpawnPlatform == true                                                            // Sequence name :TestPlayerNearSummonerPlatform
                                                            (
                                                                  LessFloat(
                                                                        Distance, 
                                                                        1000) &&
                                                                  SetVarBool(
                                                                        out VisitedSpawnPlatform, 
                                                                        true)
                                                            )
                                                      ) &&
                                                      GreaterFloat(
                                                            Distance, 
                                                            2000) &&
                                                      // Sequence name :TestPlayerHealth
                                                      (
                                                            // Sequence name :TestPlayerHealth
                                                            (
                                                                  HealthRequirementMet == true                                                                  SetVarBool(
                                                                        out VisitedSpawnPlatform, 
                                                                        False)
                                                            ) &&
                                                            HealthRequirementMet == true
                                                      )
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateQuest
                        (
                              ActivateQuest(
                                    out QuestID, 
                                    game_advanced_tutorial_quest_name_lizard_elder, 
                                    TutorialPlayer, 
                                    SECONDARY_QUEST, 
                                    true, 
                                    game_advanced_tutorial_quest_tooltip_lizard_elder, 
                                    "") &&
                              SetVarBool(
                                    out QuestActive, 
                                    true) &&
                              SetVarDWORD(
                                    out BubbleID, 
                                    0) &&
                              PingMinimapLocation(
                                    TutorialPlayer, 
                                    OrderLizardElderPosition, 
                                    true) &&
                              DelayNSecondsBlocking(
                                    1) &&
                              PlayVOAudioEvent(
                                    Tip_Lizard, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out QuestRolledOver, 
                                    False) &&
                              SetBTInstanceStatus(
                                    true, 
                                    LizardTactics)
                        )
                  ) ||
                  // Sequence name :TestQuestCompletion
                  (
                        // Sequence name :TestQuestSuccess
                        (
                              QuestActive == true &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :HandleQuestRollOver
                                    (
                                          // Sequence name :TestQuestRollOver
                                          (
                                                QuestRolledOver == False &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      true) &&
                                                AddPositionPerceptionBubble(
                                                      out BubbleID, 
                                                      OrderLizardElderPosition, 
                                                      1000, 
                                                      1000, 
                                                      PlayerTeam, 
                                                      False, 
                                                      , 
                                                      ) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      true)
                                          ) ||
                                          // Sequence name :QuestNotRolledOver
                                          (
                                                QuestRolledOver == true &&
                                                TestQuestRolledOver(
                                                      QuestID, 
                                                      False) &&
                                                RemovePerceptionBubble(
                                                      BubbleID) &&
                                                SetVarBool(
                                                      out QuestRolledOver, 
                                                      False)
                                          )
                                    )
                              ) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :TestQuestClicked
                                    (
                                          QuestTrackerSequenceActive == False &&
                                          TestQuestClicked(
                                                QuestID, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                true) &&
                                          // Sequence name :RecordCameraState
                                          (
                                                // Sequence name :TestCameraState
                                                (
                                                      TestPlayerCameraLocked(
                                                            TutorialPlayer, 
                                                            true) &&
                                                      SetVarBool(
                                                            out CameraLocked, 
                                                            true)
                                                ) ||
                                                SetVarBool(
                                                      out CameraLocked, 
                                                      False)
                                          ) &&
                                          SetGamePauseState(
                                                true) &&
                                          ToggleUserInput(
                                                False) &&
                                          DisableTipEvents(
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                OrderLizardElderPosition, 
                                                2.5) &&
                                          DelayNSecondsBlocking(
                                                2) &&
                                          GetUnitPosition(
                                                out PlayerPosition, 
                                                TutorialPlayer) &&
                                          PanCameraFromCurrentPositionToPoint(
                                                TutorialPlayer, 
                                                PlayerPosition, 
                                                1.5) &&
                                          // Sequence name :ReturnToCameraState
                                          (
                                                // Sequence name :ReturnToCameraState
                                                (
                                                      CameraLocked == true &&
                                                      LockAllPlayerCameras(
                                                            true)
                                                ) ||
                                                LockAllPlayerCameras(
                                                      False)
                                          ) &&
                                          EnableTipEvents(
                                                TutorialPlayer) &&
                                          ToggleUserInput(
                                                true) &&
                                          SetGamePauseState(
                                                False) &&
                                          PingMinimapLocation(
                                                TutorialPlayer, 
                                                OrderLizardElderPosition, 
                                                true) &&
                                          SetVarBool(
                                                out QuestTrackerSequenceActive, 
                                                False)
                                    )
                              ) &&
                              // Sequence name :SuccessConditions
                              (
                                    TestUnitHasBuff(
                                          TutorialPlayer, 
                                          , 
                                          BlessingoftheLizardElder, 
                                          true)
                              ) &&
                              // Sequence name :CompleteQuest
                              (
                                    CompleteQuest(
                                          QuestID, 
                                          true) &&
                                    GiveChampionGold(
                                          TutorialPlayer, 
                                          200) &&
                                    SetBTInstanceStatus(
                                          true, 
                                          LizardBuff) &&
                                    DelayNSecondsBlocking(
                                          QuestDelayTime) &&
                                    SetVarBool(
                                          out LizardElderQuestComplete, 
                                          true) &&
                                    SetBTInstanceStatus(
                                          False, 
                                          DefeatLizardElder)

                              )
                        )
                  )
            );
      }
}

