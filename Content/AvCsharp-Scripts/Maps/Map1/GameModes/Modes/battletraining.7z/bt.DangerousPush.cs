using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class DangerousPush : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit TutorialPlayer;
      AttackableUnit ChaosNexus;
      bool GlobalTipDialogActive;

      bool DangerousPush()
      {
      return
            // Sequence name :TipState-DangerousPush
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    TutorialPlayer, 
                                    true) &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              GetUnitPosition(
                                    out PlayerPosition, 
                                    TutorialPlayer) &&
                              GetUnitsInTargetArea(
                                    out TurretsNearPlayerCollection, 
                                    TutorialPlayer, 
                                    PlayerPosition, 
                                    1350, 
                                    AffectEnemies,AffectTurrets, 
                                    "") &&
                              TurretsNearPlayerCollection.ForEach( TurretNearPlayer => (                                    // Sequence name :Sequence
                                    (
                                          TestUnitIsInvulnerable(
                                                TurretNearPlayer, 
                                                False) &&
                                          GetUnitTeam(
                                                out TurretTeam, 
                                                TurretNearPlayer) &&
                                          TurretTeam == TeamId.TEAM_PURPLE &&
                                          GetTurretPosition(
                                                out TurretPosition, 
                                                TurretNearPlayer) &&
                                          LessInt(
                                                TurretPosition, 
                                                3)
                                    )
                              ) &&
                              GetUnitsInTargetArea(
                                    out TeamMembersNearPlayer, 
                                    TutorialPlayer, 
                                    PlayerPosition, 
                                    1350, 
                                    AffectFriends,AffectHeroes,AlwaysSelf, 
                                    "") &&
                              GetCollectionCount(
                                    out NumberOfAllyPlayers, 
                                    TeamMembersNearPlayer) &&
                              SetVarInt(
                                    out NumberOfMissingEnemies, 
                                    0) &&
                              GetChampionCollection(
                                    out ChampionCollection, 
                                    out ChampionCollection) &&
                              ChampionCollection.ForEach( Champion => (                                    // Sequence name :TestForMissingEnemy
                                    (
                                          GetUnitTeam(
                                                out ChampionTeam, 
                                                Champion) &&
                                          ChampionTeam == TeamId.TEAM_PURPLE &&
                                          TestUnitCondition(
                                                Champion, 
                                                true) &&
                                          TestUnitVisibility(
                                                TutorialPlayer, 
                                                Champion, 
                                                False) &&
                                          AddInt(
                                                out NumberOfMissingEnemies, 
                                                NumberOfMissingEnemies, 
                                                1)
                                    )
                              ) &&
                              GreaterInt(
                                    NumberOfMissingEnemies, 
                                    NumberOfAllyPlayers)
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              GlobalTipDialogActive == False &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_dangerous_push, 
                                    game_advanced_tutorial_tip_dialog_dangerous_push, 
                                    DATA/Images/Tips/tipDialogImage_dangerousPush.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Ambush, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              DangerousPush)

                  )
            );
      }
}

