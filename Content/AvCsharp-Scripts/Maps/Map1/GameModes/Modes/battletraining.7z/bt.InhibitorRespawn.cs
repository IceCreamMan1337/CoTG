using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class InhibitorRespawn : BehaviourTree 
{
      out bool GlobalTipDialogActive;
      AttackableUnit ChaosNexus;
      AttackableUnit ChaosTopInhibitor;
      AttackableUnit ChaosMidInhibitor;
      AttackableUnit ChaosBotInhibitor;
      AttackableUnit TutorialPlayer;
      float SafeAreaRange;
      bool GlobalTipDialogActive;

      bool InhibitorRespawn()
      {
      return
            // Sequence name :TipState-InhibitorRespawn
            (
                  // Sequence name :InitializeTip
                  (
                        __IsFirstRun == true &&
                        SetVarBool(
                              out TipDialogActive, 
                              False) &&
                        SetVarInt(
                              out PreviousActiveInhibitors, 
                              3) &&
                        SetVarBool(
                              out RespawnOccurred, 
                              False)
                  ) ||
                  // Sequence name :TestTipActivation
                  (
                        TipDialogActive == False &&
                        // Sequence name :TestActivationConditions
                        (
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              SetVarInt(
                                    out ActiveInhibitors, 
                                    3) &&
                              // Sequence name :CountActiveInhibitors
                              (
                                    // Sequence name :Selector
                                    (
                                          TestUnitCondition(
                                                ChaosTopInhibitor, 
                                                true)                                          SubtractInt(
                                                out ActiveInhibitors, 
                                                ActiveInhibitors, 
                                                1)
                                    ) &&
                                    // Sequence name :Selector
                                    (
                                          TestUnitCondition(
                                                ChaosMidInhibitor, 
                                                true)                                          SubtractInt(
                                                out ActiveInhibitors, 
                                                ActiveInhibitors, 
                                                1)
                                    ) &&
                                    // Sequence name :Selector
                                    (
                                          TestUnitCondition(
                                                ChaosBotInhibitor, 
                                                true)                                          SubtractInt(
                                                out ActiveInhibitors, 
                                                ActiveInhibitors, 
                                                1)
                                    )
                              ) &&
                              // Sequence name :TestInhibitorRespawned
                              (
                                    // Sequence name :TestAndUpdateInhibitorCount
                                    (
                                          // Sequence name :TestInhibitorCount
                                          (
                                                GreaterInt(
                                                      ActiveInhibitors, 
                                                      PreviousActiveInhibitors) &&
                                                SetVarBool(
                                                      out RespawnOccurred, 
                                                      true)
                                          ) ||
                                          SetVarInt(
                                                out PreviousActiveInhibitors, 
                                                ActiveInhibitors)
                                    ) &&
                                    RespawnOccurred == true
                              ) &&
                              // Sequence name :TestEnemiesNearPlayer
                              (
                                    GetUnitPosition(
                                          out PlayerPosition, 
                                          TutorialPlayer) &&
                                    GetUnitsInTargetArea(
                                          out EnemiesNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectEnemies,AffectHeroes,AffectMinions,AffectTurrets, 
                                          "") &&
                                    GetCollectionCount(
                                          out EnemyCount, 
                                          EnemiesNearPlayer) &&
                                    EnemyCount == 0
                              ) &&
                              // Sequence name :TestAggroNeutralsNear
                              (
                                    GetUnitsInTargetArea(
                                          out NeutralsNearPlayer, 
                                          TutorialPlayer, 
                                          PlayerPosition, 
                                          SafeAreaRange, 
                                          AffectMinions,AffectNeutral, 
                                          "") &&
                                    GetCollectionCount(
                                          out NeutralCount, 
                                          NeutralsNearPlayer) &&
                                    // Sequence name :ConditionOption
                                    (
                                          NeutralCount == 0                                          NeutralsNearPlayer.ForEach( Unit => (
                                                // Sequence name :TestHealth
                                                (
                                                      GetUnitMaxHealth(
                                                            out UnitMaxHealth, 
                                                            Unit) &&
                                                      GetUnitCurrentHealth(
                                                            out UnitHealth, 
                                                            Unit) &&
                                                      UnitHealth == UnitMaxHealth
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :ActivateTipDialog
                        (
                              DelayNSecondsBlocking(
                                    1) &&
                              GlobalTipDialogActive == False &&
                              TestUnitCondition(
                                    ChaosNexus, 
                                    true) &&
                              ActivateTipDialogue(
                                    out TipDialogID, 
                                    TutorialPlayer, 
                                    game_advanced_tutorial_tip_name_inhibitor_respawn, 
                                    game_advanced_tutorial_tip_dialog_inhibitor_respawn, 
                                    DATA/Images/Tips/tipDialogImage_inhibitorRespawn.dds) &&
                              SetVarBool(
                                    out GlobalTipDialogActive, 
                                    true) &&
                              DisableTipEvents(
                                    TutorialPlayer) &&
                              ToggleUserInput(
                                    False) &&
                              SetGamePauseState(
                                    true) &&
                              DelayNSecondsBlocking(
                                    0.5) &&
                              PlayVOAudioEvent(
                                    Tip_Inhibitor_Respawn, 
                                    Tutorial2, 
                                    true) &&
                              SetVarBool(
                                    out TipDialogActive, 
                                    true)
                        )
                  ) ||
                  // Sequence name :TestTipDialog
                  (
                        TipDialogActive == true &&
                        TestTipClicked(
                              TipDialogID, 
                              true) &&
                        RemoveTip(
                              TipDialogID) &&
                        SetVarBool(
                              out GlobalTipDialogActive, 
                              False) &&
                        EnableTipEvents(
                              TutorialPlayer) &&
                        ToggleUserInput(
                              true) &&
                        SetGamePauseState(
                              False) &&
                        SetBTInstanceStatus(
                              False, 
                              InhibitorRespawn)

                  )
            );
      }
}

