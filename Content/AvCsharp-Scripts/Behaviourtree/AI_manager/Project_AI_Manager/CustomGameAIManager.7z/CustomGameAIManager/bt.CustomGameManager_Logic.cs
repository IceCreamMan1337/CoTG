using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class CustomGameManager_Logic : BehaviourTree 
{

      // Sequence name :CustomGameAIManager.CustomGameManager_Logic
      (
            // Sequence name :CustomGameManager_Logic
            (
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :Init
                        (
                              TestAIFirstTime(
                                    true) &&
                              Initialization(
                                    out StartGameTime, 
                                    out LaneUpdateTime, 
                                    out EnemyStrengthTop, 
                                    out EnemyStrengthMid, 
                                    out EnemyStrengthBot, 
                                    out FriendlyStrengthTop, 
                                    out FriendlyStrengthBot, 
                                    out FriendlyStrengthMid, 
                                    out Squad_PushBot, 
                                    out Squad_PushMid, 
                                    out Squad_PushTop, 
                                    out Squad_WaitAtBase, 
                                    out Mission_PushBot, 
                                    out Mission_PushMid, 
                                    out Mission_PushTop, 
                                    out Mission_WaitAtBase, 
                                    out PrevLaneDistributionTime, 
                                    out hampion, 
                                    out inion, 
                                    out DistributionCount, 
                                    out DynamicDistributionStartTime, 
                                    out DynamicDistributionUpdateTime, 
                                    out UpdateGoldXP, 
                                    out DisconnectAdjustmentEnabled, 
                                    out DisconnectAdjustmentEntityID, 
                                    out TotalDeadTurrets, 
                                    out DifficultyScaling_IsWinState, 
                                    out IsDifficultySet, 
                                    out OverrideDifficulty, 
                                    out StartGameTime, 
                                    out LaneUpdateTime, 
                                    out EnemyStrengthTop, 
                                    out EnemyStrengthMid, 
                                    out EnemyStrengthBot, 
                                    out FriendlyStrengthTop, 
                                    out FriendlyStrengthBot, 
                                    out FriendlyStrengthMid, 
                                    out Squad_PushBot, 
                                    out Squad_PushMid, 
                                    out Squad_PushTop, 
                                    out Squad_WaitAtBase, 
                                    out Mission_PushBot, 
                                    out Mission_PushMid, 
                                    out Mission_PushTop, 
                                    out Mission_WaitAtBase, 
                                    out PrevLaneDistributionTime, 
                                    out hampion, 
                                    out inion, 
                                    out DistributionCount, 
                                    out DynamicDistributionStartTime, 
                                    out DynamicDistributionUpdateTime, 
                                    out UpdateGoldXP, 
                                    out DisconnectAdjustmentEnabled, 
                                    out DisconnectAdjustmentEntityID, 
                                    out TotalDeadTurrets, 
                                    out DifficultyScaling_IsWinState, 
                                    out IsDifficultySet, 
                                    out OverrideDifficulty) &&
                              SetVarBool(
                                    out PlayersOnTeam, 
                                    False) &&
                              SetVarInt(
                                    out Bot1Lane, 
                                    0) &&
                              SetVarInt(
                                    out Bot2Lane, 
                                    2) &&
                              SetVarInt(
                                    out Bot3Lane, 
                                    1) &&
                              SetVarInt(
                                    out Bot4Lane, 
                                    0) &&
                              SetVarBool(
                                    out TeamInit, 
                                    False)
                        )
                  ) &&
                  // Sequence name :HasEntities
                  (
                        GetAIManagerEntities(
                              out AllEntities, 
                              out AllEntities) &&
                        AllEntities.ForEach( Entity => (
                              // Sequence name :Sequence
                              (
                                    SetVarAttackableUnit(
                                          out ReferenceUnit, 
                                          Entity) &&
                                    GetUnitTeam(
                                          out ReferenceUnitTeam, 
                                          ReferenceUnit)
                              )
                        )
                  ) &&
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :PlayingWithPlayers?
                        (
                              TeamInit == False &&
                              GetChampionCollection(
                                    out ChampCollection, 
                                    out ChampCollection) &&
                              SetVarInt(
                                    out ChampCount, 
                                    0) &&
                              SetVarInt(
                                    out BotCount, 
                                    0) &&
                              ChampCollection.ForEach( Champ => (                                    // Sequence name :Sequence
                                    (
                                          GetUnitTeam(
                                                out ChampTeam, 
                                                Champ) &&
                                          ChampTeam == ReferenceUnitTeam &&
                                          AddInt(
                                                out ChampCount, 
                                                ChampCount, 
                                                1)
                                    )
                              ) &&
                              AllEntities.ForEach( Entity => (                                    // Sequence name :Sequence
                                    (
                                          GetUnitTeam(
                                                out EntityTeam, 
                                                Entity) &&
                                          EntityTeam == ReferenceUnitTeam &&
                                          AddInt(
                                                out BotCount, 
                                                BotCount, 
                                                1)
                                    )
                              ) &&
                              SetVarBool(
                                    out TeamInit, 
                                    true) &&
                              NotEqualInt(
                                    ChampCount, 
                                    BotCount) &&
                              GreaterInt(
                                    BotCount, 
                                    0) &&
                              SetVarBool(
                                    out PlayersOnTeam, 
                                    true)
                        )
                  ) &&
                  SetVarInt(
                        out DifficultyIndex, 
                        0) &&
                  BeginnerOverrideDifficulty_TurretDestruction(
                        out OverrideDifficulty, 
                        out IsDifficultySet, 
                        OverrideDifficulty, 
                        ReferenceUnitTeam, 
                        DynamicDistributionStartTime, 
                        IsDifficultySet) &&
                  DifficultySetting(
                        out DynamicDistributionStartTime, 
                        out DynamicDistributionUpdateTime, 
                        out IsDifficultySet, 
                        DifficultyIndex, 
                        DifficultyScaling_IsWinState, 
                        DynamicDistributionStartTime, 
                        IsDifficultySet, 
                        OverrideDifficulty) &&
                  ReferenceUpdateGlobal(
                        out LaneUpdateTime, 
                        out EnemyStrengthTop, 
                        out EnemyStrengthBot, 
                        out EnemyStrengthMid, 
                        out FriendlyStrengthTop, 
                        out FriendlyStrengthMid, 
                        out FriendlyStrengthBot, 
                        LaneUpdateTime, 
                        ReferenceUnit, 
                        EnemyStrengthTop, 
                        EnemyStrengthMid, 
                        EnemyStrengthBot, 
                        FriendlyStrengthTop, 
                        FriendlyStrengthMid, 
                        FriendlyStrengthBot, 
                        Value=, 
                        Value=) &&
                  LevelNormalizer(
                        out UpdateGoldXP, 
                        UpdateGoldXP, 
                        ReferenceUnit, 
                        DifficultyIndex) &&
                  GetGameTime(
                        out CurrentGameTime, 
                        out CurrentGameTime) &&
                  SubtractFloat(
                        out TimeDiff, 
                        CurrentGameTime, 
                        StartGameTime) &&
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :ConformLaningToPlayerPositioning
                        (
                              LessFloat(
                                    CurrentGameTime, 
                                    90) &&
                              PlayersOnTeam == true &&
                              ConformLanesToPlayers(
                                    out Bot1Lane, 
                                    out Bot2Lane, 
                                    out Bot3Lane, 
                                    out Bot4Lane, 
                                    AllEntities, 
                                    ReferenceUnitTeam)
                        )
                  ) &&
                  // Sequence name :LaneDistribution
                  (
                        // Sequence name :EarlyGameLaneDistribution
                        (
                              LessEqualFloat(
                                    TimeDiff, 
                                    DynamicDistributionStartTime) &&
                              CustomGameStaticLaneDistribution(
                                    out Squad_PushBot, 
                                    out Squad_PushMid, 
                                    out Squad_PushTop, 
                                    out Bot1Lane, 
                                    out Bot2Lane, 
                                    out Bot3Lane, 
                                    out Bot4Lane, 
                                    AllEntities, 
                                    Squad_PushBot, 
                                    Squad_PushMid, 
                                    Squad_PushTop, 
                                    Bot1Lane, 
                                    Bot2Lane, 
                                    Bot3Lane, 
                                    Bot4Lane)
                        ) ||
                        // Sequence name :MidGame
                        (
                              SubtractFloat(
                                    out LaneUpdateTimeDiff, 
                                    CurrentGameTime, 
                                    PrevLaneDistributionTime) &&
                              GreaterFloat(
                                    LaneUpdateTimeDiff, 
                                    DynamicDistributionUpdateTime) &&
                              Lane_OptimalDistribution(
                                    EnemyStrengthTop, 
                                    EnemyStrengthMid, 
                                    EnemyStrengthBot, 
                                    FriendlyStrengthTop, 
                                    FriendlyStrengthMid, 
                                    FriendlyStrengthBot, 
                                    AllEntities, 
                                    Squad_PushTop, 
                                    Squad_PushMid, 
                                    Squad_PushBot, 
                                    Value=, 
                                    DisconnectAdjustmentEntityID) &&
                              SetVarFloat(
                                    out PrevLaneDistributionTime, 
                                    CurrentGameTime) &&
                              SetVarBool(
                                    out IsDifficultySet, 
                                    False)

                        )
                  )
            );
      }
}

