using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class AssignBotToSquad : BehaviourTree 
{
      AttackableUnitCollection BotsCollection;
      int BotIndex;
      AISquad SquadToAssign;

      bool AssignBotToSquad()
      {
      return
            // Sequence name :Sequence
            (
                  SetVarInt(
                        out Count, 
                        -1) &&
                  BotsCollection.ForEach( Unit => (
                        // Sequence name :Sequence
                        (
                              AddInt(
                                    out Count, 
                                    Count, 
                                    1) &&
                              Count == BotIndex &&
                              AddAIEntityToSquad(
                                    Unit, 
                                    SquadToAssign)

                        )
                  )
            );
      }
}

