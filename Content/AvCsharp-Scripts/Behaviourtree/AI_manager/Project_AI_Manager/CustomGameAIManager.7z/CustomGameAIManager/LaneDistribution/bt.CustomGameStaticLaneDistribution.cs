using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class CustomGameStaticLaneDistribution : BehaviourTree 
{
      out AISquad Squad_PushBot;
      out AISquad Squad_PushMid;
      out AISquad Squad_PushTop;
      out int Bot1Lane;
      out int Bot2Lane;
      out int Bot3Lane;
      out int Bot4Lane;
      AttackableUnitCollection AllEntities;
      AISquad Squad_PushBot;
      AISquad Squad_PushMid;
      AISquad Squad_PushTop;
      int Bot1Lane;
      int Bot2Lane;
      int Bot3Lane;
      int Bot4Lane;

      bool CustomGameStaticLaneDistribution()
      {
      return
            // Sequence name :CustomGameStaticLaneDistribution
            (
                  SetVarInt(
                        out DistributionCount, 
                        0) &&
                  AllEntities.ForEach( Entity => (
                        // Sequence name :AssignToPushSquad
                        (
                              AddInt(
                                    out DistributionCount, 
                                    DistributionCount, 
                                    1) &&
                              // Sequence name :AssignToLane
                              (
                                    // Sequence name :Bot1
                                    (
                                          DistributionCount == 1 &&
                                          SetVarInt(
                                                out LaneID, 
                                                Bot1Lane)
                                    ) ||
                                    // Sequence name :Bot2
                                    (
                                          DistributionCount == 2 &&
                                          SetVarInt(
                                                out LaneID, 
                                                Bot2Lane)
                                    ) ||
                                    // Sequence name :Bot3
                                    (
                                          DistributionCount == 3 &&
                                          SetVarInt(
                                                out LaneID, 
                                                Bot3Lane)
                                    ) ||
                                    // Sequence name :Bot4
                                    (
                                          DistributionCount == 4 &&
                                          SetVarInt(
                                                out LaneID, 
                                                Bot4Lane)
                                    ) ||
                                    // Sequence name :Bot5
                                    (
                                          DistributionCount == 5 &&
                                          SetVarInt(
                                                out LaneID, 
                                                2)
                                    )
                              ) &&
                              AssignToLane(
                                    Squad_PushTop, 
                                    Squad_PushMid, 
                                    Squad_PushBot, 
                                    Entity, 
                                    LaneID)

                        )
                  )
            );
      }
}

