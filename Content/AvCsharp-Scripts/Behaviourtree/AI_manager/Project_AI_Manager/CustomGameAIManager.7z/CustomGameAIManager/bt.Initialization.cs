using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class Initialization : BehaviourTree 
{
      out float StartGameTime;
      out float LaneUpdateTime;
      out float EnemyStrengthTop;
      out float EnemyStrengthMid;
      out float EnemyStrengthBot;
      out float FriendlyStrengthTop;
      out float FriendlyStrengthBot;
      out float FriendlyStrengthMid;
      out AISquad Squad_PushBot;
      out AISquad Squad_PushMid;
      out AISquad Squad_PushTop;
      out AISquad Squad_WaitAtBase;
      out AIMission Mission_PushBot;
      out AIMission Mission_PushMid;
      out AIMission Mission_PushTop;
      out AIMission Mission_WaitAtBase;
      out float PrevLaneDistributionTime;
      out float PointValue_Champion;
      out float PointValue_Minion;
      out int DistributionCount;
      out float DynamicDistributionStartTime;
      out float DynamicDistributionUpdateTime;
      out float UpdateGoldXP;
      out bool DisconnectAdjustmentEnabled;
      out int DisconnectAdjustmentEntityID;
      out float TotalDeadTurrets;
      out bool DifficultyScaling_IsWinState;
      out bool IsDifficultySet;
      out bool OverrideDifficulty;

      bool Initialization()
      {
      return
            // Sequence name :MaskFailure
            (
                  // Sequence name :RunFirstTimeOnly
                  (
                        GetGameTime(
                              out StartGameTime, 
                              out StartGameTime) &&
                        // Sequence name :Strength
                        (
                              SetVarFloat(
                                    out LaneUpdateTime, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthTop, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthMid, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthBot, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthTop, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthBot, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthMid, 
                                    0)
                        ) &&
                        // Sequence name :AI_Squads
                        (
                              CreateAISquad(
                                    out Squad_PushBot, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_PushMid, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_PushTop, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_WaitAtBase, 
                                    5)
                        ) &&
                        // Sequence name :Missions
                        (
                              CreateAIMission(
                                    out Mission_PushBot, 
                                    PUSH, 
                                    , 
                                    , 
                                    0) &&
                              CreateAIMission(
                                    out Mission_PushMid, 
                                    PUSH, 
                                    , 
                                    , 
                                    1) &&
                              CreateAIMission(
                                    out Mission_PushTop, 
                                    PUSH, 
                                    , 
                                    , 
                                    2) &&
                              CreateAIMission(
                                    out Mission_WaitAtBase, 
                                    SUPPORT, 
                                    , 
                                    , 
                                    )
                        ) &&
                        // Sequence name :AssignSquadsToMissions
                        (
                              AssignAIMission(
                                    Squad_PushBot, 
                                    Mission_PushBot) &&
                              AssignAIMission(
                                    Squad_PushMid, 
                                    Mission_PushMid) &&
                              AssignAIMission(
                                    Squad_PushTop, 
                                    Mission_PushTop) &&
                              AssignAIMission(
                                    Squad_WaitAtBase, 
                                    Mission_WaitAtBase)
                        ) &&
                        // Sequence name :DistributionValues
                        (
                              SetVarFloat(
                                    out PrevLaneDistributionTime, 
                                    0) &&
                              SetVarFloat(
                                    out PointValue_Champion, 
                                    100) &&
                              SetVarFloat(
                                    out PointValue_Minion, 
                                    20) &&
                              SetVarInt(
                                    out DistributionCount, 
                                    0) &&
                              SetVarFloat(
                                    out DynamicDistributionStartTime, 
                                    540) &&
                              SetVarFloat(
                                    out DynamicDistributionUpdateTime, 
                                    15)
                        ) &&
                        // Sequence name :LevelNormalizer
                        (
                              SetVarFloat(
                                    out UpdateGoldXP, 
                                    0)
                        ) &&
                        SetVarFloat(
                              out TotalDeadTurrets, 
                              0) &&
                        DisconnectAdjustmentInitialization(
                              out DisconnectAdjustmentEntityID, 
                              out DisconnectAdjustmentEnabled, 
                              out DisconnectAdjustmentEntityID, 
                              out DisconnectAdjustmentEnabled) &&
                        // Sequence name :DifficultyScaling
                        (
                              SetVarBool(
                                    out DifficultyScaling_IsWinState, 
                                    False) &&
                              SetVarBool(
                                    out IsDifficultySet, 
                                    False) &&
                              SetVarBool(
                                    out OverrideDifficulty, 
                                    False)

                        )
                  )
            );
      }
}

