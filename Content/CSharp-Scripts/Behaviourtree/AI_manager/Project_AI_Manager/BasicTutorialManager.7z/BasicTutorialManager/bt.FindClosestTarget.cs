using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees;


class FindClosestTargetTutorialClass : CommonAI 
{
    

     public  bool FindClosestTarget(
            out AttackableUnit ClosestTarget,
    ICollection<AttackableUnit> UnitsToSearch,
    AttackableUnit ReferenceUnit,
    bool UseVisibilityChecks,
    AttackableUnit IgnoreUnit,
    bool IgnoreUnitFlag)
      {

        AttackableUnit _ClosestTarget = default;

bool result =
            // Sequence name :ClosestTargetFinder
            (
                  SetVarBool(
                        out ValueChanged, 
                        false) &&
                  SetVarFloat(
                        out CurrentClosestDistance, 
                        1E+09f) &&
                  GetUnitPosition(
                        out UnitPosition, 
                        ReferenceUnit) &&
                  ForEach(UnitsToSearch,Unit => (                        // Sequence name :CheckClosestTarget
                        (
                              // Sequence name :VisibilityChecks
                              (
                                    UseVisibilityChecks == false   &&        
                                    // Sequence name :Visible
                                    (
                                          UseVisibilityChecks == true &&
                                          TestUnitIsVisible(
                                                ReferenceUnit, 
                                                Unit)
                                    )
                              ) &&
                              // Sequence name :IgnoreUnitChecks
                              (
                                    IgnoreUnitFlag == false        &&
                                    // Sequence name :CheckAgainstUnitToIgnore
                                    (
                                          IgnoreUnitFlag == true &&
                                          NotEqualUnit(
                                                Unit, 
                                                IgnoreUnit)
                                    )
                              ) &&
                              DistanceBetweenObjectAndPoint(
                                    out Distance, 
                                    Unit, 
                                    UnitPosition) &&
                              LessFloat(
                                    Distance, 
                                    CurrentClosestDistance) &&
                              SetVarFloat(
                                    out CurrentClosestDistance, 
                                    Distance) &&
                              SetVarAttackableUnit(
                                    out _ClosestTarget, 
                                    Unit) &&
                              SetVarBool(
                                    out ValueChanged, 
                                    true)
                        ))
                  ) &&
                  ValueChanged == true

            );

        ClosestTarget = _ClosestTarget;
        return result;
      }
}

