using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees;


class BasicTutorialManager_Logic : CommonAI
{

     public BasicTutorialManager_Logic() {


        var assignToLane = new AssignToLaneTutorialClass();
            // Sequence name :BasicTutorialManager_Logic
            (
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :RunFirstTimeOnly
                        (
                              TestAIFirstTime(
                                    true) &&
                              GetGameTime(
                                    out StartGameTime) &&
                              SetVarFloat(
                                    out LaneUpdateTime, 
                                    0) &&
                              SetVarFloat(
                                    out UpdateGoldXP, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthTop, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthMid, 
                                    0) &&
                              SetVarFloat(
                                    out EnemyStrengthBot, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthTop, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthBot, 
                                    0) &&
                              SetVarFloat(
                                    out FriendlyStrengthMid, 
                                    0) &&
                              MakeVector(
                                    out DragonPosition, 
                                    9827.91f, 
                                    -68.97f, 
                                    4743.4f) &&
                              CreateAISquad(
                                    out Squad_PushBot, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_PushMid, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_PushTop, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_Dragon, 
                                    5) &&
                              CreateAISquad(
                                    out Squad_Jungling, 
                                    5) &&
                              CreateAIMission(
                                    out Mission_PushBot, 
                                   AIMissionTopicType.PUSH, 
                                    null, 
                                    (Vector3)default, 
                                    0) &&
                              CreateAIMission(
                                    out Mission_PushMid,
                                    AIMissionTopicType.PUSH,
                                    null,
                                    (Vector3)default,
                                    1) &&
                              CreateAIMission(
                                    out Mission_PushTop,
                                    AIMissionTopicType.PUSH,
                                    null,
                                    (Vector3)default,
                                    2) &&
                              AssignAIMission(
                                    Squad_PushBot, 
                                    Mission_PushBot) &&
                              AssignAIMission(
                                    Squad_PushMid, 
                                    Mission_PushMid) &&
                              AssignAIMission(
                                    Squad_PushTop, 
                                    Mission_PushTop) &&
                              SetVarFloat(
                                    out PrevLaneDistributionTime, 
                                    0) &&
                              SetVarFloat(
                                    out PointValue_Champion, 
                                    100) &&
                              SetVarFloat(
                                    out PointValue_Minion, 
                                    20) &&
                              SetVarInt(
                                    out DistributionCount, 
                                    0) &&
                              SetVarFloat(
                                    out DynamicDistributionStartTime, 
                                    540) &&
                              SetVarFloat(
                                    out DynamicDistributionUpdateTime, 
                                    15) &&
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :ForcedFailUntilWeHaveNewMegaPacket
                                    (
                                          SetVarBool(
                                                out Run, 
                                                false) &&
                                          Run == true &&
                                          // Sequence name :DifficultySelector
                                          (
                                                // Sequence name :EasyMode
                                                (
                                                      TestAITeamDifficulty(
                                                           GameDifficultyType.GAME_DIFFICULTY_NEWBIE, 
                                                            true) &&
                                                      SetVarFloat(
                                                            out DynamicDistributionStartTime, 
                                                            1200) &&
                                                      SetVarFloat(
                                                            out DynamicDistributionUpdateTime, 
                                                            30)
                                                ) ||
                                                // Sequence name :MediumMode
                                                (
                                                      TestAITeamDifficulty(
                                                            GameDifficultyType.GAME_DIFFICULTY_INTERMEDIATE, 
                                                            true) &&
                                                      SetVarFloat(
                                                            out DynamicDistributionStartTime, 
                                                            540) &&
                                                      SetVarFloat(
                                                            out DynamicDistributionUpdateTime, 
                                                            15)
                                                )
                                          )
                                    )
                              )
                        )
                  ) &&
                  // Sequence name :HasEntities
                  (
                        GetAIManagerEntities(
                              out AllEntities) &&
                        ForEach(AllEntities ,Entity => (
                              SetVarAttackableUnit(
                                    out ReferenceUnit, 
                                    Entity)
                        )
                  ) &&
                  GetGameTime(
                        out CurrentGameTime) &&
                  SubtractFloat(
                        out TimeDiff, 
                        CurrentGameTime, 
                        StartGameTime) &&
                  // Sequence name :LaneDistribution
                  (
                        SetVarInt(
                              out DistributionCount, 
                              -1) &&
                        ForEach(AllEntities, Entity => (
                              // Sequence name :AssignToPushSquad
                              (
                                    AddInt(
                                          out DistributionCount, 
                                          DistributionCount, 
                                          1) &&
                                    ModulusInt(
                                          out LaneID, 
                                          DistributionCount, 
                                          3) &&
                                    // Sequence name :Remap_LaneID
                                    (
                                          // Sequence name :RemapLane1To2
                                          (
                                                LaneID == 1 &&
                                                SetVarInt(
                                                      out LaneID, 
                                                      2)
                                          ) ||
                                          // Sequence name :RemapLane2To1
                                          (
                                                LaneID == 2 &&
                                                SetVarInt(
                                                      out LaneID, 
                                                      1)
                                          ) ||
                                          LaneID == 0
                                    ) &&
                                    assignToLane.AssignToLane(
                                          Squad_PushTop, 
                                          Squad_PushMid, 
                                          Squad_PushBot, 
                                          Entity, 
                                          LaneID)

                              )
                        )
                  )
            );
      }
}

