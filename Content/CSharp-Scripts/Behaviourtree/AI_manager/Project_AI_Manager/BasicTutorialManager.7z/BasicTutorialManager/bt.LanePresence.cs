using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LanePresence : BehaviourTree 
{


     public  bool LanePresence(
        out float StrengthIndicator,
        float EnemyStrength,
        float FriendlyStrength)
      {
      return
            // Sequence name :Calculates_Lane_Presence
            (
                  SubtractFloat(
                        out Presence, 
                        FriendlyStrength, 
                        EnemyStrength) &&
                  DivideFloat(
                        out Presence, 
                        Presence, 
                        4000) &&
                  MaxFloat(
                        out Presence, 
                        Presence, 
                        -1) &&
                  MinFloat(
                        out Presence, 
                        Presence, 
                        1) &&
                  SetVarFloat(
                        out StrengthIndicator, 
                        Presence)

            );
      }
}

