using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class LevelNormalizer : BehaviourTree 
{
      out float PrevTime;
      float PrevTime;
      AttackableUnit ReferenceUnit;
      int DifficultyIndex;

      bool LevelNormalizer()
      {
      return
            // Sequence name :MaskFailure
            (
                  // Sequence name :Sequence
                  (
                        GetGameTime(
                              out CurrentTime, 
                              out CurrentTime) &&
                        SubtractFloat(
                              out TimeDiff, 
                              CurrentTime, 
                              PrevTime) &&
                        GreaterFloat(
                              TimeDiff, 
                              5) &&
                        SetVarInt(
                              out BotTeamAverageLevel, 
                              0) &&
                        SetVarInt(
                              out BotTeamTotalLevel, 
                              0) &&
                        SetVarInt(
                              out HumanTeamAverageLevel, 
                              0) &&
                        SetVarInt(
                              out HumanTeamTotalLevel, 
                              0) &&
                        SetVarFloat(
                              out PrevTime, 
                              CurrentTime) &&
                        // Sequence name :BotTeamAverageLevel
                        (
                              GetAIManagerEntities(
                                    out BotTeam, 
                                    out BotTeam) &&
                              GetCollectionCount(
                                    out BotTeamCount, 
                                    BotTeam) &&
                              GreaterInt(
                                    BotTeamCount, 
                                    0) &&
                              BotTeam.ForEach( Bot => (                                    // Sequence name :IncrementTotalByBotLevel
                                    (
                                          GetUnitLevel(
                                                out BotLevel, 
                                                Bot) &&
                                          AddInt(
                                                out BotTeamTotalLevel, 
                                                BotTeamTotalLevel, 
                                                BotLevel)
                                    )
                              ) &&
                              DivideInt(
                                    out BotTeamAverageLevel, 
                                    BotTeamTotalLevel, 
                                    BotTeamCount) &&
                              AddString(
                                    out "BotTeamUpdateSay", 
                                    BotTeamAverageLevel, 
                                    BotTeamAverageLevel) &&
                              Say(
                                    ReferenceUnit, 
                                    "BotTeamUpdateSay")
                        ) &&
                        // Sequence name :HumanTeamAverageLevel
                        (
                              GetUnitPosition(
                                    out SampleBotPosition, 
                                    ReferenceUnit) &&
                              GetUnitsInTargetArea(
                                    out HumanTeam, 
                                    ReferenceUnit, 
                                    SampleBotPosition, 
                                    20000, 
                                    AffectEnemies,AffectHeroes, 
                                    "") &&
                              GetCollectionCount(
                                    out HumanTeamCount, 
                                    HumanTeam) &&
                              GreaterInt(
                                    HumanTeamCount, 
                                    0) &&
                              HumanTeam.ForEach( Human => (                                    // Sequence name :IncrementTotalByHumanLevel
                                    (
                                          GetUnitLevel(
                                                out HumanLevel, 
                                                Human) &&
                                          AddInt(
                                                out HumanTeamTotalLevel, 
                                                HumanTeamTotalLevel, 
                                                HumanLevel)
                                    )
                              ) &&
                              DivideInt(
                                    out HumanTeamAverageLevel, 
                                    HumanTeamTotalLevel, 
                                    HumanTeamCount) &&
                              AddString(
                                    out "HumanTeamUpdateSay", 
                                    HumanTeamAverageLevel, 
                                    HumanTeamAverageLevel) &&
                              Say(
                                    ReferenceUnit, 
                                    "HumanTeamUpdateSay")
                        ) &&
                        // Sequence name :ContinueHereIf
                        (
                              GreaterEqualInt(
                                    HumanTeamAverageLevel, 
                                    4)
                        ) &&
                        // Sequence name :NormalizeBasedOnDisparity
                        (
                              // Sequence name :If Bot Team is Winning
                              (
                                    GreaterInt(
                                          BotTeamAverageLevel, 
                                          HumanTeamAverageLevel) &&
                                    SubtractInt(
                                          out LevelDisparity, 
                                          BotTeamAverageLevel, 
                                          HumanTeamAverageLevel)
                              ) ||
                              // Sequence name :Lose Reactions Based on Difficulty
                              (
                                    // Sequence name :EASY: If Bot Team is Losing
                                    (
                                          DifficultyIndex == 0 &&
                                          Say(
                                                ReferenceUnit, 
                                                NO BONUS)
                                    ) ||
                                    // Sequence name :INTERMEDIATE: If Bot Team is Losing
                                    (
                                          DifficultyIndex == 1 &&
                                          LessEqualInt(
                                                BotTeamAverageLevel, 
                                                HumanTeamAverageLevel) &&
                                          SubtractInt(
                                                out LevelDisparity, 
                                                HumanTeamAverageLevel, 
                                                BotTeamAverageLevel) &&
                                          SetVarFloat(
                                                out AdditionalEXPValue, 
                                                7) &&
                                          SetVarFloat(
                                                out EXPModifier, 
                                                1) &&
                                          // Sequence name :DetermineOverallModifiedXPValue
                                          (
                                                MultiplyFloat(
                                                      out EXPModifierIncrement, 
                                                      LevelDisparity, 
                                                      0.55) &&
                                                AddFloat(
                                                      out EXPModifier, 
                                                      EXPModifier, 
                                                      EXPModifierIncrement) &&
                                                MultiplyFloat(
                                                      out AdditionalEXPValue, 
                                                      AdditionalEXPValue, 
                                                      EXPModifier)
                                          ) &&
                                          BotTeam.ForEach( Bot => (
                                                // Sequence name :INCREMENT CHEAT XP LEVEL
                                                (
                                                      GiveChampionExp(
                                                            Bot, 
                                                            AdditionalEXPValue) &&
                                                      AddString(
                                                            out "CheatXPValue", 
                                                            EXPCHEAT:, 
                                                            AdditionalEXPValue) &&
                                                      Say(
                                                            Bot, 
                                                            "CheatXPValue")
                                                )
                                          )
                                    )
                              )
                        ) &&
                        // Sequence name :GeneralGoldNormalizing
                        (
                              BotTeam.ForEach( Bot => (
                                    // Sequence name :Sequence
                                    (
                                          GiveChampionGold(
                                                Bot, 
                                                8) &&
                                          Say(
                                                Bot, 
                                                BLING)

                                    )
                              )
                        )
                  )
            );
      }
}

