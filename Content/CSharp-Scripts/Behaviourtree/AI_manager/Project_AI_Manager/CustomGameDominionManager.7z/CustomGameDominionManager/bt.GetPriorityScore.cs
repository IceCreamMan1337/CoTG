using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class GetPriorityScore : BehaviourTree 
{
      out float PriorityScore;
      float FriendlyStrength;
      float EnemyStrength;
      float ChampionPointValue;
      AttackableUnit CapturePoint;
      TeamEnum ReferenceTeam;
      int DifficultyIndex;

      bool GetPriorityScore()
      {
      return
            // Sequence name :GetPriorityScore
            (
                  // Sequence name :Beginner
                  (
                        DifficultyIndex == 0 &&
                        GetUnitTeam(
                              out CPTeam, 
                              CapturePoint) &&
                        SubtractFloat(
                              out Temp1, 
                              EnemyStrength, 
                              FriendlyStrength) &&
                        MultiplyFloat(
                              out Temp2, 
                              ChampionPointValue, 
                              4) &&
                        DivideFloat(
                              out ThreatScore, 
                              Temp1, 
                              Temp2) &&
                        // Sequence name :Selector
                        (
                              // Sequence name :Sequence
                              (
                                    CPTeam == ReferenceTeam &&
                                    LessFloat(
                                          EnemyStrength, 
                                          ChampionPointValue) &&
                                    SetVarFloat(
                                          out PriorityScore, 
                                          0.1)
                              ) ||
                              // Sequence name :Sequence
                              (
                                    AbsFloat(
                                          out ThreatScore, 
                                          ThreatScore) &&
                                    InterpolateLine(
                                          out PriorityScore, 
                                          0, 
                                          1, 
                                          1, 
                                          0, 
                                          0, 
                                          1, 
                                          ThreatScore)
                              )
                        )
                  ) ||
                  // Sequence name :NotBeginner
                  (
                        NotEqualInt(
                              DifficultyIndex, 
                              0) &&
                        GetUnitTeam(
                              out CPTeam, 
                              CapturePoint) &&
                        SubtractFloat(
                              out Temp1, 
                              EnemyStrength, 
                              FriendlyStrength) &&
                        MultiplyFloat(
                              out Temp2, 
                              ChampionPointValue, 
                              6) &&
                        DivideFloat(
                              out ThreatScore, 
                              Temp1, 
                              Temp2) &&
                        // Sequence name :Selector
                        (
                              // Sequence name :Sequence
                              (
                                    CPTeam == ReferenceTeam &&
                                    LessFloat(
                                          EnemyStrength, 
                                          ChampionPointValue) &&
                                    SetVarFloat(
                                          out PriorityScore, 
                                          0.1)
                              ) ||
                              // Sequence name :Sequence
                              (
                                    AbsFloat(
                                          out ThreatScore, 
                                          ThreatScore) &&
                                    InterpolateLine(
                                          out PriorityScore, 
                                          0, 
                                          1, 
                                          1.5, 
                                          0, 
                                          0, 
                                          1, 
                                          ThreatScore)

                              )
                        )
                  )
            );
      }
}

