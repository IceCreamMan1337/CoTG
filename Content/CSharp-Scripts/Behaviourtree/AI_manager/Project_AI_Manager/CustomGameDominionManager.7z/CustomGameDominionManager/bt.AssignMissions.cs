using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class AssignMissions : BehaviourTree 
{
      out int PreviousOwnedCPCount;
      out int PreviousNeutralCPCount;
      out int PreviousEnemyCPCount;
      out float NextUpdateTime;
      int OwnedCPCount;
      int NeutralCPCount;
      int EnemyCPCount;
      AttackableUnit CapturePointA;
      AttackableUnit CapturePointB;
      AttackableUnit CapturePointC;
      AttackableUnit CapturePointD;
      AttackableUnit CapturePointE;
      TeamEnum ReferenceTeam;
      float ChampionPointValue;
      AISquad CapturePointASquad;
      AISquad CapturePointBSquad;
      AISquad CapturePointCSquad;
      AISquad CapturePointDSquad;
      AISquad CapturePointESquad;
      Vector3CapturePointAPosition;
      Vector3CapturePointBPosition;
      Vector3CapturePointCPosition;
      Vector3CapturePointDPosition;
      Vector3CapturePointEPosition;
      float StrengthEvaluatorRadius;
      float MinionPointValue;
      float CPPointValue;
      int UpdateLimit;
      int PreviousOwnedCPCount;
      int PreviousNeutralCPCount;
      int PreviousEnemyCPCount;
      float NextUpdateTime;
      int DifficultyIndex;
      AISquad WaitInBaseSquad;
      bool DisconnectAdjustmentEnabled;

      bool AssignMissions()
      {
      return
            // Sequence name :Sequence
            (
                  GetAIManagerEntities(
                        out AIEntities, 
                        out AIEntities) &&
                  SetVarInt(
                        out NeedOffsetA, 
                        0) &&
                  SetVarInt(
                        out NeedOffsetB, 
                        0) &&
                  SetVarInt(
                        out NeedOffsetC, 
                        0) &&
                  SetVarInt(
                        out NeedOffsetD, 
                        0) &&
                  SetVarInt(
                        out NeedOffsetE, 
                        0) &&
                  SetVarFloat(
                        out StrengthOffsetA, 
                        0) &&
                  SetVarFloat(
                        out StrengthOffsetB, 
                        0) &&
                  SetVarFloat(
                        out StrengthOffsetC, 
                        0) &&
                  SetVarFloat(
                        out StrengthOffsetD, 
                        0) &&
                  SetVarFloat(
                        out StrengthOffsetE, 
                        0) &&
                  SetVarFloat(
                        out TopPointScoreModifier, 
                        1.2) &&
                  SetVarFloat(
                        out MidPointScoreModifier, 
                        1.1) &&
                  SetVarFloat(
                        out BasePointScoreModifier, 
                        1.1) &&
                  SetVarFloat(
                        out MaxDistance, 
                        14000) &&
                  SetVarFloat(
                        out DistanceNormalizer, 
                        21000) &&
                  SetVarFloat(
                        out StrengthOffset, 
                        ChampionPointValue) &&
                  SetVarInt(
                        out CurrentEntityID, 
                        0) &&
                  SetVarInt(
                        out DisconnectAdjustmentEntityID, 
                        3) &&
                  SetVarBool(
                        out DisconnectAdjustmentNeeded, 
                        False) &&
                  // Sequence name :StrengthOffsetModifier
                  (
                        // Sequence name :Beginner
                        (
                              DifficultyIndex == 0 &&
                              MultiplyFloat(
                                    out StrengthOffset, 
                                    StrengthOffset, 
                                    1)
                        ) ||
                        // Sequence name :IntermediateAdvanced
                        (
                              GreaterInt(
                                    DifficultyIndex, 
                                    0) &&
                              MultiplyFloat(
                                    out StrengthOffset, 
                                    StrengthOffset, 
                                    2)
                        )
                  ) &&
                  // Sequence name :DynamicAssignments
                  (
                        // Sequence name :MaskFailure
                        (
                              AIEntities.ForEach( Entity => (
                                    // Sequence name :Sequence
                                    (
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :DisconnectAdjustment
                                                (
                                                      DisconnectAdjustmentEnabled == true &&
                                                      CurrentEntityID == DisconnectAdjustmentEntityID &&
                                                      // Sequence name :GetEnemyTeam
                                                      (
                                                            // Sequence name :IsOrder
                                                            (
                                                                  ReferenceTeam == TeamId.TEAM_BLUE &&
                                                                  SetVarUnitTeam(
                                                                        out EnemyTeam, 
                                                                        TeamId.TEAM_PURPLE)
                                                            ) ||
                                                            // Sequence name :IsChaos
                                                            (
                                                                  ReferenceTeam == TeamId.TEAM_PURPLE &&
                                                                  SetVarUnitTeam(
                                                                        out EnemyTeam, 
                                                                        TeamId.TEAM_BLUE)
                                                            )
                                                      ) &&
                                                      GetNumberOfConnectedPlayers(
                                                            out ConnectedPlayersOnEnemyTeam, 
                                                            EnemyTeam) &&
                                                      LessInt(
                                                            ConnectedPlayersOnEnemyTeam, 
                                                            5) &&
                                                      AddAIEntityToSquad(
                                                            Entity, 
                                                            WaitInBaseSquad) &&
                                                      SetVarBool(
                                                            out DisconnectAdjustmentNeeded, 
                                                            true)
                                                )
                                          ) &&
                                          AddInt(
                                                out CurrentEntityID, 
                                                CurrentEntityID, 
                                                1)
                                    )
                              )
                        ) &&
                        SetVarInt(
                              out CurrentEntityID, 
                              0) &&
                        // Sequence name :UpdateConditions
                        (
                              // Sequence name :TimeToUpdate
                              (
                                    GetGameTime(
                                          out CurrentGameTime, 
                                          out CurrentGameTime) &&
                                    GreaterFloat(
                                          CurrentGameTime, 
                                          NextUpdateTime)
                              ) ||
                              NotEqualInt(
                                    EnemyCPCount, 
                                    PreviousEnemyCPCount)                              NotEqualInt(
                                    NeutralCPCount, 
                                    PreviousNeutralCPCount)                              NotEqualInt(
                                    OwnedCPCount, 
                                    PreviousOwnedCPCount)
                        ) &&
                        AIEntities.ForEach( Entity => (                              // Sequence name :Sequence
                              (
                                    // Sequence name :ParseEntities
                                    (
                                          TestUnitHasBuff(
                                                Entity, 
                                                , 
                                                OdinGuardianStatsByLevel, 
                                                true)                                          TestUnitCondition(
                                                Entity, 
                                                False)                                          TestUnitIsChanneling(
                                                Entity, 
                                                true)                                          // Sequence name :DoNothingIfDisconnectAdjustment
                                          (
                                                DisconnectAdjustmentEnabled == true &&
                                                CurrentEntityID == DisconnectAdjustmentEntityID &&
                                                DisconnectAdjustmentNeeded == true
                                          ) ||
                                          // Sequence name :DoNothingIfReturningToBase
                                          (
                                                TestAIEntityHasTask(
                                                      Entity, 
                                                      DOMINION_RETURN_TO_BASE, 
                                                      , 
                                                      , 
                                                      , 
                                                      true) &&
                                                GetUnitAIBasePosition(
                                                      out BasePosition, 
                                                      Entity) &&
                                                DistanceBetweenObjectAndPoint(
                                                      out DistanceToBase, 
                                                      Entity, 
                                                      BasePosition) &&
                                                GetUnitCurrentHealth(
                                                      out EntityCurrentHealth, 
                                                      Entity) &&
                                                GetUnitMaxHealth(
                                                      out EntityMaxHealth, 
                                                      Entity) &&
                                                DivideFloat(
                                                      out EntityHealthRatio, 
                                                      EntityCurrentHealth, 
                                                      EntityMaxHealth) &&
                                                // Sequence name :SkipConditions
                                                (
                                                      GreaterFloat(
                                                            DistanceToBase, 
                                                            800)                                                      LessFloat(
                                                            EntityHealthRatio, 
                                                            0.95)
                                                )
                                          ) ||
                                          // Sequence name :AssignToPoint
                                          (
                                                // Sequence name :GetStrengthEval
                                                (
                                                      StrengthEvaluationPointA(
                                                            out EnemyStrengthPointA, 
                                                            out FriendlyStrengthPointA, 
                                                            CapturePointAPosition, 
                                                            Entity, 
                                                            StrengthEvaluatorRadius, 
                                                            Value=, 
                                                            Value=, 
                                                            Value=) &&
                                                      StrengthEvaluationPointB(
                                                            out EnemyStrengthPointB, 
                                                            out FriendlyStrengthPointB, 
                                                            CapturePointBPosition, 
                                                            Entity, 
                                                            StrengthEvaluatorRadius, 
                                                            Value=, 
                                                            Value=, 
                                                            Value=) &&
                                                      StrengthEvaluationPointC(
                                                            out EnemyStrengthPointC, 
                                                            out FriendlyStrengthPointC, 
                                                            CapturePointCPosition, 
                                                            Entity, 
                                                            StrengthEvaluatorRadius, 
                                                            Value=, 
                                                            Value=, 
                                                            Value=) &&
                                                      StrengthEvaluationPointD(
                                                            out EnemyStrengthPointD, 
                                                            out FriendlyStrengthPointD, 
                                                            CapturePointDPosition, 
                                                            Entity, 
                                                            StrengthEvaluatorRadius, 
                                                            Value=, 
                                                            Value=, 
                                                            Value=) &&
                                                      StrengthEvaluationPointE(
                                                            out EnemyStrengthPointE, 
                                                            out FriendlyStrengthPointE, 
                                                            CapturePointEPosition, 
                                                            Entity, 
                                                            StrengthEvaluatorRadius, 
                                                            Value=, 
                                                            Value=, 
                                                            Value=) &&
                                                      AddFloat(
                                                            out FriendlyStrengthPointA, 
                                                            FriendlyStrengthPointA, 
                                                            StrengthOffsetA) &&
                                                      AddFloat(
                                                            out FriendlyStrengthPointB, 
                                                            FriendlyStrengthPointB, 
                                                            StrengthOffsetB) &&
                                                      AddFloat(
                                                            out FriendlyStrengthPointC, 
                                                            FriendlyStrengthPointC, 
                                                            StrengthOffsetC) &&
                                                      AddFloat(
                                                            out FriendlyStrengthPointD, 
                                                            FriendlyStrengthPointD, 
                                                            StrengthOffsetD) &&
                                                      AddFloat(
                                                            out FriendlyStrengthPointE, 
                                                            FriendlyStrengthPointE, 
                                                            StrengthOffsetE)
                                                ) &&
                                                // Sequence name :GetPriority
                                                (
                                                      GetPriorityScore(
                                                            out PriorityA, 
                                                            FriendlyStrengthPointA, 
                                                            EnemyStrengthPointA, 
                                                            Value=, 
                                                            CapturePointA, 
                                                            ReferenceTeam, 
                                                            DifficultyIndex) &&
                                                      GetPriorityScore(
                                                            out PriorityB, 
                                                            FriendlyStrengthPointB, 
                                                            EnemyStrengthPointB, 
                                                            Value=, 
                                                            CapturePointB, 
                                                            ReferenceTeam, 
                                                            DifficultyIndex) &&
                                                      GetPriorityScore(
                                                            out PriorityC, 
                                                            FriendlyStrengthPointC, 
                                                            EnemyStrengthPointC, 
                                                            Value=, 
                                                            CapturePointC, 
                                                            ReferenceTeam, 
                                                            DifficultyIndex) &&
                                                      GetPriorityScore(
                                                            out PriorityD, 
                                                            FriendlyStrengthPointD, 
                                                            EnemyStrengthPointD, 
                                                            Value=, 
                                                            CapturePointD, 
                                                            ReferenceTeam, 
                                                            DifficultyIndex) &&
                                                      GetPriorityScore(
                                                            out PriorityE, 
                                                            FriendlyStrengthPointE, 
                                                            EnemyStrengthPointE, 
                                                            Value=, 
                                                            CapturePointE, 
                                                            ReferenceTeam, 
                                                            DifficultyIndex)
                                                ) &&
                                                // Sequence name :GetDistanceNeedPairScores
                                                (
                                                      GetDistanceBetweenUnits(
                                                            out DistanceA, 
                                                            Entity, 
                                                            CapturePointA) &&
                                                      GetDistanceBetweenUnits(
                                                            out DistanceB, 
                                                            Entity, 
                                                            CapturePointB) &&
                                                      GetDistanceBetweenUnits(
                                                            out DistanceC, 
                                                            Entity, 
                                                            CapturePointC) &&
                                                      GetDistanceBetweenUnits(
                                                            out DistanceD, 
                                                            Entity, 
                                                            CapturePointD) &&
                                                      GetDistanceBetweenUnits(
                                                            out DistanceE, 
                                                            Entity, 
                                                            CapturePointE) &&
                                                      SubtractFloat(
                                                            out DistanceA, 
                                                            MaxDistance, 
                                                            DistanceA) &&
                                                      SubtractFloat(
                                                            out DistanceB, 
                                                            MaxDistance, 
                                                            DistanceB) &&
                                                      SubtractFloat(
                                                            out DistanceC, 
                                                            MaxDistance, 
                                                            DistanceC) &&
                                                      SubtractFloat(
                                                            out DistanceD, 
                                                            MaxDistance, 
                                                            DistanceD) &&
                                                      SubtractFloat(
                                                            out DistanceE, 
                                                            MaxDistance, 
                                                            DistanceE) &&
                                                      DivideFloat(
                                                            out DistanceA, 
                                                            DistanceA, 
                                                            DistanceNormalizer) &&
                                                      DivideFloat(
                                                            out DistanceB, 
                                                            DistanceB, 
                                                            DistanceNormalizer) &&
                                                      DivideFloat(
                                                            out DistanceC, 
                                                            DistanceC, 
                                                            DistanceNormalizer) &&
                                                      DivideFloat(
                                                            out DistanceD, 
                                                            DistanceD, 
                                                            DistanceNormalizer) &&
                                                      DivideFloat(
                                                            out DistanceE, 
                                                            DistanceE, 
                                                            DistanceNormalizer) &&
                                                      MultiplyFloat(
                                                            out PairScoreA, 
                                                            DistanceA, 
                                                            PriorityA) &&
                                                      MultiplyFloat(
                                                            out PairScoreB, 
                                                            DistanceB, 
                                                            PriorityB) &&
                                                      MultiplyFloat(
                                                            out PairScoreC, 
                                                            DistanceC, 
                                                            PriorityC) &&
                                                      MultiplyFloat(
                                                            out PairScoreD, 
                                                            DistanceD, 
                                                            PriorityD) &&
                                                      MultiplyFloat(
                                                            out PairScoreE, 
                                                            DistanceE, 
                                                            PriorityE)
                                                ) &&
                                                // Sequence name :InflateScoresForPointsBySide
                                                (
                                                      MultiplyFloat(
                                                            out PairScoreC, 
                                                            PairScoreC, 
                                                            TopPointScoreModifier) &&
                                                      GetUnitTeam(
                                                            out EntityTeam, 
                                                            Entity) &&
                                                      // Sequence name :WhichSide?
                                                      (
                                                            // Sequence name :Chaos
                                                            (
                                                                  EntityTeam == TeamId.TEAM_PURPLE &&
                                                                  MultiplyFloat(
                                                                        out PairScoreD, 
                                                                        PairScoreD, 
                                                                        MidPointScoreModifier) &&
                                                                  MultiplyFloat(
                                                                        out PairScoreE, 
                                                                        PairScoreE, 
                                                                        BasePointScoreModifier)
                                                            ) ||
                                                            // Sequence name :Order
                                                            (
                                                                  EntityTeam == TeamId.TEAM_BLUE &&
                                                                  MultiplyFloat(
                                                                        out PairScoreB, 
                                                                        PairScoreB, 
                                                                        MidPointScoreModifier) &&
                                                                  MultiplyFloat(
                                                                        out PairScoreA, 
                                                                        PairScoreA, 
                                                                        BasePointScoreModifier)
                                                            )
                                                      )
                                                ) &&
                                                // Sequence name :GetBestScore
                                                (
                                                      SetVarFloat(
                                                            out BestScore, 
                                                            -1) &&
                                                      SetVarInt(
                                                            out PointID, 
                                                            -1) &&
                                                      // Sequence name :MaskFailure
                                                      (
                                                            // Sequence name :Sequence
                                                            (
                                                                  GreaterFloat(
                                                                        PairScoreA, 
                                                                        BestScore) &&
                                                                  SetVarFloat(
                                                                        out BestScore, 
                                                                        PairScoreA) &&
                                                                  SetVarInt(
                                                                        out PointID, 
                                                                        0)
                                                            )
                                                      ) &&
                                                      // Sequence name :MaskFailure
                                                      (
                                                            // Sequence name :Sequence
                                                            (
                                                                  GreaterFloat(
                                                                        PairScoreB, 
                                                                        BestScore) &&
                                                                  SetVarFloat(
                                                                        out BestScore, 
                                                                        PairScoreB) &&
                                                                  SetVarInt(
                                                                        out PointID, 
                                                                        1)
                                                            )
                                                      ) &&
                                                      // Sequence name :MaskFailure
                                                      (
                                                            // Sequence name :Sequence
                                                            (
                                                                  GreaterFloat(
                                                                        PairScoreC, 
                                                                        BestScore) &&
                                                                  SetVarFloat(
                                                                        out BestScore, 
                                                                        PairScoreC) &&
                                                                  SetVarInt(
                                                                        out PointID, 
                                                                        2)
                                                            )
                                                      ) &&
                                                      // Sequence name :MaskFailure
                                                      (
                                                            // Sequence name :Sequence
                                                            (
                                                                  GreaterFloat(
                                                                        PairScoreD, 
                                                                        BestScore) &&
                                                                  SetVarFloat(
                                                                        out BestScore, 
                                                                        PairScoreD) &&
                                                                  SetVarInt(
                                                                        out PointID, 
                                                                        3)
                                                            )
                                                      ) &&
                                                      // Sequence name :MaskFailure
                                                      (
                                                            // Sequence name :Sequence
                                                            (
                                                                  GreaterFloat(
                                                                        PairScoreE, 
                                                                        BestScore) &&
                                                                  SetVarFloat(
                                                                        out BestScore, 
                                                                        PairScoreE) &&
                                                                  SetVarInt(
                                                                        out PointID, 
                                                                        4)
                                                            )
                                                      )
                                                ) &&
                                                // Sequence name :AssignToSquad
                                                (
                                                      // Sequence name :PointA
                                                      (
                                                            PointID == 0 &&
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointASquad) &&
                                                            // Sequence name :MaskFailure
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        GetDistanceBetweenUnits(
                                                                              out DistanceToPoint, 
                                                                              Entity, 
                                                                              CapturePointA) &&
                                                                        GreaterFloat(
                                                                              DistanceToPoint, 
                                                                              StrengthEvaluatorRadius) &&
                                                                        AddFloat(
                                                                              out StrengthOffsetA, 
                                                                              StrengthOffsetA, 
                                                                              StrengthOffset)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :PointB
                                                      (
                                                            PointID == 1 &&
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointBSquad) &&
                                                            // Sequence name :MaskFailure
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        GetDistanceBetweenUnits(
                                                                              out DistanceToPoint, 
                                                                              Entity, 
                                                                              CapturePointB) &&
                                                                        GreaterFloat(
                                                                              DistanceToPoint, 
                                                                              StrengthEvaluatorRadius) &&
                                                                        AddFloat(
                                                                              out StrengthOffsetB, 
                                                                              StrengthOffsetB, 
                                                                              StrengthOffset)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :PointC
                                                      (
                                                            PointID == 2 &&
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointCSquad) &&
                                                            // Sequence name :MaskFailure
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        GetDistanceBetweenUnits(
                                                                              out DistanceToPoint, 
                                                                              Entity, 
                                                                              CapturePointC) &&
                                                                        GreaterFloat(
                                                                              DistanceToPoint, 
                                                                              StrengthEvaluatorRadius) &&
                                                                        AddFloat(
                                                                              out StrengthOffsetC, 
                                                                              StrengthOffsetC, 
                                                                              StrengthOffset)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :PointD
                                                      (
                                                            PointID == 3 &&
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointDSquad) &&
                                                            // Sequence name :MaskFailure
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        GetDistanceBetweenUnits(
                                                                              out DistanceToPoint, 
                                                                              Entity, 
                                                                              CapturePointD) &&
                                                                        GreaterFloat(
                                                                              DistanceToPoint, 
                                                                              StrengthEvaluatorRadius) &&
                                                                        AddFloat(
                                                                              out StrengthOffsetD, 
                                                                              StrengthOffsetD, 
                                                                              StrengthOffset)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :PointE
                                                      (
                                                            PointID == 4 &&
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointESquad) &&
                                                            // Sequence name :MaskFailure
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        GetDistanceBetweenUnits(
                                                                              out DistanceToPoint, 
                                                                              Entity, 
                                                                              CapturePointE) &&
                                                                        GreaterFloat(
                                                                              DistanceToPoint, 
                                                                              StrengthEvaluatorRadius) &&
                                                                        AddFloat(
                                                                              out StrengthOffsetE, 
                                                                              StrengthOffsetE, 
                                                                              StrengthOffset)
                                                                  )
                                                            )
                                                      )
                                                )
                                          )
                                    ) &&
                                    AddInt(
                                          out CurrentEntityID, 
                                          CurrentEntityID, 
                                          1)
                              )
                        ) &&
                        // Sequence name :UpdateParameters
                        (
                              SetVarInt(
                                    out PreviousEnemyCPCount, 
                                    EnemyCPCount) &&
                              SetVarInt(
                                    out PreviousOwnedCPCount, 
                                    OwnedCPCount) &&
                              SetVarInt(
                                    out PreviousNeutralCPCount, 
                                    NeutralCPCount) &&
                              // Sequence name :NextUpdateTimeBasedOnDifficulty
                              (
                                    // Sequence name :Beginner
                                    (
                                          DifficultyIndex == 0 &&
                                          GetGameScore(
                                                out OrderScore, 
                                                TeamId.TEAM_BLUE) &&
                                          GetGameScore(
                                                out ChaosScore, 
                                                TeamId.TEAM_PURPLE) &&
                                          SubtractFloat(
                                                out ScoreDiff, 
                                                ChaosScore, 
                                                OrderScore) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :Sequence
                                                (
                                                      ReferenceTeam == TeamId.TEAM_BLUE &&
                                                      MultiplyFloat(
                                                            out ScoreDiff, 
                                                            ScoreDiff, 
                                                            -1)
                                                )
                                          ) &&
                                          DivideFloat(
                                                out UpdateModifier, 
                                                ScoreDiff, 
                                                30) &&
                                          MinFloat(
                                                out UpdateModifier, 
                                                UpdateModifier, 
                                                5) &&
                                          MaxFloat(
                                                out UpdateModifier, 
                                                UpdateModifier, 
                                                -5) &&
                                          AddFloat(
                                                out MinUpdateDelay, 
                                                10, 
                                                UpdateModifier) &&
                                          AddFloat(
                                                out MaxUpdateDelay, 
                                                MinUpdateDelay, 
                                                5) &&
                                          GenerateRandomFloat(
                                                out temp, 
                                                Value=, 
                                                Value=) &&
                                          AddFloat(
                                                out NextUpdateTime, 
                                                CurrentGameTime, 
                                                temp)
                                    ) ||
                                    // Sequence name :Intermediate
                                    (
                                          DifficultyIndex == 1 &&
                                          GenerateRandomFloat(
                                                out temp, 
                                                Value=, 
                                                Value=) &&
                                          AddFloat(
                                                out NextUpdateTime, 
                                                CurrentGameTime, 
                                                temp)
                                    ) ||
                                    // Sequence name :Advanced
                                    (
                                          DifficultyIndex == 2 &&
                                          AddFloat(
                                                out NextUpdateTime, 
                                                CurrentGameTime, 
                                                1)

                                    )
                              )
                        )
                  )
            );
      }
}

