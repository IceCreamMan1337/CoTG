using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class CalculateNeed : BehaviourTree 
{
      out int Need;
      AttackableUnit CapturePoint;
      float StrDiff;
      float ChampionPointValue;
      TeamEnum ReferenceTeam;
      int OwnedCPCount;
      int EnemyCPCount;

      bool CalculateNeed()
      {
      return
            // Sequence name :CalculateNeed
            (
                  GetUnitTeam(
                        out CPTeam, 
                        CapturePoint) &&
                  DivideFloat(
                        out TempNeed, 
                        StrDiff, 
                        ChampionPointValue) &&
                  // Sequence name :Selector
                  (
                        // Sequence name :MatchIfNeutral
                        (
                              CPTeam == TeamId.TEAM_NEUTRAL &&
                              NumberToSend(
                                    out Need, 
                                    TempNeed) &&
                              AddInt(
                                    out Need, 
                                    Need, 
                                    1)
                        ) ||
                        // Sequence name :AssessIfEnemy
                        (
                              NotEqualUnitTeam(
                                    CPTeam, 
                                    ReferenceTeam) &&
                              // Sequence name :Assess
                              (
                                    // Sequence name :Undefended
                                    (
                                          LessFloat(
                                                StrDiff, 
                                                ChampionPointValue) &&
                                          SetVarInt(
                                                out Need, 
                                                2)
                                    ) ||
                                    // Sequence name :Losing
                                    (
                                          LessInt(
                                                OwnedCPCount, 
                                                EnemyCPCount) &&
                                          NumberToSend(
                                                out Need, 
                                                TempNeed) &&
                                          AddInt(
                                                out Need, 
                                                Need, 
                                                1)
                                    )
                              )
                        ) ||
                        // Sequence name :DefendIfOwnedAndThreatened
                        (
                              // Sequence name :Threatened
                              (
                                    GreaterFloat(
                                          StrDiff, 
                                          0) &&
                                    NumberToSend(
                                          out Need, 
                                          TempNeed) &&
                                    AddInt(
                                          out Need, 
                                          Need, 
                                          1)
                              ) ||
                              SetVarInt(
                                    out Need, 
                                    0)

                        )
                  )
            );
      }
}

