using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class CustomGameDominionAIManager_Logic : BehaviourTree 
{

      // Sequence name :CustomGameDominionManager.CustomGameDominionAIManager_Logic
      (
            // Sequence name :Sequence
            (
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :Initialization
                        (
                              TestAIFirstTime(
                                    true) &&
                              GetWorldLocationByName(
                                    out CapturePointAPosition, 
                                    CapturePointA) &&
                              GetWorldLocationByName(
                                    out CapturePointBPosition, 
                                    CapturePointB) &&
                              GetWorldLocationByName(
                                    out CapturePointCPosition, 
                                    CapturePointC) &&
                              GetWorldLocationByName(
                                    out CapturePointDPosition, 
                                    CapturePointD) &&
                              GetWorldLocationByName(
                                    out CapturePointEPosition, 
                                    CapturePointE) &&
                              CreateAISquad(
                                    out CapturePointASquad, 
                                    5) &&
                              CreateAISquad(
                                    out CapturePointBSquad, 
                                    5) &&
                              CreateAISquad(
                                    out CapturePointCSquad, 
                                    5) &&
                              CreateAISquad(
                                    out CapturePointDSquad, 
                                    5) &&
                              CreateAISquad(
                                    out CapturePointESquad, 
                                    5) &&
                              CreateAISquad(
                                    out WaitInBaseSquad, 
                                    5) &&
                              CreateAIMission(
                                    out CapturePointA, 
                                    SUPPORT, 
                                    , 
                                    CapturePointAPosition, 
                                    ) &&
                              CreateAIMission(
                                    out CapturePointB, 
                                    SUPPORT, 
                                    , 
                                    CapturePointBPosition, 
                                    ) &&
                              CreateAIMission(
                                    out CapturePointC, 
                                    SUPPORT, 
                                    , 
                                    CapturePointCPosition, 
                                    ) &&
                              CreateAIMission(
                                    out CapturePointD, 
                                    SUPPORT, 
                                    , 
                                    CapturePointDPosition, 
                                    ) &&
                              CreateAIMission(
                                    out CapturePointE, 
                                    SUPPORT, 
                                    , 
                                    CapturePointEPosition, 
                                    ) &&
                              CreateAIMission(
                                    out WaitInBaseMission, 
                                    DEFEND, 
                                    , 
                                    , 
                                    ) &&
                              AssignAIMission(
                                    CapturePointASquad, 
                                    CapturePointA) &&
                              AssignAIMission(
                                    CapturePointBSquad, 
                                    CapturePointB) &&
                              AssignAIMission(
                                    CapturePointCSquad, 
                                    CapturePointC) &&
                              AssignAIMission(
                                    CapturePointDSquad, 
                                    CapturePointD) &&
                              AssignAIMission(
                                    CapturePointESquad, 
                                    CapturePointE) &&
                              AssignAIMission(
                                    WaitInBaseSquad, 
                                    WaitInBaseMission) &&
                              SetVarFloat(
                                    out MinionPointValue, 
                                    20) &&
                              SetVarFloat(
                                    out ChampionPointValue, 
                                    100) &&
                              SetVarFloat(
                                    out CPPointValue, 
                                    0) &&
                              SetVarBool(
                                    out CapturePointsFound, 
                                    False) &&
                              SetVarFloat(
                                    out StrengthEvaluatorRadius, 
                                    1600) &&
                              SetVarBool(
                                    out Opened, 
                                    False) &&
                              SetVarInt(
                                    out UpdateLimit, 
                                    1) &&
                              SetVarInt(
                                    out PreviousEnemyCPCount, 
                                    0) &&
                              SetVarInt(
                                    out PreviousNeutralCPCount, 
                                    0) &&
                              SetVarInt(
                                    out PreviousOwnedCPCount, 
                                    0) &&
                              SetVarBool(
                                    out DisconnectAdjustmentEnabled, 
                                    False) &&
                              UpdateDistributionTime_Initialization(
                                    out IsBeingCapturedA, 
                                    out IsBeingCapturedB, 
                                    out IsBeingCapturedC, 
                                    out IsBeingCapturedD, 
                                    out IsBeingCapturedE, 
                                    out IsBeingCapturedA, 
                                    out IsBeingCapturedB, 
                                    out IsBeingCapturedC, 
                                    out IsBeingCapturedD, 
                                    out IsBeingCapturedE) &&
                              SetVarFloat(
                                    out NextUpdateTime, 
                                    0) &&
                              SetVarFloat(
                                    out LastGoldScalingUpdateTime, 
                                    0) &&
                              SetVarInt(
                                    out DifficultyIndex, 
                                    1)
                        )
                  ) &&
                  // Sequence name :HasEntities
                  (
                        GetAIManagerEntities(
                              out AllEntities, 
                              out AllEntities) &&
                        AllEntities.ForEach( Entity => (                              SetVarAttackableUnit(
                                    out ReferenceUnit, 
                                    Entity)
                        ) &&
                        TestUnitHasBuff(
                              ReferenceUnit, 
                              , 
                              OdinGuardianStatsByLevel, 
                              False) &&
                        GetUnitTeam(
                              out ReferenceTeam, 
                              ReferenceUnit)
                  ) &&
                  // Sequence name :Init_GetCapturePoints
                  (
                        CapturePointsFound == true                        // Sequence name :GetCapturePoints
                        (
                              GetUnitsInTargetArea(
                                    out CapPointAColl, 
                                    ReferenceUnit, 
                                    CapturePointAPosition, 
                                    500, 
                                    AffectEnemies,AffectFriends,AffectMinions,AffectNeutral,AffectUseable, 
                                    "") &&
                              GetUnitsInTargetArea(
                                    out CapPointBColl, 
                                    ReferenceUnit, 
                                    CapturePointBPosition, 
                                    500, 
                                    AffectEnemies,AffectFriends,AffectMinions,AffectNeutral,AffectUseable, 
                                    "") &&
                              GetUnitsInTargetArea(
                                    out CapPointCColl, 
                                    ReferenceUnit, 
                                    CapturePointCPosition, 
                                    500, 
                                    AffectEnemies,AffectFriends,AffectMinions,AffectNeutral,AffectUseable, 
                                    "") &&
                              GetUnitsInTargetArea(
                                    out CapPointDColl, 
                                    ReferenceUnit, 
                                    CapturePointDPosition, 
                                    500, 
                                    AffectEnemies,AffectFriends,AffectMinions,AffectNeutral,AffectUseable, 
                                    "") &&
                              GetUnitsInTargetArea(
                                    out CapPointEColl, 
                                    ReferenceUnit, 
                                    CapturePointEPosition, 
                                    500, 
                                    AffectEnemies,AffectFriends,AffectMinions,AffectNeutral,AffectUseable, 
                                    "") &&
                              CapPointAColl.ForEach( CapturePoint => (                                    SetVarAttackableUnit(
                                          out CapturePointA, 
                                          CapturePoint)
                              ) &&
                              CapPointBColl.ForEach( CapturePoint => (                                    SetVarAttackableUnit(
                                          out CapturePointB, 
                                          CapturePoint)
                              ) &&
                              CapPointCColl.ForEach( CapturePoint => (                                    SetVarAttackableUnit(
                                          out CapturePointC, 
                                          CapturePoint)
                              ) &&
                              CapPointDColl.ForEach( CapturePoint => (                                    SetVarAttackableUnit(
                                          out CapturePointD, 
                                          CapturePoint)
                              ) &&
                              CapPointEColl.ForEach( CapturePoint => (                                    SetVarAttackableUnit(
                                          out CapturePointE, 
                                          CapturePoint)
                              ) &&
                              SetVarBool(
                                    out CapturePointsFound, 
                                    true)
                        )
                  ) &&
                  CountCapturePointsOwned(
                        out EnemyCPCount, 
                        out OwnedCPCount, 
                        out NeutralCPCount, 
                        CapturePointA, 
                        CapturePointB, 
                        CapturePointC, 
                        CapturePointD, 
                        CapturePointE, 
                        ReferenceTeam) &&
                  GoldScaling(
                        out LastGoldScalingUpdateTime, 
                        DifficultyIndex, 
                        LastGoldScalingUpdateTime, 
                        ReferenceUnit) &&
                  // Sequence name :MaskFailure
                  (
                        // Sequence name :ForceGameToOpen
                        (
                              NotEqualBool(
                                    Opened, 
                                    true) &&
                              GetGameTime(
                                    out GameTime, 
                                    out GameTime) &&
                              // Sequence name :Conditions
                              (
                                    GreaterEqualFloat(
                                          GameTime, 
                                          110)                                    GreaterEqualInt(
                                          OwnedCPCount, 
                                          2)
                              ) &&
                              SetVarBool(
                                    out Opened, 
                                    true)
                        )
                  ) &&
                  // Sequence name :GameLogic
                  (
                        // Sequence name :FixedOpeningStrategy
                        (
                              NotEqualBool(
                                    Opened, 
                                    true) &&
                              SetVarInt(
                                    out BotIndex, 
                                    0) &&
                              AllEntities.ForEach( Entity => (
                                    // Sequence name :Selector
                                    (
                                          TestUnitHasBuff(
                                                Entity, 
                                                , 
                                                OdinGuardianStatsByLevel, 
                                                true)                                          TestUnitCondition(
                                                Entity, 
                                                False)                                          // Sequence name :Sequence
                                          (
                                                // Sequence name :Selector
                                                (
                                                      // Sequence name :Bot0ToBottom
                                                      (
                                                            BotIndex == 0 &&
                                                            // Sequence name :Selector
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        ReferenceTeam == TeamId.TEAM_BLUE &&
                                                                        AddAIEntityToSquad(
                                                                              Entity, 
                                                                              CapturePointASquad)
                                                                  ) ||
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        ReferenceTeam == TeamId.TEAM_PURPLE &&
                                                                        AddAIEntityToSquad(
                                                                              Entity, 
                                                                              CapturePointESquad)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :Bot1ToMid
                                                      (
                                                            BotIndex == 1 &&
                                                            // Sequence name :Selector
                                                            (
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        ReferenceTeam == TeamId.TEAM_BLUE &&
                                                                        AddAIEntityToSquad(
                                                                              Entity, 
                                                                              CapturePointBSquad)
                                                                  ) ||
                                                                  // Sequence name :Sequence
                                                                  (
                                                                        ReferenceTeam == TeamId.TEAM_PURPLE &&
                                                                        AddAIEntityToSquad(
                                                                              Entity, 
                                                                              CapturePointDSquad)
                                                                  )
                                                            )
                                                      ) ||
                                                      // Sequence name :AllOtherBotsToTop
                                                      (
                                                            AddAIEntityToSquad(
                                                                  Entity, 
                                                                  CapturePointCSquad)
                                                      )
                                                ) &&
                                                AddInt(
                                                      out BotIndex, 
                                                      BotIndex, 
                                                      1)
                                          )
                                    )
                              )
                        ) ||
                        // Sequence name :DynamicDistribution
                        (
                              // Sequence name :MaskFailure
                              (
                                    // Sequence name :ForceUpdateIfAllyPointIsBeingCaptured
                                    (
                                          NotEqualInt(
                                                DifficultyIndex, 
                                                0) &&
                                          UpdateDistributionTime_HelperA(
                                                out IsBeingCapturedA, 
                                                out NextUpdateTime, 
                                                ReferenceTeam, 
                                                CapturePointA, 
                                                IsBeingCapturedA, 
                                                NextUpdateTime) &&
                                          UpdateDistributionTime_HelperB(
                                                out IsBeingCapturedB, 
                                                out NextUpdateTime, 
                                                ReferenceTeam, 
                                                CapturePointB, 
                                                IsBeingCapturedB, 
                                                NextUpdateTime) &&
                                          UpdateDistributionTime_HelperC(
                                                out IsBeingCapturedC, 
                                                out NextUpdateTime, 
                                                ReferenceTeam, 
                                                CapturePointC, 
                                                IsBeingCapturedC, 
                                                NextUpdateTime) &&
                                          UpdateDistributionTime_HelperD(
                                                out IsBeingCapturedD, 
                                                out NextUpdateTime, 
                                                ReferenceTeam, 
                                                CapturePointD, 
                                                IsBeingCapturedD, 
                                                NextUpdateTime) &&
                                          UpdateDistributionTime_HelperE(
                                                out IsBeingCapturedE, 
                                                out NextUpdateTime, 
                                                ReferenceTeam, 
                                                CapturePointE, 
                                                IsBeingCapturedE, 
                                                NextUpdateTime)
                                    )
                              ) &&
                              DynamicDistribution(
                                    out PreviousOwnedCPCount, 
                                    out PreviousNeutralCPCount, 
                                    out PreviousEnemyCPCount, 
                                    out NextUpdateTime, 
                                    OwnedCPCount, 
                                    NeutralCPCount, 
                                    EnemyCPCount, 
                                    CapturePointA, 
                                    CapturePointB, 
                                    CapturePointC, 
                                    CapturePointD, 
                                    CapturePointE, 
                                    ReferenceTeam, 
                                    Value=, 
                                    CapturePointASquad, 
                                    CapturePointBSquad, 
                                    CapturePointCSquad, 
                                    CapturePointDSquad, 
                                    CapturePointESquad, 
                                    CapturePointAPosition, 
                                    CapturePointBPosition, 
                                    CapturePointCPosition, 
                                    CapturePointDPosition, 
                                    CapturePointEPosition, 
                                    StrengthEvaluatorRadius, 
                                    Value=, 
                                    Value=, 
                                    UpdateLimit, 
                                    PreviousOwnedCPCount, 
                                    PreviousNeutralCPCount, 
                                    PreviousEnemyCPCount, 
                                    NextUpdateTime, 
                                    DifficultyIndex, 
                                    WaitInBaseSquad, 
                                    DisconnectAdjustmentEnabled)

                        )
                  )
            );
      }
}

