using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class UpdateDistributionTime_Initialization : BehaviourTree 
{
      out bool IsBeingCapturedA;
      out bool IsBeingCapturedB;
      out bool IsBeingCapturedC;
      out bool IsBeingCapturedD;
      out bool IsBeingCapturedE;

      bool UpdateDistributionTime_Initialization()
      {
      return
            // Sequence name :Sequence
            (
                  SetVarBool(
                        out IsBeingCapturedA, 
                        False) &&
                  SetVarBool(
                        out IsBeingCapturedB, 
                        False) &&
                  SetVarBool(
                        out IsBeingCapturedC, 
                        False) &&
                  SetVarBool(
                        out IsBeingCapturedD, 
                        False) &&
                  SetVarBool(
                        out IsBeingCapturedE, 
                        False)

            );
      }
}

