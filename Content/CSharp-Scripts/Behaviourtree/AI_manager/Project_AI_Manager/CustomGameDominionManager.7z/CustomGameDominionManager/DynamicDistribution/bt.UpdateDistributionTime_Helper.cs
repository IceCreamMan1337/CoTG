using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class UpdateDistributionTime_Helper : BehaviourTree 
{
      out bool IsBeingCaptured;
      out float NextUpdateTime;
      TeamEnum ReferenceTeam;
      AttackableUnit CapturePoint;
      bool IsBeingCaptured;
      float NextUpdateTime;

      bool UpdateDistributionTime_Helper()
      {
      return
            // Sequence name :MaskFailure
            (
                  // Sequence name :Sequence
                  (
                        GetUnitBuffCount(
                              out Count, 
                              CapturePoint, 
                              OdinGuardianSuppression) &&
                        // Sequence name :Selector
                        (
                              // Sequence name :NotBeingCaptured
                              (
                                    Count == 0 &&
                                    SetVarBool(
                                          out IsBeingCaptured, 
                                          False)
                              ) ||
                              // Sequence name :BeingCapturedAndPreviouslyWasNot
                              (
                                    IsBeingCaptured == False &&
                                    GreaterInt(
                                          Count, 
                                          0) &&
                                    SetVarBool(
                                          out IsBeingCaptured, 
                                          true) &&
                                    GetUnitTeam(
                                          out CapturePointTeam, 
                                          CapturePoint) &&
                                    // Sequence name :Selector
                                    (
                                          CapturePointTeam == ReferenceTeam                                          CapturePointTeam == TeamId.TEAM_NEUTRAL
                                    ) &&
                                    SetVarFloat(
                                          out NextUpdateTime, 
                                          0)

                              )
                        )
                  )
            );
      }
}

