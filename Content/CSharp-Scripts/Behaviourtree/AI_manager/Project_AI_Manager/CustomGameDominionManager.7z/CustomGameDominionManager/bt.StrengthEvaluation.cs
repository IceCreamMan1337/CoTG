using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class StrengthEvaluation : BehaviourTree 
{
      out float EnemyStrength;
      out float FriendlyStrength;
      Vector3PointPosition;
      AttackableUnit ReferenceUnit;
      float Radius;
      float MinionPointValue;
      float ChampionPointValue;
      float CPPointValue;

      bool StrengthEvaluation()
      {
      return
            // Sequence name :Evaluate_Strength_Of_Units_In_Area
            (
                  GetUnitsInTargetArea(
                        out TargetCollection, 
                        ReferenceUnit, 
                        PointPosition, 
                        Radius, 
                        AffectEnemies,AffectFriends,AffectHeroes,AffectMinions,AffectUseable,NotAffectSelf, 
                        "") &&
                  SetVarFloat(
                        out EnemyStrength, 
                        0) &&
                  SetVarFloat(
                        out FriendlyStrength, 
                        0) &&
                  GetUnitTeam(
                        out MyTeam, 
                        ReferenceUnit) &&
                  TargetCollection.ForEach( Unit => (
                        // Sequence name :Sequence
                        (
                              GetUnitTeam(
                                    out UnitTeam, 
                                    Unit) &&
                              // Sequence name :MinionHeroOrTurret
                              (
                                    // Sequence name :MinionOrCapturePoint
                                    (
                                          GetUnitType(
                                                out UnitType, 
                                                Unit) &&
                                          UnitType == MINION_UNIT &&
                                          // Sequence name :Selector
                                          (
                                                // Sequence name :CapturePoint
                                                (
                                                      GetUnitBuffCount(
                                                            out IsCP, 
                                                            Unit, 
                                                            OdinGuardianStatsByLevel) &&
                                                      GreaterInt(
                                                            IsCP, 
                                                            0) &&
                                                      SetVarFloat(
                                                            out Strength, 
                                                            CPPointValue)
                                                ) ||
                                                SetVarFloat(
                                                      out Strength, 
                                                      MinionPointValue)
                                          )
                                    ) ||
                                    // Sequence name :Hero
                                    (
                                          GetUnitType(
                                                out UnitType, 
                                                Unit) &&
                                          UnitType == HERO_UNIT &&
                                          TestAIEntityHasTask(
                                                Unit, 
                                                DOMINION_RETURN_TO_BASE, 
                                                , 
                                                , 
                                                , 
                                                False) &&
                                          SetVarFloat(
                                                out Strength, 
                                                ChampionPointValue) &&
                                          // Sequence name :MaskFailure
                                          (
                                                // Sequence name :Sequence
                                                (
                                                      SetVarBool(
                                                            out Run, 
                                                            False) &&
                                                      Run == true &&
                                                      TestUnitIsVisibleToTeam(
                                                            ReferenceUnit, 
                                                            Unit, 
                                                            False) &&
                                                      DivideFloat(
                                                            out Strength, 
                                                            Strength, 
                                                            2)
                                                )
                                          )
                                    )
                              ) &&
                              // Sequence name :MyTeamOrEnemyTeam
                              (
                                    // Sequence name :MyTeam
                                    (
                                          MyTeam == UnitTeam &&
                                          AddFloat(
                                                out FriendlyStrength, 
                                                FriendlyStrength, 
                                                Strength)
                                    ) ||
                                    // Sequence name :OtherTeam
                                    (
                                          NotEqualUnitTeam(
                                                MyTeam, 
                                                UnitTeam) &&
                                          AddFloat(
                                                out EnemyStrength, 
                                                EnemyStrength, 
                                                Strength)

                                    )
                              )
                        )
                  )
            );
      }
}

