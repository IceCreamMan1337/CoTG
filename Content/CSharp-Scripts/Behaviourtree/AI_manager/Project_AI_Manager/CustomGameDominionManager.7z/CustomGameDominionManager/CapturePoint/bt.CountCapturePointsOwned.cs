using static GameServerCore.Enums.SpellDataFlags;
using static GameServerCore.Enums.SpellbookType;
using static GameServerCore.Enums.UnitType;
using AIScripts;

namespace BehaviourTrees.Map8;


class CountCapturePointsOwned : BehaviourTree 
{
      out int NumCapturePoints_Enemy;
      out int NumCapturePoints_Ally;
      out int NumCapturePoints_Neutral;
      AttackableUnit CapturePointA;
      AttackableUnit CapturePointB;
      AttackableUnit CapturePointC;
      AttackableUnit CapturePointD;
      AttackableUnit CapturePointE;
      TeamEnum ReferenceTeam;

      bool CountCapturePointsOwned()
      {
      return
            // Sequence name :CPInfo
            (
                  SetVarInt(
                        out NumCapturePoints_Ally, 
                        0) &&
                  SetVarInt(
                        out NumCapturePoints_Enemy, 
                        0) &&
                  SetVarInt(
                        out NumCapturePoints_Neutral, 
                        0) &&
                  // Sequence name :GetCPCount
                  (
                        // Sequence name :CapturePointA
                        (
                              GetUnitTeam(
                                    out CPTeam, 
                                    CapturePointA) &&
                              // Sequence name :Ally_Neutral_Enemy
                              (
                                    // Sequence name :Ally
                                    (
                                          CPTeam == ReferenceTeam &&
                                          AddInt(
                                                out NumCapturePoints_Ally, 
                                                NumCapturePoints_Ally, 
                                                1)
                                    ) ||
                                    // Sequence name :Enemy
                                    (
                                          NotEqualUnitTeam(
                                                CPTeam, 
                                                TeamId.TEAM_NEUTRAL) &&
                                          AddInt(
                                                out NumCapturePoints_Enemy, 
                                                NumCapturePoints_Enemy, 
                                                1)
                                    ) ||
                                    AddInt(
                                          out NumCapturePoints_Neutral, 
                                          NumCapturePoints_Neutral, 
                                          1)
                              )
                        ) &&
                        // Sequence name :CapturePointB
                        (
                              GetUnitTeam(
                                    out CPTeam, 
                                    CapturePointB) &&
                              // Sequence name :Ally_Neutral_Enemy
                              (
                                    // Sequence name :Ally
                                    (
                                          CPTeam == ReferenceTeam &&
                                          AddInt(
                                                out NumCapturePoints_Ally, 
                                                NumCapturePoints_Ally, 
                                                1)
                                    ) ||
                                    // Sequence name :Enemy
                                    (
                                          NotEqualUnitTeam(
                                                CPTeam, 
                                                TeamId.TEAM_NEUTRAL) &&
                                          AddInt(
                                                out NumCapturePoints_Enemy, 
                                                NumCapturePoints_Enemy, 
                                                1)
                                    ) ||
                                    AddInt(
                                          out NumCapturePoints_Neutral, 
                                          NumCapturePoints_Neutral, 
                                          1)
                              )
                        ) &&
                        // Sequence name :CapturePointC
                        (
                              GetUnitTeam(
                                    out CPTeam, 
                                    CapturePointC) &&
                              // Sequence name :Ally_Neutral_Enemy
                              (
                                    // Sequence name :Ally
                                    (
                                          CPTeam == ReferenceTeam &&
                                          AddInt(
                                                out NumCapturePoints_Ally, 
                                                NumCapturePoints_Ally, 
                                                1)
                                    ) ||
                                    // Sequence name :Enemy
                                    (
                                          NotEqualUnitTeam(
                                                CPTeam, 
                                                TeamId.TEAM_NEUTRAL) &&
                                          AddInt(
                                                out NumCapturePoints_Enemy, 
                                                NumCapturePoints_Enemy, 
                                                1)
                                    ) ||
                                    AddInt(
                                          out NumCapturePoints_Neutral, 
                                          NumCapturePoints_Neutral, 
                                          1)
                              )
                        ) &&
                        // Sequence name :CapturePointD
                        (
                              GetUnitTeam(
                                    out CPTeam, 
                                    CapturePointD) &&
                              // Sequence name :Ally_Neutral_Enemy
                              (
                                    // Sequence name :Ally
                                    (
                                          CPTeam == ReferenceTeam &&
                                          AddInt(
                                                out NumCapturePoints_Ally, 
                                                NumCapturePoints_Ally, 
                                                1)
                                    ) ||
                                    // Sequence name :Enemy
                                    (
                                          NotEqualUnitTeam(
                                                CPTeam, 
                                                TeamId.TEAM_NEUTRAL) &&
                                          AddInt(
                                                out NumCapturePoints_Enemy, 
                                                NumCapturePoints_Enemy, 
                                                1)
                                    ) ||
                                    AddInt(
                                          out NumCapturePoints_Neutral, 
                                          NumCapturePoints_Neutral, 
                                          1)
                              )
                        ) &&
                        // Sequence name :CapturePointE
                        (
                              GetUnitTeam(
                                    out CPTeam, 
                                    CapturePointE) &&
                              // Sequence name :Ally_Neutral_Enemy
                              (
                                    // Sequence name :Ally
                                    (
                                          CPTeam == ReferenceTeam &&
                                          AddInt(
                                                out NumCapturePoints_Ally, 
                                                NumCapturePoints_Ally, 
                                                1)
                                    ) ||
                                    // Sequence name :Enemy
                                    (
                                          NotEqualUnitTeam(
                                                CPTeam, 
                                                TeamId.TEAM_NEUTRAL) &&
                                          AddInt(
                                                out NumCapturePoints_Enemy, 
                                                NumCapturePoints_Enemy, 
                                                1)
                                    ) ||
                                    AddInt(
                                          out NumCapturePoints_Neutral, 
                                          NumCapturePoints_Neutral, 
                                          1)

                              )
                        )
                  )
            );
      }
}

